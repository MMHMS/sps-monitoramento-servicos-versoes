﻿# SPS Monitoramento de Serviços - JANELA do instalador e do desinstalador (WPF, mesmo visual da tela de configuração:
# topo com a logo e a faixa degradê, etapa, barra de progresso no degradê SPS, lista do que foi feito, modo dia/noite).
#
# Uso (dentro de instalar.ps1 / desinstalar.ps1):
#   . (Join-Path $PSScriptRoot 'ui-janela.ps1')
#   $script:SemJanela = $true   -> tudo vai para o console (atualizador automático, sem ninguém olhando)
#   Abrir-Janela 'Título da janela' 'Título do topo' 'subtítulo' $pastaComLogo
#   Etapa 10 'Fazendo algo...'; Progresso 30; Detalhe '3 de 10'; Feito 'algo feito'; Aviso 'atenção'; Falhou 'motivo'
#   Pedir-Inicio @('linha 1','linha 2') 'Desinstalar' 'texto da caixa de marcar'  -> @{ Iniciar; Marcado }
#   Concluir $true 'mensagem' 'Abrir configuração'  -> $true se clicou no botão principal (espera fechar)
$script:UI = $null
$script:deuErro = $false
$script:quadroUI = $null

function Atualizar-Tela { if ($script:UI) { [void][Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Windows.Threading.DispatcherPriority]::Background, [Action] {}) } }

function Abrir-Janela([string]$tituloJanela, [string]$tituloTopo, [string]$subtitulo, [string]$pastaMarca) {
    if ($script:SemJanela) { Write-Host ''; Write-Host "=== $tituloTopo ==="; return }
    Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Xaml
    try {
        Add-Type -Namespace MonitUI -Name Nativo -MemberDefinition @'
[DllImport("shell32.dll", CharSet = CharSet.Unicode)] public static extern int SetCurrentProcessExplicitAppUserModelID(string id);
[DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr h, int a, ref int v, int s);
'@ -ErrorAction Stop
    } catch { }
    try { [void][MonitUI.Nativo]::SetCurrentProcessExplicitAppUserModelID('SPSGroup.MonitoramentoServiceLayer') } catch { }
    # tema: o escolhido na tela de configuração; senão o do Windows
    $tema = 'claro'
    try { $t = (Get-ItemProperty -LiteralPath 'HKCU:\Software\SPS Group\Monitoramento' -ErrorAction Stop).tema; if ($t -in 'claro', 'escuro') { $tema = $t } else { throw 'x' } }
    catch { try { if ((Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -ErrorAction Stop).AppsUseLightTheme -eq 0) { $tema = 'escuro' } } catch { } }
    $cores = @{
        claro  = @{ Fundo = '#F4F6FB'; Cartao = '#FFFFFF'; Texto = '#1A1D3A'; TextoSec = '#5D6380'; Borda = '#DFE3EE'; Titulo = '#0C0068'; Primario = '#0C0068'; Link = '#0085E5'; Ok = '#0F7D5F'; Erro = '#B3261E'; Alerta = '#7A4B00'; Selecao = '#E9EEFB' }
        escuro = @{ Fundo = '#0B1020'; Cartao = '#171D31'; Texto = '#E4E8F2'; TextoSec = '#9AA3B9'; Borda = '#2A3350'; Titulo = '#C3CDFF'; Primario = '#3D52D5'; Link = '#7FB2FF'; Ok = '#4FD1A5'; Erro = '#FF8F87'; Alerta = '#FFCF70'; Selecao = '#22305A' }
    }[$tema]
    $xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Width="660" SizeToContent="Height" ResizeMode="CanMinimize" WindowStartupLocation="CenterScreen"
        FontFamily="Segoe UI Variable Text, Segoe UI" FontSize="13" UseLayoutRounding="True" TextOptions.TextFormattingMode="Display">
  <Window.Resources>
    <LinearGradientBrush x:Key="Degrade" StartPoint="0,0" EndPoint="1,0">
      <GradientStop Color="#00C7B0" Offset="0"/><GradientStop Color="#00A5CD" Offset="0.5"/><GradientStop Color="#0085E5" Offset="1"/></LinearGradientBrush>
    <Style x:Key="Botao" TargetType="Button">
      <Setter Property="Cursor" Value="Hand"/><Setter Property="Padding" Value="18,9"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/><Setter Property="MinWidth" Value="120"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button">
        <Border x:Name="B" CornerRadius="8" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1" Padding="{TemplateBinding Padding}">
          <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="Opacity" Value="0.86"/></Trigger>
          <Trigger Property="IsEnabled" Value="False"><Setter TargetName="B" Property="Opacity" Value="0.4"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="Chave" TargetType="CheckBox">
      <Setter Property="Cursor" Value="Hand"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="CheckBox">
        <StackPanel Orientation="Horizontal" Background="Transparent">
          <Border x:Name="T" Width="34" Height="18" CornerRadius="9" Background="#8A93AD" VerticalAlignment="Center">
            <Ellipse x:Name="E" Width="14" Height="14" Fill="White" HorizontalAlignment="Left" Margin="2,0"/></Border>
          <ContentPresenter Margin="9,0,0,0" VerticalAlignment="Center"/>
        </StackPanel>
        <ControlTemplate.Triggers>
          <Trigger Property="IsChecked" Value="True"><Setter TargetName="T" Property="Background" Value="#D9534F"/><Setter TargetName="E" Property="HorizontalAlignment" Value="Right"/></Trigger>
          <Trigger Property="IsEnabled" Value="False"><Setter Property="Opacity" Value="0.5"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
  </Window.Resources>
  <DockPanel x:Name="Raiz">
    <StackPanel DockPanel.Dock="Top">
      <Border x:Name="Topo" Padding="22,12"><StackPanel Orientation="Horizontal">
        <Border CornerRadius="8" Background="White" Padding="8,4" VerticalAlignment="Center"><Image x:Name="Logo" Height="32" RenderOptions.BitmapScalingMode="HighQuality"/></Border>
        <Border x:Name="Divisor" Width="1" Height="30" Margin="16,0"/>
        <StackPanel VerticalAlignment="Center">
          <TextBlock x:Name="TxtTitulo" FontSize="16" FontWeight="SemiBold"/>
          <TextBlock x:Name="TxtSub" FontSize="12"/>
        </StackPanel>
      </StackPanel></Border>
      <Border Height="4" Background="{StaticResource Degrade}"/>
    </StackPanel>
    <Border x:Name="Rodape" DockPanel.Dock="Bottom" BorderThickness="0,1,0,0" Padding="22,12"><DockPanel>
      <StackPanel DockPanel.Dock="Right" Orientation="Horizontal">
        <Button x:Name="BtnPrincipal" Style="{StaticResource Botao}" Foreground="White" FontWeight="SemiBold" Margin="0,0,8,0" Visibility="Collapsed"/>
        <Button x:Name="BtnFechar" Style="{StaticResource Botao}" Content="Fechar" IsEnabled="False"/>
      </StackPanel>
      <TextBlock x:Name="TxtRodape" VerticalAlignment="Center" FontSize="12" TextTrimming="CharacterEllipsis"/>
    </DockPanel></Border>
    <StackPanel Margin="22,18,22,18">
      <TextBlock x:Name="TxtEtapa" FontSize="15" FontWeight="SemiBold" TextWrapping="Wrap"/>
      <Grid Height="8" Margin="0,12,0,0">
        <Border x:Name="Trilho" CornerRadius="4"/>
        <Border x:Name="Barra" CornerRadius="4" HorizontalAlignment="Left" Width="0" Background="{StaticResource Degrade}"/>
      </Grid>
      <TextBlock x:Name="TxtDetalhe" FontSize="12" Margin="0,7,0,0" TextWrapping="Wrap"/>
      <CheckBox x:Name="Caixa" Style="{StaticResource Chave}" Margin="0,12,0,0" Visibility="Collapsed"/>
      <Border x:Name="CaixaLista" CornerRadius="10" BorderThickness="1" Padding="14,10" Margin="0,14,0,0">
        <ScrollViewer x:Name="Rolagem" Height="190" VerticalScrollBarVisibility="Auto">
          <TextBlock x:Name="Lista" FontSize="12.5" TextWrapping="Wrap" LineHeight="21"/></ScrollViewer>
      </Border>
    </StackPanel>
  </DockPanel>
</Window>
'@
    $j = [Windows.Markup.XamlReader]::Parse($xaml)
    $ui = @{ Janela = $j; Trabalhando = $true; Escolha = $false; Cores = $cores; Pct = 0 }
    foreach ($n in 'Raiz', 'Topo', 'Divisor', 'Logo', 'TxtTitulo', 'TxtSub', 'Rodape', 'BtnPrincipal', 'BtnFechar', 'TxtRodape', 'TxtEtapa', 'Trilho', 'Barra', 'TxtDetalhe', 'Caixa', 'CaixaLista', 'Rolagem', 'Lista') { $ui[$n] = $j.FindName($n) }
    $pincel = { param($hex) $p = [Windows.Media.SolidColorBrush]::new([Windows.Media.ColorConverter]::ConvertFromString($hex)); $p.Freeze(); $p }
    $ui.Pincel = $pincel
    $j.Title = $tituloJanela; $ui.TxtTitulo.Text = $tituloTopo; $ui.TxtSub.Text = $subtitulo
    $ui.Raiz.Background = & $pincel $cores.Fundo; $ui.Topo.Background = & $pincel $cores.Cartao; $ui.Rodape.Background = & $pincel $cores.Cartao
    $ui.Rodape.BorderBrush = & $pincel $cores.Borda; $ui.Divisor.Background = & $pincel $cores.Borda; $ui.Trilho.Background = & $pincel $cores.Borda
    $ui.TxtTitulo.Foreground = & $pincel $cores.Titulo; $ui.TxtSub.Foreground = & $pincel $cores.TextoSec; $ui.TxtEtapa.Foreground = & $pincel $cores.Titulo
    $ui.TxtDetalhe.Foreground = & $pincel $cores.TextoSec; $ui.TxtRodape.Foreground = & $pincel $cores.TextoSec; $ui.Lista.Foreground = & $pincel $cores.Texto
    $ui.Caixa.Foreground = & $pincel $cores.Texto
    $ui.CaixaLista.Background = & $pincel $cores.Cartao; $ui.CaixaLista.BorderBrush = & $pincel $cores.Borda
    $ui.BtnPrincipal.Background = & $pincel $cores.Primario; $ui.BtnPrincipal.BorderBrush = & $pincel $cores.Primario
    $ui.BtnFechar.Background = & $pincel $cores.Cartao; $ui.BtnFechar.BorderBrush = & $pincel $cores.Borda; $ui.BtnFechar.Foreground = & $pincel $cores.Titulo
    # logo e ícone carregados na memória (o desinstalador apaga a pasta depois)
    foreach ($par in @(@('logo_sps.png', 'Logo'), @('logo_sps.ico', 'Icone'))) {
        $arq = Join-Path $pastaMarca $par[0]
        if (Test-Path -LiteralPath $arq) {
            try {
                $b = New-Object Windows.Media.Imaging.BitmapImage; $b.BeginInit(); $b.CacheOption = 'OnLoad'
                $b.StreamSource = New-Object IO.MemoryStream(, [IO.File]::ReadAllBytes($arq)); $b.EndInit(); $b.Freeze()
                if ($par[1] -eq 'Logo') { $ui.Logo.Source = $b } else { $j.Icon = $b }
            } catch { }
        }
    }
    # botão principal: na pergunta inicial só libera a espera; no fim fecha a janela
    $ui.BtnPrincipal.Add_Click({ $script:UI.Escolha = $true; if ($script:UI.ModoInicio) { if ($script:quadroUI) { $script:quadroUI.Continue = $false } } else { $script:UI.Janela.Close() } })
    $ui.BtnFechar.Add_Click({ $script:UI.Janela.Close() })
    # não deixa fechar no X no meio do trabalho (deixaria a instalação pela metade)
    $j.Add_Closing({ param($s, $e) if ($script:UI.Trabalhando) { $e.Cancel = $true } })
    $j.Add_Closed({ if ($script:quadroUI) { $script:quadroUI.Continue = $false } })
    $j.Add_SourceInitialized({ try { $h = (New-Object Windows.Interop.WindowInteropHelper($script:UI.Janela)).Handle; $v = [int]($script:UI.Tema -eq 'escuro'); [void][MonitUI.Nativo]::DwmSetWindowAttribute($h, 20, [ref]$v, 4) } catch { } })
    $ui.Tema = $tema
    $script:UI = $ui
    $j.Show(); $j.Activate() | Out-Null
    Atualizar-Tela
}

function Desenhar-Barra { $u = $script:UI; $u.Janela.UpdateLayout(); $u.Barra.Width = [Math]::Max(0, $u.Trilho.ActualWidth * $u.Pct / 100) }
function Etapa([int]$pct, [string]$texto) {
    if (-not $script:UI) { Write-Host ''; Write-Host ">> $texto"; return }
    $script:UI.Pct = [Math]::Min(100, [Math]::Max(0, $pct)); Desenhar-Barra
    $script:UI.TxtEtapa.Text = $texto; $script:UI.TxtDetalhe.Text = ''; Atualizar-Tela
}
function Progresso([int]$pct) { if ($script:UI) { $script:UI.Pct = [Math]::Min(100, [Math]::Max(0, $pct)); Desenhar-Barra; Atualizar-Tela } }
function Detalhe([string]$texto) { if ($script:UI) { $script:UI.TxtDetalhe.Text = $texto; Atualizar-Tela } }
function Linha-Lista([string]$texto, [string]$cor) {
    $u = $script:UI
    $run = New-Object Windows.Documents.Run($texto); if ($cor) { $run.Foreground = & $u.Pincel $u.Cores[$cor] }
    if ($u.Lista.Inlines.Count) { $u.Lista.Inlines.Add((New-Object Windows.Documents.LineBreak)) }
    $u.Lista.Inlines.Add($run); $u.Rolagem.ScrollToEnd(); Atualizar-Tela
}
function Feito([string]$texto) { if (-not $script:UI) { Write-Host "   ok  $texto"; return }; Linha-Lista ([string][char]0x2713 + '  ' + $texto) $null }
function Aviso([string]$texto) { if (-not $script:UI) { Write-Host "   !   $texto"; return }; Linha-Lista ('!  ' + $texto) 'Alerta' }
function Falhou([string]$texto) {
    $script:deuErro = $true
    if (-not $script:UI) { Write-Host ''; Write-Host "ERRO: $texto"; return }
    $script:UI.TxtEtapa.Text = 'Não foi possível concluir'; $script:UI.TxtEtapa.Foreground = & $script:UI.Pincel $script:UI.Cores.Erro
    Linha-Lista ([string][char]0x2717 + '  ' + $texto) 'Erro'
}
# espera um clique (o trabalho já parou): mantém a janela respondendo até ela fechar ou alguém clicar
function Esperar-Clique { $script:quadroUI = New-Object Windows.Threading.DispatcherFrame; [Windows.Threading.Dispatcher]::PushFrame($script:quadroUI); $script:quadroUI = $null }

# antes de começar: explicação na lista, caixa de marcar opcional e os botões [textoBotao] / Cancelar
function Pedir-Inicio([string[]]$linhas, [string]$textoBotao, [string]$textoCaixa = '') {
    if (-not $script:UI) { return @{ Iniciar = $true; Marcado = $false } }
    $u = $script:UI
    $u.Lista.Inlines.Clear(); foreach ($l in $linhas) { Linha-Lista $l $null }
    if ($textoCaixa) { $u.Caixa.Content = $textoCaixa; $u.Caixa.Visibility = 'Visible' }
    $u.Barra.Visibility = 'Hidden'; $u.Trilho.Visibility = 'Hidden'
    $u.BtnPrincipal.Content = $textoBotao; $u.BtnPrincipal.Visibility = 'Visible'; $u.BtnFechar.Content = 'Cancelar'; $u.BtnFechar.IsEnabled = $true
    $u.Trabalhando = $false; $u.Escolha = $false; $u.ModoInicio = $true
    if ($env:SPS_JANELA_TESTE) { $u.Escolha = $true } else { Esperar-Clique }   # teste automatizado: responde "sim"
    $u.ModoInicio = $false
    $r = @{ Iniciar = [bool]$u.Escolha; Marcado = [bool]$u.Caixa.IsChecked }
    if ($r.Iniciar) {
        $u.Escolha = $false; $u.Trabalhando = $true; $u.Caixa.IsEnabled = $false
        $u.BtnPrincipal.Visibility = 'Collapsed'; $u.BtnFechar.Content = 'Fechar'; $u.BtnFechar.IsEnabled = $false
        $u.Barra.Visibility = 'Visible'; $u.Trilho.Visibility = 'Visible'; $u.Lista.Inlines.Clear(); Atualizar-Tela
    }
    return $r
}

# fim: mostra o resultado, libera os botões e espera fechar. Devolve $true se clicou no botão principal.
function Concluir([bool]$ok, [string]$mensagem, [string]$textoPrincipal = '') {
    if (-not $script:UI) { Write-Host ''; Write-Host $(if ($ok) { "OK: $mensagem" } else { "ERRO: $mensagem" }); return $false }
    $u = $script:UI
    if ($ok) { $u.Pct = 100; Desenhar-Barra; $u.TxtEtapa.Foreground = & $u.Pincel $u.Cores.Ok; if ($u.TxtEtapa.Text -notmatch 'conclu') { $u.TxtEtapa.Text = 'Concluído' } }
    $u.TxtDetalhe.Text = $mensagem
    if ($ok -and $textoPrincipal) { $u.BtnPrincipal.Content = $textoPrincipal; $u.BtnPrincipal.Visibility = 'Visible' } else { $u.BtnPrincipal.Visibility = 'Collapsed' }
    $u.BtnFechar.Content = 'Fechar'; $u.BtnFechar.IsEnabled = $true
    $u.Trabalhando = $false
    if ($env:SPS_JANELA_TESTE) { return $false }   # teste automatizado: não espera clique
    if ($u.Janela.IsVisible) { Esperar-Clique }
    return [bool]$u.Escolha
}
