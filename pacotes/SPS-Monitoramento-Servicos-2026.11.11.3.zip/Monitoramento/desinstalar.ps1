﻿﻿# Desinstala o Monitoramento de Serviços deste servidor (janela com barra de progresso, mesmo visual da tela de configuração).
# Chamado pelo DESINSTALAR.vbs (dois cliques, pede permissão de administrador).
# Remove: a tarefa agendada, o atualizador (se aponta para esta pasta) e o ícone da área de trabalho.
# A pasta (configuração, senhas criptografadas, logs e o Node) só é apagada se marcar a caixa.
$pasta = Split-Path -Parent $MyInvocation.MyCommand.Path
$nomeTarefa = 'Monitoramento Service Layer'
$nomeAtualizador = 'Monitoramento de Servicos - Atualizador'
. (Join-Path $pasta 'ui-janela.ps1')
Abrir-Janela 'Monitoramento de Serviços - Desinstalação' 'Desinstalar o Monitoramento de Serviços' 'SPS Group · Monitoramento de Serviços' $pasta
Etapa 0 'Isto para o monitoramento e remove a tarefa agendada e o ícone da área de trabalho.'
$escolha = Pedir-Inicio @(
    'O que será removido:',
    "   •  tarefa agendada '$nomeTarefa' (o monitoramento para)",
    "   •  atualizador '\SPS Group\$nomeAtualizador'",
    "   •  ícone 'Monitoramento da Service Layer' da área de trabalho",
    '',
    'Marque a caixa acima para apagar também a pasta inteira:',
    "   $pasta",
    '   (configuração, senhas criptografadas, logs e o Node baixado)') 'Desinstalar' 'Apagar também a pasta (configuração, senhas e logs)'
if (-not $escolha.Iniciar) { return }
$script:apagarPasta = [bool]$escolha.Marcado

function Desinstalar {
    try {
        $admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        if (-not $admin) { throw 'O desinstalador precisa de permissão de administrador.' }

        Etapa 15 'Parando o monitoramento...'
        if (Get-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue) { Stop-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue }
        # encerra o node que estiver rodando a partir desta pasta
        Get-Process node -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path -like "$pasta*" } | Stop-Process -Force -ErrorAction SilentlyContinue
        Feito 'monitoramento parado'

        Etapa 40 'Removendo a tarefa agendada...'
        if (Get-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue) { Unregister-ScheduledTask -TaskName $nomeTarefa -Confirm:$false; Feito "tarefa '$nomeTarefa' removida" }
        else { Feito 'tarefa agendada não existia' }
        # atualizador (\SPS Group\Monitoramento de Servicos - Atualizador): só remove se aponta para ESTA pasta
        Etapa 55 'Removendo o atualizador...'
        $tAtu = Get-ScheduledTask -TaskName $nomeAtualizador -TaskPath '\SPS Group\' -ErrorAction SilentlyContinue
        if ($tAtu -and "$($tAtu.Actions[0].Arguments)".ToLower().Contains(("$pasta\atualizar.ps1").ToLower())) {
            Unregister-ScheduledTask -TaskName $nomeAtualizador -TaskPath '\SPS Group\' -Confirm:$false
            Feito 'atualizador removido'
            # a pasta "SPS Group" do Agendador só sai se ficou vazia (outros produtos SPS usam a mesma)
            try {
                $agenda = New-Object -ComObject Schedule.Service; $agenda.Connect()
                $grupo = $agenda.GetFolder('\SPS Group')
                if ($grupo.GetTasks(1).Count -eq 0 -and $grupo.GetFolders(0).Count -eq 0) { $agenda.GetFolder('\').DeleteFolder('SPS Group', 0) }
            } catch { }
        } elseif ($tAtu) { Feito 'atualizador mantido (é de outra pasta)' } else { Feito 'atualizador não existia' }
        Remove-Item -LiteralPath (Join-Path $pasta 'atualizacoes') -Recurse -Force -ErrorAction SilentlyContinue

        Etapa 70 'Removendo o ícone da área de trabalho...'
        $atalho = Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'Monitoramento da Service Layer.lnk'
        if (Test-Path -LiteralPath $atalho) { Remove-Item -LiteralPath $atalho -Force; Feito 'ícone removido' } else { Feito 'ícone não existia' }
        $atalhoManual = Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'Manual do Monitoramento.lnk'
        if (Test-Path -LiteralPath $atalhoManual) { Remove-Item -LiteralPath $atalhoManual -Force; Feito 'ícone do manual removido' }

        if ($script:apagarPasta) { Etapa 90 'Preparando a remoção da pasta...'; Feito ('a pasta ' + $pasta + ' será apagada ao fechar esta janela') }
        else { Feito ('pasta mantida: ' + $pasta + ' (rode o INSTALAR.vbs para reinstalar)') }
        Etapa 100 'Desinstalação concluída'
    } catch { Falhou $_.Exception.Message; $script:apagarPasta = $false }
}
Desinstalar
[void](Concluir (-not $script:deuErro) $(if ($script:deuErro) { 'Nada mais foi removido. Corrija o problema acima e rode o DESINSTALAR.vbs de novo.' } elseif ($script:apagarPasta) { 'Ao fechar, a pasta é apagada.' } else { 'A configuração ficou guardada na pasta.' }))
# a pasta só é apagada depois que esta janela fechou (este script roda de dentro dela)
if ($script:apagarPasta) {
    Set-Location -LiteralPath $env:TEMP
    Start-Process -FilePath "$env:SystemRoot\System32\cmd.exe" -ArgumentList ('/c timeout /t 3 /nobreak >nul & rmdir /s /q "' + $pasta + '"') -WorkingDirectory $env:TEMP -WindowStyle Hidden
}
