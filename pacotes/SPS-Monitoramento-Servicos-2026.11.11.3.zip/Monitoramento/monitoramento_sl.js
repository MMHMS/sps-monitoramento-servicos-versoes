// MONITORAMENTO DA SERVICE LAYER (Agendador de Tarefas do Windows): roda com o Node.js instalado no servidor (pré-requisito), sem depender do DIS.
// Uso: node monitoramento_sl.js            -> monitorar (o agendamento chama assim, a cada 1 minuto)
//      node monitoramento_sl.js status     -> só mostra o status no Controller (não envia nada)
//      node monitoramento_sl.js teste_email | memoria
// Configuração: config.json (senhas criptografadas pela máquina) e tempos.json, editados pelo configurar_monitoramento.ps1.
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const { execFile } = require('child_process');
const PASTA = __dirname;
const variables = {};

// config.json: usuário/senha do Controller, SMTP e destinatários (com defeito = erro em logs\geral e nada é feito)
let ERRO_CONFIG = '';
const CONFIG = (() => { try { return JSON.parse(fs.readFileSync(path.join(PASTA, 'config.json'), 'utf8').replace(/^﻿/, '')); } catch (e) { ERRO_CONFIG = e.message; return {}; } })();

// logs: uma pasta por Service Layer (logs\NOME\AAAA-MM-DD.log) + logs\geral só para erros fora de uma Service Layer;
// em cada pasta ficam só os últimos dias_manter_logs dias (tempos.json, padrão 30)
const PASTA_LOGS = path.join(PASTA, 'logs');
const DIAS_LOG = (() => { try { const v = Number(JSON.parse(fs.readFileSync(path.join(PASTA, 'tempos.json'), 'utf8')).dias_manter_logs); return v >= 1 ? v : 30; } catch (e) { return 30; } })();
const dataArquivo = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const pastaSegura = (nome) => String(nome || 'geral').replace(/[^A-Za-z0-9_-]/g, '_');
const pastasLimpas = {};
function limparLogsAntigos(pasta) {
    pastasLimpas[pasta] = true;
    try {
        const limite = dataArquivo(new Date(Date.now() - DIAS_LOG * 86400000));
        fs.readdirSync(pasta).forEach(a => {
            const m = a.match(/^(\d{4}-\d{2}-\d{2})\.log$/);
            if (m && m[1] < limite) fs.unlinkSync(path.join(pasta, a));
        });
    } catch (e) { }
}
const console = {
    // nome = Service Layer dona da linha (sem nome = logs\geral)
    log: (s, nome) => {
        const agora = new Date();
        const linha = agora.toLocaleTimeString('pt-BR') + ' ' + s;
        process.stdout.write(linha + '\n');
        try {
            const pasta = path.join(PASTA_LOGS, pastaSegura(nome));
            if (!fs.existsSync(pasta)) fs.mkdirSync(pasta, { recursive: true });
            fs.appendFileSync(path.join(pasta, dataArquivo(agora) + '.log'), linha + '\n');
            if (!pastasLimpas[pasta]) limparLogsAntigos(pasta);
        } catch (e) { }
    }
};
// chamada HTTP(S) no formato que o monitoramento usava no DIS (axios): { status, headers, data }
function axios(cfg) {
    return new Promise((ok, falha) => {
        const u = new URL(cfg.url);
        const corpo = cfg.data ? Buffer.from(String(cfg.data)) : null;
        const headers = Object.assign({}, cfg.headers || {});
        if (corpo) headers['Content-Length'] = corpo.length;
        const tempo = cfg.timeout || 30000;
        const req = (u.protocol === 'https:' ? https : http).request({
            hostname: u.hostname, port: u.port, path: u.pathname + u.search, method: cfg.method || 'GET', headers,
            agent: u.protocol === 'https:' ? agente : undefined
        }, res => {
            const partes = [];
            res.on('data', d => partes.push(d));
            res.on('end', () => ok({ status: res.statusCode, headers: res.headers, data: Buffer.concat(partes).toString('utf8') }));
        });
        req.setTimeout(tempo, () => { const e = new Error('timeout of ' + tempo + 'ms exceeded'); e.code = 'ECONNABORTED'; req.destroy(e); });
        req.on('error', falha);
        if (corpo) req.write(corpo);
        req.end();
    });
}
axios.get = (url, cfg) => axios(Object.assign({}, cfg || {}, { url, method: 'GET' }));

// e-mail pelo enviar_email.ps1 (SMTP e senha do config.json)
function sendEmail(d) {
    const arq = path.join(PASTA, 'email_' + Date.now() + '_' + Math.floor(Math.random() * 1000) + '.html');
    fs.writeFileSync(arq, d.html, 'utf8');
    return new Promise((ok, falha) => {
        execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(PASTA, 'enviar_email.ps1'),
            '-Assunto', d.subject, '-Para', d.to, '-ArquivoHtml', arq], { timeout: 90000, windowsHide: true }, (err, saida, erroSaida) => {
                try { fs.unlinkSync(arq); } catch (e) { }
                if (err) falha(new Error(String(erroSaida || err.message).trim())); else ok(saida);
            });
    });
}

const log = (t, v) => console.log(t + ': ' + (typeof v === 'string' ? v : JSON.stringify(v)));
const semQuery = (u) => String(u || '').split('?')[0];

// ===== configuração =====
// MODO: 'status'        = só conecta no Controller e mostra o status (não envia nada)
//       'teste_restart' = reinicia AGORA e acompanha até voltar (rodar manual, no horário combinado)
//       'teste_email'   = só manda um e-mail de teste
//       'memoria'       = mostra no log o resumo da memória medida (por dia: mínimo, média, máximo)
//       'monitorar'     = para o agendamento de 1 em 1 min (parada: reinicia na hora; lenta ou memória alta: na 3ª seguida)
const MODO = (process.argv[2] === 'vigiar' ? 'monitorar' : process.argv[2]) || 'monitorar';
// Service Layers monitoradas (config.json "servicos"): todas com o mesmo login do Controller.
// Os caminhos usam o NOME do servidor: o Controller recusa acesso pelo IP.
// Service Layers monitoradas (config.json "servicos"): todas com o mesmo login do Controller.
// Os caminhos usam o NOME do servidor: o Controller recusa acesso pelo IP.
const SERVICOS = (Array.isArray(CONFIG.servicos) ? CONFIG.servicos : [])
    .filter(s => s && s.nome && s.controller && s.service_layer);// tempos e limites: tempos.json (na mesma pasta). Valor ausente ou inválido = padrão abaixo.
const TEMPOS = (() => { try { return JSON.parse(fs.readFileSync(path.join(PASTA, 'tempos.json'), 'utf8')); } catch (e) { return {}; } })();
const num = (nome, padrao) => { const v = Number(TEMPOS[nome]); return TEMPOS[nome] !== undefined && TEMPOS[nome] !== '' && !isNaN(v) && v >= 0 ? v : padrao; };
const FALHAS_SEM_RESPOSTA = Math.max(1, num('falhas_sem_resposta', 1));
const FALHAS_LENTIDAO = Math.max(1, num('falhas_lentidao', 3));
const MEDICOES_MEMORIA = Math.max(1, num('medicoes_memoria', 3));
const MINUTOS_ENTRE_RELIGAMENTOS = num('minutos_entre_reinicios', 0);
const SEGUNDOS_TESTE = num('segundos_sem_resposta', 30);
const SEGUNDOS_LENTO = num('segundos_lentidao', 10);
const MINUTOS_ESPERAR_VOLTAR = num('minutos_esperar_voltar', 5);
// fora sem parar há mais que isso (ex.: Service Layer desativada e esquecida no cadastro): para de reiniciar e avisa 1 vez por dia (0 = nunca)
const HORAS_PARAR_REINICIO = num('horas_parar_reinicio', 24);
const SEGUNDOS_ENTRE_VERIFICACOES = Math.max(1, num('segundos_entre_verificacoes', 10));
const SEGUNDOS_POR_EXECUCAO = num('segundos_por_execucao', 50);
const SEGUNDOS_CONFIRMAR = num('segundos_confirmar', 30);
const COMANDOS_POR_EXECUCAO = Math.max(1, num('comandos_por_execucao', 3));
const MINUTOS_MEDIR_MEMORIA = num('minutos_medir_memoria', 15);
const ALERTA_GB = num('alerta_memoria_gb', 0);
const LIMITE_GB = num('limite_memoria_gb', 0);
const JANELA_REINICIO_MEMORIA = typeof TEMPOS.janela_reinicio_memoria === 'string' && TEMPOS.janela_reinicio_memoria ? TEMPOS.janela_reinicio_memoria : '00:00-05:00';
const EMAIL_PARA = CONFIG.email_para || '';
// avisos (config.json "avisos"): quais e-mails enviar e de quanto em quanto tempo repetir
const AVISOS = CONFIG.avisos || {};
const avisoLigado = (tipo) => AVISOS[tipo] !== false;
const REPETIR_MS = (Number(AVISOS.repetir_min) > 0 ? Number(AVISOS.repetir_min) : 30) * 60000;
const ALERTA_MEMORIA_MS = (Number(AVISOS.memoria_min) > 0 ? Number(AVISOS.memoria_min) : 60) * 60000;
const usuario = String(CONFIG.controller_usuario || '').trim();
// senha do Controller: criptografada pela máquina (configurar_monitoramento.ps1) ou, em último caso, em texto (controller_senha)
let senhaCache;
function senhaController() {
    if (senhaCache === undefined) senhaCache = abrirSenha('controller_senha_cripto') || CONFIG.controller_senha || '';
    return senhaCache;
}
// abre a senha criptografada (chave desta máquina, DPAPI LocalMachine) pelo abrir_senha.ps1, que lê direto do config.json
// (nada criptografado vai na linha de comando: antivírus derruba programa que passa base64 longo para o PowerShell)
function abrirSenha(campo) {
    if (!CONFIG[campo]) return '';
    try {
        const saida = require('child_process').execFileSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
            path.join(PASTA, 'abrir_senha.ps1'), '-Campo', campo], { encoding: 'utf8', windowsHide: true, timeout: 30000 }).trim();
        return Buffer.from(saida, 'base64').toString('utf8');
    } catch (e) { log('Senha', 'não consegui abrir a senha criptografada: ' + String(e.message || e).split('\n')[0]); return ''; }
}

// o Controller usa certificado próprio: aceito só nas chamadas do monitoramento
const agente = new https.Agent({ rejectUnauthorized: false });

// um monitor por Service Layer: estado, sessão, histórico e log próprios.
// Todos rodam no MESMO processo, em paralelo: uma Service Layer reiniciando não atrasa as outras,
// e um erro numa fica no tratamento dela (try/catch próprio), sem derrubar as demais.
function criarMonitor(servico, indice) {
    const NOME_SL = servico.nome;
    const BASE = servico.controller;
    const URL_SERVICE_LAYER = servico.service_layer;
    const REINICIA = servico.reiniciar !== false;   // false = só avisa, não reinicia
    const prefixo = SERVICOS.length > 1 ? '[' + NOME_SL + '] ' : '';
    const log = (t, v) => console.log(prefixo + t + ': ' + (typeof v === 'string' ? v : JSON.stringify(v)), NOME_SL);
    // estado em dados\NOME\estado.json; ocorrências em logs\NOME\historico.log (uma linha por evento)
    const PASTA_DADOS = path.join(PASTA, 'dados', pastaSegura(NOME_SL));
    try { fs.mkdirSync(PASTA_DADOS, { recursive: true }); fs.mkdirSync(path.join(PASTA_LOGS, pastaSegura(NOME_SL)), { recursive: true }); } catch (e) { }
    const ARQ_ESTADO = path.join(PASTA_DADOS, 'estado.json');
    const ARQ_HISTORICO = path.join(PASTA_LOGS, pastaSegura(NOME_SL), 'historico.log');
    // guarda os cookies da sessão (login do Keycloak e do Controller)
    const cookies = new Map();
    function guardarCookies(r) {
        const sc = r.headers && r.headers['set-cookie'];
        (Array.isArray(sc) ? sc : sc ? [sc] : []).forEach(c => {
            const par = c.split(';')[0];
            const i = par.indexOf('=');
            if (i > 0) cookies.set(par.slice(0, i).trim(), par.slice(i + 1));
        });
    }
    const cabecalhoCookie = () => [...cookies].map(([k, v]) => k + '=' + v).join('; ');

    // faz a chamada e segue os redirecionamentos guardando os cookies
    async function ir(url, metodo, corpo) {
        for (let i = 0; i < 15; i++) {
            const r = await axios({
                url, method: metodo || 'GET', data: corpo, httpsAgent: agente, timeout: 30000,
                maxRedirects: 0, validateStatus: () => true, responseType: 'text', transformResponse: [d => d],
                headers: Object.assign({ Cookie: cabecalhoCookie() }, corpo ? { 'Content-Type': 'application/x-www-form-urlencoded' } : {})
            });
            guardarCookies(r);
            log((metodo || 'GET') + ' ' + semQuery(url), 'HTTP ' + r.status);
            const destino = r.headers && r.headers.location;
            if (r.status >= 300 && r.status < 400 && destino) {
                url = new URL(destino, url).href;
                metodo = 'GET';
                corpo = undefined;
                continue;
            }
            return { r, url, html: String(r.data || '') };
        }
        throw new Error('Redirecionamentos demais');
    }

    async function entrar() {
        if (!usuario) { log('Login', 'usuário do Controller não configurado (tela de configuração, aba Service Layers)'); return null; }
        if (!senhaController()) { log('Login', 'senha do Controller não configurada (rode o configurar_monitoramento.ps1)'); return null; }
        // 1. abre o Controller: cai na tela de login
        let pag = await ir(BASE);
        // 2. o login da SAP tem etapas (1ª tela: usuário; 2ª tela: senha). Preenche cada tela até sair do login.
        let senhaEnviada = false;
        for (let etapa = 1; etapa <= 4; etapa++) {
            const form = pag.html.match(/<form[^>]*action=["']([^"']*login-actions[^"']*)["']/i);
            if (!form) break;
            const acao = new URL(form[1].replace(/&amp;/g, '&'), pag.url).href;

            // campos da tela (mostra só o NOME e o tipo; os escondidos e o botão vão com o valor deles)
            const blocoForm = (pag.html.match(/<form[\s\S]*?<\/form>/i) || [pag.html])[0];
            const campos = [...blocoForm.matchAll(/<(input|select|button)\b[^>]*>/gi)].map(m => {
                const tag = m[0];
                const pega = (a) => { const x = tag.match(new RegExp('\\b' + a + '=["\']([^"\']*)["\']', 'i')); return x ? x[1] : ''; };
                return { nome: pega('name'), tipo: pega('type') || m[1], valor: pega('value') };
            }).filter(c => c.nome);
            log('Etapa ' + etapa + ' - campos', campos.map(c => c.nome + ' (' + c.tipo + ')'));

            if (senhaEnviada && campos.some(c => /password/i.test(c.tipo))) {
                const textos = [...pag.html.matchAll(/<(span|div|p)[^>]*(error|alert|feedback)[^>]*>([\s\S]{0,300}?)<\/\1>/gi)]
                    .map(m => m[3].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()).filter(Boolean);
                log('Login', 'RECUSADO');
                log('Mensagem da tela', textos.slice(0, 5));
                return null;
            }

            const dados = {};
            campos.forEach(c => {
                if (/password/i.test(c.tipo)) { dados[c.nome] = senhaController(); senhaEnviada = true; }
                else if (/text|email/i.test(c.tipo) && /user|login|email/i.test(c.nome)) dados[c.nome] = usuario;
                else if (/hidden|submit/i.test(c.tipo)) dados[c.nome] = c.valor;
            });
            log('Etapa ' + etapa + ' - enviando', Object.keys(dados));
            pag = await ir(acao, 'POST', new URLSearchParams(dados).toString());
        }
        if (/__wrong_access_url__/i.test(pag.url)) { log('Login', 'o Controller recusou o endereço ' + BASE + ' (use o nome do servidor, não o IP)'); return null; }
        if (/login-actions/i.test(pag.html)) { log('Login', 'não terminou (ainda na tela de login)'); return null; }
        log('Login', 'OK');
        return pag;
    }

    // guarda entre uma execução e outra: falhas seguidas e quando religou pela última vez
    function lerEstado() {
        try { return JSON.parse(fs.readFileSync(ARQ_ESTADO, 'utf8')); } catch (e) { return { falhas: 0, ultimoReligamento: 0 }; }
    }
    function gravarEstado(estado) {
        try { fs.writeFileSync(ARQ_ESTADO, JSON.stringify(estado)); } catch (e) { log('Estado', 'não consegui gravar: ' + e.message); }
    }

    // o Service Layer está vivo se devolver QUALQUER resposta HTTP (401 sem login também vale) dentro do tempo
    async function serviceLayerResponde() {
        const ini = Date.now();
        try {
            const r = await axios.get(URL_SERVICE_LAYER, { httpsAgent: agente, timeout: SEGUNDOS_TESTE * 1000, validateStatus: () => true });
            return { ok: true, ms: Date.now() - ini, http: r.status };
        } catch (e) {
            return { ok: false, ms: Date.now() - ini, erro: (e && (e.code || e.message)) || String(e) };
        }
    }

    // histórico do monitoramento: uma linha por evento no ARQ_HISTORICO, a MAIS RECENTE NO TOPO
    // (fica com as últimas 3000 linhas, uns 30 dias de medição). A 1ª linha é o cabeçalho.
    const CABECALHO_HIST = '# Histórico de ocorrências de ' + NOME_SL + ' - a mais recente no topo';
    function linhasHistorico() {
        let linhas = [];
        try { linhas = fs.readFileSync(ARQ_HISTORICO, 'utf8').split('\n').filter(Boolean); } catch (e) { return []; }
        // arquivo da versão antiga (sem cabeçalho) estava do mais antigo para o mais recente: inverte uma vez
        if (linhas.length && !linhas[0].startsWith('#')) return linhas.reverse();
        return linhas.filter(l => !l.startsWith('#'));
    }
    function registrar(evento, texto) {
        try {
            // no histórico vai só o resumo: as linhas "Rótulo: valor", sem o "Próximo passo"
            const dados = String(texto || '').split('\n').filter(l => /^[^:]{1,32}: /.test(l) && !/^Próximo passo/i.test(l));
            const linha = hora(Date.now()) + ' | ' + evento + ' | ' + (dados.length ? dados.join(' · ') : String(texto || '').replace(/\n/g, ' · '));
            const pasta = path.dirname(ARQ_HISTORICO);
            if (!fs.existsSync(pasta)) fs.mkdirSync(pasta, { recursive: true });
            fs.writeFileSync(ARQ_HISTORICO, [CABECALHO_HIST, linha].concat(linhasHistorico().slice(0, 2999)).join('\n') + '\n');
        } catch (e) { log('Histórico', 'não consegui gravar: ' + e.message); }
    }
    function historicoRecente(n) {
        return linhasHistorico().slice(0, n);
    }

    // manda o e-mail de aviso (HTML próprio, leve, sem modelo) e grava no histórico; se o e-mail falhar, só registra no log.
    // detalhe: linhas "Rótulo: valor" (viram tabela). secoes: [{ nome, linhas: [texto] }] (erros do Controller, nós...)
    async function avisar(titulo, detalhe, secoes) {
        registrar(titulo, detalhe);
        const tipo = /teste/i.test(titulo) ? 'teste' : /memória elevado/i.test(titulo) ? 'memoria' : /não restabelecida|falha/i.test(titulo) ? 'falhas'
            : /reiniciando/i.test(titulo) ? 'reiniciando' : /restabelecida/i.test(titulo) ? 'restabelecida' : 'indisponivel';
        if (tipo !== 'teste' && !avisoLigado(tipo)) { log('E-mail', 'aviso "' + tipo + '" desligado na configuração: só registrado no histórico'); return; }
        if (!EMAIL_PARA) { log('E-mail', 'sem destinatário (EMAIL_PARA vazio)'); return; }
        const servidor = new URL(BASE).hostname;
        // cor da faixa: vermelho = indisponível/falha, laranja = reiniciando, verde = restabelecida/teste
        const cor = /não|falha|permanece/i.test(titulo) ? '#b91c1c' : /reiniciando/i.test(titulo) ? '#b45309' : /restabelecid|teste/i.test(titulo) ? '#107e3e' : '#b91c1c';
        const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        const td1 = 'padding:5px 12px 5px 0;color:#6b7280;white-space:nowrap;vertical-align:top';
        const td2 = 'padding:5px 0;color:#111827';
        const tabela = (linhasTexto) => '<table style="border-collapse:collapse;width:100%">' + linhasTexto.filter(l => String(l).trim()).map(l => {
            const i = String(l).indexOf(': ');
            return i > 0 && i < 32
                ? '<tr><td style="' + td1 + '">' + esc(l.slice(0, i)) + '</td><td style="' + td2 + '">' + esc(l.slice(i + 2)) + '</td></tr>'
                : '<tr><td colspan="2" style="' + td2 + '">' + esc(l) + '</td></tr>';
        }).join('') + '</table>';
        const titSecao = (t) => '<div style="margin:16px 0 6px;font-size:11px;letter-spacing:.04em;color:#6b7280;text-transform:uppercase">' + esc(t) + '</div>';
        const historico = historicoRecente(8);
        const html = '<div style="font-family:Arial,Helvetica,sans-serif;max-width:600px;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden">'
            + '<div style="background:' + cor + ';color:#fff;padding:14px 18px">'
            + '<div style="font-size:12px;opacity:.85">MONITORAMENTO · SERVIDOR ' + esc(servidor.toUpperCase()) + '</div>'
            + '<div style="font-size:19px;margin-top:2px">' + esc(titulo) + '</div></div>'
            + '<div style="padding:12px 18px 16px;font-size:14px;line-height:1.45">'
            + tabela(String(detalhe).split('\n'))
            + (secoes || []).filter(s => s.linhas && s.linhas.length).map(s => titSecao(s.nome) + tabela(s.linhas)).join('')
            + (historico.length ? titSecao('Histórico de eventos (mais recente primeiro)')
                + '<div style="font-family:Consolas,monospace;font-size:12px;color:#374151;background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:8px 10px">'
                + historico.map(esc).join('<br>') + '</div>' : '')
            + '</div>'
            + '<div style="background:#f9fafb;border-top:1px solid #e5e7eb;padding:10px 18px;font-size:12px;color:#6b7280">'
            + 'Monitoramento da Service Layer · enviado pelo servidor ' + esc(require('os').hostname()) + ' · ' + hora(Date.now()) + ' · histórico completo: ' + esc(ARQ_HISTORICO) + '</div></div>';
        try {
            await sendEmail({ subject: '[Service Layer ' + servidor.toUpperCase() + '] ' + titulo, to: EMAIL_PARA, html });
            log('E-mail', 'enviado: ' + titulo);
        } catch (e) {
            log('E-mail', 'FALHOU: ' + erroTexto(e));
        }
    }

    // mostra o erro inteiro, inclusive o que fica escondido dentro de "error" (mensagem, código, resposta do servidor)
    function erroTexto(e) {
        const abrir = (o, nivel) => {
            if (!o || typeof o !== 'object' || nivel > 3) return o;
            const r = {};
            Object.getOwnPropertyNames(o).forEach(k => { if (k !== 'stack' && k !== 'config' && k !== 'request') r[k] = abrir(o[k], nivel + 1); });
            return r;
        };
        try { return JSON.stringify(abrir(e, 0)).slice(0, 1500); } catch (x) { return String(e); }
    }

    // hora (dd/mm hh:mm:ss) e duração (X min Y s) para os avisos
    const hora = (ms) => new Date(ms).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
    // tempo legível: "45 s", "12 min 5 s", "3 h 20 min", "2 dias 4 h"
    const duracao = (ms) => {
        const s = Math.max(0, Math.round(ms / 1000));
        if (s >= 86400) { const d = Math.floor(s / 86400); return d + (d === 1 ? ' dia ' : ' dias ') + Math.floor((s % 86400) / 3600) + ' h'; }
        if (s >= 3600) return Math.floor(s / 3600) + ' h ' + Math.floor((s % 3600) / 60) + ' min';
        return (s >= 60 ? Math.floor(s / 60) + ' min ' : '') + (s % 60) + ' s';
    };

    // explica o código do erro em português
    function explicarErro(erro) {
        const e = String(erro || '');
        if (/LENTIDAO/i.test(e)) return e.replace('LENTIDAO', 'Lentidão') + ' (resposta acima de ' + SEGUNDOS_LENTO + ' s - serviço sobrecarregado ou travando)';
        if (/ECONNREFUSED/i.test(e)) return e + ' (conexão recusada - serviço parado)';
        if (/ETIMEDOUT|ECONNABORTED|timeout|tempo/i.test(e)) return e + ' (tempo limite esgotado - serviço travado ou lento)';
        if (/ENOTFOUND|EAI_AGAIN/i.test(e)) return e + ' (servidor não localizado na rede)';
        if (/ECONNRESET|socket hang up/i.test(e)) return e + ' (conexão encerrada pelo servidor)';
        return e || 'não informado';
    }

    // informações que o Controller manda pelo websocket, em linhas para o e-mail
    function secoesController(info) {
        const s = [];
        if (info.erros) {
            const erros = info.erros.slice().sort((a, b) => (b.count || 0) - (a.count || 0)).slice(0, 8)
                .map(x => (x.count || 0) + 'x ' + (x.method || '') + ' ' + (x.groupUrl || ''));
            s.push({ nome: 'Erros recentes registrados na Service Layer', linhas: erros.length ? erros : ['Nenhum erro agrupado no Controller'] });
        }
        if (info.nos && info.nos.length) {
            s.push({ nome: 'Nós da Service Layer', linhas: info.nos.map(n => (n.nodeName || 'nó') + ': ' + (n.status || 'sem status') + ' (porta ' + (String(n.workerURL || '').split(':')[2] || '').split('/')[0] + ')') });
        }
        const outros = [];
        if (info.performance) {
            const [cpu, mem] = String(info.performance).split(':');
            outros.push('CPU: ' + (cpu || '-') + ' %');
            outros.push('Memória: ' + (mem || '-') + ' MB');
        }
        if (info.versao) outros.push('Versão: ' + info.versao);
        if (outros.length) s.push({ nome: 'Servidor', linhas: outros });
        return s;
    }

    // resumo das medições de memória do histórico: por dia, mínimo / média / máximo e a hora do pico (para definir ALERTA_GB e LIMITE_GB)
    function resumoMemoria() {
        // do mais antigo para o mais recente (o arquivo guarda o mais recente no topo)
        const linhas = linhasHistorico().reverse();
        if (!linhas.length) { log('Memória', 'histórico ainda não existe'); return; }
        const dias = {};
        linhas.forEach(l => {
            const m = l.match(/^(\d{2}\/\d{2}),? (\d{2}:\d{2}):\d{2} \| Medição \| Memória: ([\d,.]+) GB/);
            if (!m) return;
            const v = parseFloat(m[3].replace(',', '.'));
            const d = dias[m[1]] || (dias[m[1]] = { n: 0, soma: 0, min: v, max: v, horaMax: m[2] });
            d.n++; d.soma += v;
            if (v < d.min) d.min = v;
            if (v > d.max) { d.max = v; d.horaMax = m[2]; }
        });
        const chaves = Object.keys(dias);
        if (!chaves.length) { log('Memória', 'nenhuma medição no histórico ainda'); return; }
        const f = (v) => v.toFixed(2).replace('.', ',') + ' GB';
        let geralMax = 0;
        chaves.forEach(k => {
            const d = dias[k];
            if (d.max > geralMax) geralMax = d.max;
            log('Memória ' + k, d.n + ' medições · mínimo ' + f(d.min) + ' · média ' + f(d.soma / d.n) + ' · máximo ' + f(d.max) + ' às ' + d.horaMax);
        });
        log('Memória (sugestão)', 'maior valor medido: ' + f(geralMax) + ' -> ALERTA_GB perto de ' + Math.ceil(geralMax * 1.3) + ' e LIMITE_GB perto de ' + Math.ceil(geralMax * 1.5)
            + ' (confirmar com a RAM do servidor)');
    }

    // teste do e-mail: manda um aviso de teste igual aos de verdade
    async function testarEmail() {
        await avisar('teste de e-mail', 'Teste do aviso de monitoramento.\nNenhum comando foi enviado à Service Layer.');
    }

    // procura uma chave em qualquer nível da mensagem do Controller
    function acharChave(o, chave) {
        if (!o || typeof o !== 'object') return undefined;
        if (chave in o) return o[chave];
        for (const v of Object.values(o)) { const r = acharChave(v, chave); if (r !== undefined) return r; }
        return undefined;
    }
    const resumo = (texto, max) => {
        try { return JSON.stringify(JSON.parse(texto), (k, v) => /pass|token|cookie|secret/i.test(k) ? '***' : v).slice(0, max || 800); }
        catch (e) { return String(texto).slice(0, max || 800); }
    };

    // ouve o websocket por alguns segundos; para antes se pararQuando(texto) devolver true
    function ouvir(ws, ms, aCada, pararQuando) {
        return new Promise(fim => {
            const t = setTimeout(fim, ms);
            ws.aoReceber(texto => { aCada(texto); if (pararQuando && pararQuando(texto)) { clearTimeout(t); fim(); } });
            ws.aoFechar(() => { clearTimeout(t); fim(); });
        });
    }

    // uma verificação. Devolve 'ok' quando está tudo bem (o laço continua verificando); qualquer outro valor encerra a execução.
    async function principal(primeira) {
        if (['monitorar', 'status', 'teste_restart', 'teste_email', 'memoria'].indexOf(MODO) === -1) {
            log('Monitoramento', 'MODO inválido: ' + MODO + ' (use monitorar, status, teste_email, memoria ou teste_restart). Nada foi feito.');
            return 'invalido';
        }
        if (primeira) {
            log('Monitoramento', 'modo ' + MODO + ' · usuário Windows ' + (process.env.USERNAME || '?') + ' · Node ' + process.version + ' · Service Layer ' + URL_SERVICE_LAYER);
            log('Tempos', 'verifica a cada ' + SEGUNDOS_ENTRE_VERIFICACOES + ' s por ' + SEGUNDOS_POR_EXECUCAO + ' s · sem resposta ' + SEGUNDOS_TESTE + ' s (reinicia na ' + FALHAS_SEM_RESPOSTA + 'ª) · lenta acima de ' + SEGUNDOS_LENTO + ' s (reinicia na ' + FALHAS_LENTIDAO + 'ª) · confirma ' + SEGUNDOS_CONFIRMAR + ' s x' + COMANDOS_POR_EXECUCAO + ' · espera voltar ' + MINUTOS_ESPERAR_VOLTAR + ' min · memória a cada ' + MINUTOS_MEDIR_MEMORIA + ' min (alerta ' + (ALERTA_GB || 'off') + ' / limite ' + (LIMITE_GB || 'off') + ' GB, ' + JANELA_REINICIO_MEMORIA + ') · logs ' + DIAS_LOG + ' dias');
        }
        if (MODO === 'teste_email') {
            await testarEmail();
            return;
        }
        if (MODO === 'memoria') {
            resumoMemoria();
            return;
        }
        const estado = lerEstado();

        if (MODO === 'monitorar') {
            // reinício em andamento (outra execução cuidando): não verifica nem avisa de novo
            if (estado.reiniciandoDesde && Date.now() - estado.reiniciandoDesde < (MINUTOS_ESPERAR_VOLTAR + 3) * 60000) {
                log('Monitoramento', 'reinício em andamento desde ' + hora(estado.reiniciandoDesde) + '; aguardando');
                return 'aguardando';
            }
            const t = await serviceLayerResponde();
            // respondeu, mas devagar demais: trata como falha (costuma ser o começo de um travamento)
            if (t.ok && SEGUNDOS_LENTO > 0 && t.ms > SEGUNDOS_LENTO * 1000) {
                log('Service Layer', 'LENTA: respondeu em ' + t.ms + ' ms (limite ' + SEGUNDOS_LENTO + ' s)');
                t.ok = false;
                t.erro = 'LENTIDAO';
            }
            if (t.ok) {
                // só avisa a volta se o "indisponível" chegou a ser enviado
                if (estado.avisoIndisponivel && estado.primeiraFalha) {
                    const reiniciouAntes = estado.ultimoReligamento && estado.ultimoReligamento >= estado.primeiraFalha;
                    const msg = (reiniciouAntes ? 'A Service Layer voltou a responder após o reinício automático. Nenhuma ação necessária.'
                        : 'A Service Layer voltou a responder sem necessidade de reinício. Nenhuma ação necessária.')
                        + '\nFicou fora: ' + duracao(Date.now() - estado.primeiraFalha) + ' (de ' + hora(estado.primeiraFalha) + ' até ' + hora(Date.now()) + ')'
                        + '\nÚltimo erro: ' + explicarErro(estado.ultimoErro)
                        + '\nVerificação: HTTP ' + t.http + ' em ' + t.ms + ' ms (normal)';
                    log('Service Layer', msg);
                    await avisar(reiniciouAntes ? 'Service Layer restabelecida' : 'Service Layer restabelecida (sem reinício)', msg);
                }
                estado.falhas = 0;
                estado.primeiraFalha = 0;
                estado.foraContinuoDesde = 0;
                estado.ultimoAvisoLongo = 0;
                estado.tentativas = 0;
                estado.avisoIndisponivel = false;
                gravarEstado(estado);
                log('Service Layer', 'ok (HTTP ' + t.http + ' em ' + t.ms + ' ms) · verificação ' + (++numeroVerificacao));
                // de tempos em tempos mede a memória no Controller (alerta / reinício preventivo)
                if (MINUTOS_MEDIR_MEMORIA > 0 && Date.now() - (estado.ultimaMedicao || 0) >= MINUTOS_MEDIR_MEMORIA * 60000) {
                    // continua verificando depois de medir, a não ser que a medição tenha reiniciado
                    if (await medirMemoria(estado)) return 'medicao';
                }
                return 'ok';
            }
            estado.falhas = (estado.falhas || 0) + 1;
            if (estado.falhas === 1 || !estado.primeiraFalha) { estado.primeiraFalha = Date.now(); estado.tentativas = 0; estado.avisoIndisponivel = false; }
            // início da queda contínua: só zera quando a Service Layer volta a responder (os reinícios não zeram)
            if (!estado.foraContinuoDesde) estado.foraContinuoDesde = estado.primeiraFalha;
            estado.ultimoErro = t.erro + ' (' + t.ms + ' ms)';
            gravarEstado(estado);
            log('Service Layer', 'NÃO RESPONDEU (' + estado.falhas + 'ª vez seguida, ' + t.ms + ' ms): ' + t.erro);
            // parada: age na 1ª; lenta: só na 3ª seguida (oscilação curta não avisa nem reinicia)
            const limiteFalhas = t.erro === 'LENTIDAO' ? FALHAS_LENTIDAO : FALHAS_SEM_RESPOSTA;
            if (estado.falhas < limiteFalhas) return 'contando';   // lentidão conta 1 por execução
            if (!estado.avisoIndisponivel) {
                estado.avisoIndisponivel = true;
                gravarEstado(estado);
                // em paralelo: o reinício não espera o e-mail sair
                avisoPendente = avisar('Service Layer indisponível', (t.erro === 'LENTIDAO'
                    ? 'A Service Layer está respondendo com lentidão acima do limite (' + SEGUNDOS_LENTO + ' s), o que indica sobrecarga ou travamento.'
                    : 'A Service Layer está fora do ar e não responde às requisições.')
                    + '\nDetectado em: ' + hora(estado.primeiraFalha)
                    + '\nTempo de indisponibilidade: ' + duracao(Date.now() - estado.primeiraFalha)
                    + '\nVerificações com falha: ' + estado.falhas + (estado.falhas > 1 ? ' consecutivas' : '')
                    + '\nErro: ' + explicarErro(estado.ultimoErro)
                    + '\nPróximo passo: ' + (REINICIA ? 'O reinício automático está sendo iniciado pelo Service Layer Controller.'
                        : 'Reinício automático DESLIGADO para esta Service Layer: reiniciar manualmente pelo Controller ou acionar o NOC.'));
            }
            // fora sem parar há muito tempo (ex.: Service Layer desativada e esquecida no cadastro):
            // para de reiniciar e avisa no máximo 1 vez por dia; volta ao normal sozinho quando ela responder
            const foraHa = Date.now() - estado.foraContinuoDesde;
            if (HORAS_PARAR_REINICIO > 0 && foraHa >= HORAS_PARAR_REINICIO * 3600000) {
                log('Monitoramento', 'fora sem parar há ' + duracao(foraHa) + ' (limite ' + HORAS_PARAR_REINICIO + ' h): reinício automático suspenso, aviso 1 vez por dia');
                if (Date.now() - (estado.ultimoAvisoLongo || 0) >= 24 * 3600000) {
                    estado.ultimoAvisoLongo = Date.now();
                    gravarEstado(estado);
                    await avisar('Service Layer fora há muito tempo - confirmar se foi desativada', 'A Service Layer está sem responder há ' + duracao(foraHa) + '.'
                        + '\nFora desde: ' + hora(estado.foraContinuoDesde)
                        + '\nÚltimo erro: ' + explicarErro(estado.ultimoErro)
                        + '\nReinício automático: suspenso após ' + HORAS_PARAR_REINICIO + ' h fora sem parar (volta sozinho quando a Service Layer responder)'
                        + '\nPróximo passo: Se a Service Layer foi desativada, remova-a do monitoramento (tela de configuração, aba Service Layers, botão −, Salvar). Caso contrário, acionar o NOC.');
                }
                await avisoPendente;
                return 'fora_longo';
            }
            const minutos = (Date.now() - (estado.ultimoReligamento || 0)) / 60000;
            if (minutos < MINUTOS_ENTRE_RELIGAMENTOS) {
                log('Monitoramento', 'religou há ' + Math.round(minutos) + ' min; espera ' + MINUTOS_ENTRE_RELIGAMENTOS + ' min entre religamentos');
                // avisa de novo no máximo a cada repetir_min (padrão 30 min), sem encher a caixa
                if (Date.now() - (estado.ultimoAvisoPermanece || 0) >= REPETIR_MS) {
                    estado.ultimoAvisoPermanece = Date.now();
                    gravarEstado(estado);
                    await avisar('Service Layer permanece indisponível - acionar o NOC', 'O reinício automático já foi executado e a Service Layer continua sem responder.'
                        + '\nFora desde: ' + hora(estado.primeiraFalha) + ' (' + duracao(Date.now() - estado.primeiraFalha) + ')'
                        + '\nÚltimo reinício automático: há ' + Math.round(minutos) + ' min'
                        + '\nÚltimo erro: ' + explicarErro(estado.ultimoErro)
                        + '\nPróximo passo: Acionar o NOC. Um novo reinício automático só ocorre ' + MINUTOS_ENTRE_RELIGAMENTOS + ' min após o anterior.');
                }
                return;
            }
        }

        // reinício automático desligado para esta Service Layer: só avisa (repete o aviso no intervalo configurado)
        if (MODO === 'monitorar' && !REINICIA) {
            log('Monitoramento', 'reinício automático desligado para esta Service Layer: só aviso');
            if (Date.now() - (estado.ultimoAvisoPermanece || 0) >= REPETIR_MS && Date.now() - estado.primeiraFalha >= REPETIR_MS) {
                estado.ultimoAvisoPermanece = Date.now();
                gravarEstado(estado);
                await avisar('Service Layer permanece indisponível - acionar o NOC', 'A Service Layer continua sem responder e o reinício automático está desligado para ela.'
                    + '\nFora desde: ' + hora(estado.primeiraFalha) + ' (' + duracao(Date.now() - estado.primeiraFalha) + ')'
                    + '\nÚltimo erro: ' + explicarErro(estado.ultimoErro)
                    + '\nPróximo passo: Reiniciar manualmente pelo Controller (' + BASE + ') ou acionar o NOC.');
            }
            await avisoPendente;
            return 'sem_reinicio';
        }

        // entra no Controller e lê o status (rápido: só espera saber se está parada ou rodando)
        const ctl = await conectarController(MODO !== 'status');
        if (!ctl) {
            if (MODO !== 'status' && podeAvisarFalhaReinicio(estado)) await avisar('Falha no reinício automático - sem acesso ao Controller', 'A Service Layer está fora do ar e o monitoramento não conseguiu acessar o Service Layer Controller (login recusado ou incompleto).'
                + '\nÚltima falha da Service Layer: ' + explicarErro(estado.ultimoErro)
                + '\nPróximo passo: Reiniciar manualmente pelo Controller (' + BASE + ') ou acionar o NOC. Verificar o usuário e a senha do Controller na tela de configuração.');
            await avisoPendente;
            return;
        }
        if (MODO === 'status') {
            const m = lerPerformance(ctl.info.performance);
            if (m) log('Controller', 'memória ' + gb(m.memMB) + ' · CPU ' + m.cpu + ' %');
            ctl.ws.fechar();
            log('Fim', 'nenhum comando enviado');
            return;
        }
        await reiniciar(estado, ctl, 'falha');
        await avisoPendente;
    }

    // número da verificação dentro da execução (para o log)
    let numeroVerificacao = 0;

    // e-mail que ficou enviando em paralelo (aguardado no fim da execução)
    let avisoPendente = Promise.resolve();

    // guarda o que o Controller informa (erros, nós, CPU/memória, versão)
    function capturarInfo(d, info) {
        if (d.groupedErrorLogs) info.erros = d.groupedErrorLogs;
        if (d.loadbalance && d.loadbalance.nodes) info.nos = d.loadbalance.nodes;
        if (d.performance) info.performance = d.performance;
        if (d.version) info.versao = d.version + ' SP' + (d.pack || '') + ' build ' + (d.build || '');
    }

    // aviso de falha no reinício: no máximo 1 a cada 30 min (o monitoramento continua tentando a cada execução)
    function podeAvisarFalhaReinicio(estado) {
        if (Date.now() - (estado.ultimoAvisoFalhaReinicio || 0) < REPETIR_MS) { log('E-mail', 'falha no reinício já avisada há menos de ' + (REPETIR_MS / 60000) + ' min'); return false; }
        estado.ultimoAvisoFalhaReinicio = Date.now();
        gravarEstado(estado);
        return true;
    }

    // login no Controller + websocket + leitura do status e das informações (erros, nós, CPU/memória, versão) - no máximo 10 s
    // rapido = para assim que souber se está rodando (o resto das informações chega depois, enquanto reinicia)
    async function conectarController(rapido) {
        const pag = await entrar();
        if (!pag) return null;
        const ws = await abrirWebSocket(new URL('/ServiceLayerController/ws', pag.url).href);
        log('Controller', 'websocket conectado');
        let rodando;
        const info = {};
        await ouvir(ws, 10000, texto => {
            log('Controller (detalhe)', resumo(texto, 4000));
            let d;
            try { d = JSON.parse(texto); } catch (e) { return; }
            const r = acharChave(d, 'running');
            if (r !== undefined) rodando = r;
            capturarInfo(d, info);
        }, () => rodando !== undefined && (rapido || (info.erros !== undefined && info.performance !== undefined)));
        log('Controller', resumoController(rodando, info));
        return { ws, rodando, info };
    }

    // uma linha com o que o Controller informou: estado, memória, CPU, nós e erros
    function resumoController(rodando, info) {
        const partes = ['status: ' + (rodando === undefined ? 'não informado' : rodando ? 'Running' : 'Stopped')];
        const m = lerPerformance(info.performance);
        if (m) partes.push('memória ' + gb(m.memMB), 'CPU ' + m.cpu + ' %');
        if (info.nos && info.nos.length) {
            const ok = info.nos.filter(n => /ok/i.test(String(n.status || ''))).length;
            partes.push(info.nos.length + ' nós (' + ok + ' Init Ok)');
        }
        if (info.erros) partes.push(info.erros.reduce((s, x) => s + (x.count || 0), 0) + ' erros agrupados');
        return partes.join(' · ');
    }
    // "performance" do Controller vem como "cpu:memória em MB" (ex.: "0.1:5416.25")
    function lerPerformance(p) {
        const [cpu, mem] = String(p || '').split(':');
        const memMB = parseFloat(mem);
        if (!memMB) return null;
        return { cpu: cpu || '-', memMB };
    }
    const gb = (mb) => (mb / 1024).toFixed(2).replace('.', ',') + ' GB';

    // janela "hh:mm-hh:mm" (pode virar a meia-noite, ex.: 22:00-05:00)
    function dentroDaJanela() {
        const m = String(JANELA_REINICIO_MEMORIA || '').match(/^(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})$/);
        if (!m) return true;
        const ini = (+m[1]) * 60 + (+m[2]);
        const fim = (+m[3]) * 60 + (+m[4]);
        const agora = new Date().getHours() * 60 + new Date().getMinutes();
        return ini <= fim ? (agora >= ini && agora < fim) : (agora >= ini || agora < fim);
    }

    // mede a memória da Service Layer no Controller; alerta acima de ALERTA_GB e reinicia acima de LIMITE_GB (só na janela)
    async function medirMemoria(estado) {
        estado.ultimaMedicao = Date.now();
        gravarEstado(estado);
        let ctl;
        try { ctl = await conectarController(); } catch (e) { log('Memória', 'não consegui medir: ' + erroTexto(e)); return; }
        if (!ctl) { log('Memória', 'não consegui entrar no Controller para medir'); return; }
        const m = lerPerformance(ctl.info.performance);
        if (!m) { ctl.ws.fechar(); log('Memória', 'o Controller não informou a memória'); return; }
        const memGB = m.memMB / 1024;
        registrar('Medição', 'Memória: ' + gb(m.memMB) + ' · CPU: ' + m.cpu + ' %');
        log('Memória', gb(m.memMB) + ' · CPU ' + m.cpu + ' % (alerta ' + (ALERTA_GB || 'desligado') + ' / reinício ' + (LIMITE_GB || 'desligado') + ')');

        const acimaLimite = LIMITE_GB > 0 && memGB >= LIMITE_GB;
        const acimaAlerta = ALERTA_GB > 0 && memGB >= ALERTA_GB;
        const minutos = (Date.now() - (estado.ultimoReligamento || 0)) / 60000;
        // conta as medições seguidas acima do limite: só reinicia na MEDICOES_MEMORIA-ésima
        estado.memAcima = acimaLimite ? (estado.memAcima || 0) + 1 : 0;
        gravarEstado(estado);
        if (acimaLimite) log('Memória', 'acima do limite: ' + estado.memAcima + 'ª medição seguida (reinicia na ' + MEDICOES_MEMORIA + 'ª)');
        if (REINICIA && acimaLimite && estado.memAcima >= MEDICOES_MEMORIA && dentroDaJanela() && minutos >= MINUTOS_ENTRE_RELIGAMENTOS) {
            m.medicoes = estado.memAcima;
            estado.memAcima = 0;
            await reiniciar(estado, ctl, 'memoria', m);
            return true;
        }
        ctl.ws.fechar();
        // alerta no máximo 1 vez por hora
        if ((acimaLimite || acimaAlerta) && Date.now() - (estado.ultimoAlertaMemoria || 0) >= ALERTA_MEMORIA_MS) {
            estado.ultimoAlertaMemoria = Date.now();
            gravarEstado(estado);
            await avisar('Service Layer com uso de memória elevado', 'A Service Layer está respondendo, mas o uso de memória está acima do limite de alerta.'
                + '\nMemória em uso: ' + gb(m.memMB)
                + '\nCPU: ' + m.cpu + ' %'
                + '\nLimite de alerta: ' + (ALERTA_GB > 0 ? ALERTA_GB + ' GB' : 'desativado')
                + '\nLimite para reinício: ' + (LIMITE_GB > 0 ? LIMITE_GB + ' GB' : 'desativado')
                + '\nJanela de reinício: ' + JANELA_REINICIO_MEMORIA
                + '\nPróximo passo: ' + (acimaLimite
                    ? (dentroDaJanela() ? 'Reinício preventivo aguardando o intervalo mínimo de ' + MINUTOS_ENTRE_RELIGAMENTOS + ' min entre reinícios.'
                        : 'O reinício preventivo por memória ocorre somente na janela ' + JANELA_REINICIO_MEMORIA + '.')
                    : 'Acompanhar. O reinício preventivo ocorre acima de ' + (LIMITE_GB > 0 ? LIMITE_GB + ' GB' : '(limite desativado)') + ', na janela ' + JANELA_REINICIO_MEMORIA + '.'),
                secoesController(ctl.info));
        }
    }

    // reinicia pela conexão já aberta com o Controller e acompanha até a Service Layer responder.
    // motivo 'falha' = fora do ar; 'memoria' = reinício preventivo por uso de memória
    async function reiniciar(estado, ctl, motivo, mem) {
        const { ws, rodando, info } = ctl;
        const porMemoria = motivo === 'memoria';
        // parada (Controller diz Stopped ou a conexão foi recusada) = start; travada/lenta/memória = restart
        const recusou = /ECONNREFUSED/i.test(String(estado.ultimoErro || ''));
        const comando = !porMemoria && (rodando === false || (rodando === undefined && recusou)) ? 'start' : 'restart';
        log('Controller', 'ENVIANDO "' + comando + '"' + (porMemoria ? ' (memória ' + gb(mem.memMB) + ')' : ''));
        ws.enviar(comando);
        const enviadoAs = Date.now();
        const foraDesde = porMemoria ? enviadoAs : (estado.primeiraFalha || enviadoAs);
        const falhasAntes = estado.falhas || 0;
        const statusAntes = rodando === undefined ? 'não informado' : rodando ? (porMemoria ? 'em execução' : 'em execução, sem responder (travada)') : 'parada';
        const acao = porMemoria ? 'restart (reinício preventivo por uso de memória)'
            : comando === 'start' ? 'start (inicialização do serviço parado)' : 'restart (reinício do serviço travado)';
        // grava já: protege contra outra execução começando no meio do reinício
        estado.ultimoReligamento = Date.now();
        estado.reiniciandoDesde = Date.now();
        estado.falhas = 0;
        estado.tentativas = (estado.tentativas || 0) + 1;
        gravarEstado(estado);
        // ouve até o Controller confirmar: ação de conclusão (afterStart / forceRestartFinish) ou running false -> true
        let parou = comando === 'start';
        let ligou = false;
        let ultimoRunning = rodando;
        const ouvirConfirmacao = (ms) => ouvir(ws, ms, texto => {
            let d;
            try { d = JSON.parse(texto); } catch (e) { return; }
            capturarInfo(d, info);
            const acaoCtl = String(d.action || '');
            const r = acharChave(d, 'running');
            if (!acaoCtl && r === undefined) return;
            log('Controller (resposta)', resumo(texto));
            if (r !== undefined) ultimoRunning = r;
            if (/^before/i.test(acaoCtl) || r === false) parou = true;
            if (/afterStart|Finish|afterRestart/i.test(acaoCtl)) ligou = true;
            if (r === true && parou) ligou = true;
        }, () => ligou);
        await ouvirConfirmacao(SEGUNDOS_CONFIRMAR * 1000);
        // insiste na MESMA execução (a próxima pode ser barrada pelo DIS quando a conexão expirar)
        for (let n = 2; n <= COMANDOS_POR_EXECUCAO && !ligou; n++) {
            if (ultimoRunning === true) break;   // rodando: o teste de resposta abaixo decide
            log('Controller', 'sem confirmação; ENVIANDO \"start\" (' + n + 'ª vez nesta execução)');
            registrar('Novo comando start', 'Comando: ' + n + 'ª vez nesta execução · Estado no Controller: ' + (ultimoRunning === false ? 'parada' : 'não informado'));
            ws.enviar('start');
            parou = true;
            await ouvirConfirmacao(SEGUNDOS_CONFIRMAR * 1000);
        }
        ws.fechar();
        log('Controller', ligou ? 'status: Running' : 'não confirmou Running');

        // e-mail 'reiniciando' (depois do comando, com as informações do Controller) e só na 1ª tentativa da ocorrência
        let envioAviso = avisoPendente;
        if (!porMemoria && estado.tentativas > 1) {
            registrar('Nova tentativa de reinício', 'Tentativa: ' + estado.tentativas + 'ª · Ação executada: ' + acao + ' · Fora desde: ' + hora(foraDesde));
        } else if (porMemoria) {
            envioAviso = avisoPendente.then(() => avisar('Service Layer reiniciando', 'A Service Layer atingiu o limite de memória definido. O reinício preventivo foi iniciado pelo Service Layer Controller.'
                + '\nMemória em uso: ' + gb(mem.memMB)
                + '\nLimite para reinício: ' + LIMITE_GB + ' GB'
                + '\nMedições seguidas acima do limite: ' + (mem.medicoes || MEDICOES_MEMORIA)
                + '\nCPU: ' + mem.cpu + ' %'
                + '\nJanela permitida: ' + JANELA_REINICIO_MEMORIA
                + '\nAção executada: ' + acao
                + '\nInício do reinício: ' + hora(enviadoAs)
                + '\nPróximo passo: Aguardando o restabelecimento (até ' + MINUTOS_ESPERAR_VOLTAR + ' min). Um novo aviso será enviado ao concluir.',
                secoesController(info)));
        } else {
            envioAviso = avisoPendente.then(() => avisar('Service Layer reiniciando', 'A Service Layer permanece fora do ar. O reinício automático foi iniciado pelo Service Layer Controller.'
                + '\nFora desde: ' + hora(foraDesde) + ' (' + duracao(Date.now() - foraDesde) + ')'
                + '\nVerificações sem resposta: ' + falhasAntes + ' consecutivas'
                + '\nÚltimo erro: ' + explicarErro(estado.ultimoErro)
                + '\nEstado no Controller: ' + statusAntes
                + '\nAção executada: ' + acao
                + '\nInício do reinício: ' + hora(enviadoAs)
                + '\nPróximo passo: Aguardando o restabelecimento (até ' + MINUTOS_ESPERAR_VOLTAR + ' min). Um novo aviso será enviado ao concluir.',
                secoesController(info)));
        }
        // acompanha até a Service Layer voltar
        const ini = Date.now();
        while (Date.now() - ini < MINUTOS_ESPERAR_VOLTAR * 60000) {
            const t = await serviceLayerResponde();
            if (t.ok) {
                log('Service Layer', 'VOLTOU ' + Math.round((Date.now() - ini) / 1000) + ' s depois do ' + comando + ' (HTTP ' + t.http + ')');
                await envioAviso;   // garante a ordem dos e-mails: reiniciando antes de restabelecida
                await avisar('Service Layer restabelecida',
                    (porMemoria ? 'A Service Layer foi reiniciada preventivamente e está respondendo normalmente. Nenhuma ação necessária.'
                        : 'A Service Layer foi reiniciada automaticamente e está respondendo normalmente. Nenhuma ação necessária.')
                    + '\n' + (porMemoria ? 'Indisponibilidade' : 'Fora do ar') + ': ' + duracao(Date.now() - foraDesde) + ' (de ' + hora(foraDesde) + ' até ' + hora(Date.now()) + ')'
                    + (porMemoria ? '\nMotivo: uso de memória de ' + gb(mem.memMB) + ' (limite ' + LIMITE_GB + ' GB)' : '\nFalha detectada: ' + explicarErro(estado.ultimoErro))
                    + '\nEstado antes do reinício: ' + statusAntes
                    + '\nAção executada: ' + acao + ' às ' + hora(enviadoAs)
                    + '\nTempo de restabelecimento: ' + Math.round((Date.now() - ini) / 1000) + ' s após o comando'
                    + '\nVerificação: HTTP ' + t.http + ' (resposta esperada sem autenticação)');
                estado.primeiraFalha = 0;
                estado.foraContinuoDesde = 0;
                estado.ultimoAvisoLongo = 0;
                estado.reiniciandoDesde = 0;
                estado.tentativas = 0;
                estado.avisoIndisponivel = false;
                gravarEstado(estado);
                return;
            }
            log('Service Layer', 'ainda fora: ' + t.erro);
            await new Promise(r => setTimeout(r, 3000));
        }
        log('Service Layer', 'NÃO voltou em ' + MINUTOS_ESPERAR_VOLTAR + ' min - chamar o NOC');
        await envioAviso;
        // continua contando como fora: a próxima execução tenta de novo; o e-mail abaixo sai no máximo a cada 30 min
        estado.reiniciandoDesde = 0;
        estado.falhas = Math.max(FALHAS_SEM_RESPOSTA, FALHAS_LENTIDAO);
        const avisarNaoVoltou = Date.now() - (estado.ultimoAvisoPermanece || 0) >= REPETIR_MS;
        if (avisarNaoVoltou) estado.ultimoAvisoPermanece = Date.now();
        gravarEstado(estado);
        if (!avisarNaoVoltou) { registrar('Não restabelecida', 'Tentativa: ' + (estado.tentativas || 1) + 'ª · Fora desde: ' + hora(foraDesde)); return; }
        await avisar('Service Layer não restabelecida - acionar o NOC', 'O reinício automático foi executado, mas a Service Layer não voltou a responder em ' + MINUTOS_ESPERAR_VOLTAR + ' min.'
            + '\n' + (porMemoria ? 'Indisponível desde' : 'Fora desde') + ': ' + hora(foraDesde) + ' (' + duracao(Date.now() - foraDesde) + ')'
            + '\nAção executada: ' + acao + ' às ' + hora(enviadoAs)
            + '\nEstado no Controller após o comando: ' + (ligou ? 'em execução' : 'início não confirmado')
            + (porMemoria ? '' : '\nÚltimo erro: ' + explicarErro(estado.ultimoErro))
            + '\nPróximo passo: Acionar o NOC para verificação do servidor ' + new URL(BASE).hostname + '.', secoesController(info));
    }
    // websocket com o https do Node (aceita o certificado próprio do Controller e leva os cookies do login)
    function abrirWebSocket(url) {
        const crypto = require('crypto');
        const u = new URL(url);
        return new Promise((ok, falha) => {
            const req = https.request({
                host: u.hostname, port: u.port, path: u.pathname, method: 'GET', rejectUnauthorized: false,
                headers: {
                    Connection: 'Upgrade', Upgrade: 'websocket', 'Sec-WebSocket-Version': '13',
                    'Sec-WebSocket-Key': crypto.randomBytes(16).toString('base64'),
                    Origin: u.protocol + '//' + u.host, Cookie: cabecalhoCookie()
                }
            });
            req.setTimeout(20000, () => req.destroy(new Error('tempo esgotado ao conectar no websocket')));
            req.on('response', r => falha(new Error('websocket recusado: HTTP ' + r.statusCode)));
            req.on('error', falha);
            req.on('upgrade', (res, socket, inicio) => {
                let buf = inicio && inicio.length ? Buffer.from(inicio) : Buffer.alloc(0);
                let partes = [];
                let ouvinte = () => {};
                let aoFechar = () => {};
                // lê os quadros do websocket (servidor manda sem máscara)
                const ler = () => {
                    while (buf.length >= 2) {
                        const fin = (buf[0] & 0x80) !== 0;
                        const op = buf[0] & 0x0f;
                        let tam = buf[1] & 0x7f;
                        let pos = 2;
                        if (tam === 126) { if (buf.length < 4) return; tam = buf.readUInt16BE(2); pos = 4; }
                        else if (tam === 127) { if (buf.length < 10) return; tam = Number(buf.readBigUInt64BE(2)); pos = 10; }
                        if (buf.length < pos + tam) return;
                        const dado = buf.subarray(pos, pos + tam);
                        buf = buf.subarray(pos + tam);
                        if (op === 8) { socket.end(); return; }
                        if (op === 9) { quadro(10, dado); continue; }
                        if (op === 1 || op === 0) { partes.push(dado); if (fin) { ouvinte(Buffer.concat(partes).toString('utf8')); partes = []; } }
                        if (op === 2 && fin) ouvinte('[arquivo binário de ' + dado.length + ' bytes]');
                    }
                };
                // envia quadro de controle (pong / fechar), com máscara como o padrão exige
                const quadro = (op, dado) => {
                    const mascara = crypto.randomBytes(4);
                    const corpo = Buffer.from(dado || []);
                    const m = Buffer.alloc(corpo.length);
                    for (let i = 0; i < corpo.length; i++) m[i] = corpo[i] ^ mascara[i % 4];
                    socket.write(Buffer.concat([Buffer.from([0x80 | op, 0x80 | corpo.length]), mascara, m]));
                };
                socket.on('data', d => { buf = Buffer.concat([buf, d]); ler(); });
                socket.on('close', () => aoFechar());
                socket.on('error', () => aoFechar());
                ok({
                    status: res.statusCode,
                    aoReceber: f => { ouvinte = f; ler(); },
                    aoFechar: f => { aoFechar = f; },
                    enviar: (texto) => quadro(1, Buffer.from(String(texto), 'utf8')),
                    fechar: () => { try { quadro(8, Buffer.from([0x03, 0xe8])); } catch (e) { } setTimeout(() => socket.destroy(), 300); }
                });
            });
            req.end();
        });
    }

    async function executar() {
    try {
        // fica verificando dentro da execução: um GET a cada SEGUNDOS_ENTRE_VERIFICACOES, por até SEGUNDOS_POR_EXECUCAO
        // (parada é percebida em segundos, não só no próximo agendamento)
        const inicioExecucao = Date.now();
        let primeira = true;
        let verificacoes = 0;
        while (true) {
            const r = await principal(primeira);
            primeira = false;
            if (r === 'ok') verificacoes++;
            if (r !== 'ok' || MODO !== 'monitorar') break;
            if (Date.now() - inicioExecucao + SEGUNDOS_ENTRE_VERIFICACOES * 1000 > SEGUNDOS_POR_EXECUCAO * 1000) break;
            await new Promise(res => setTimeout(res, SEGUNDOS_ENTRE_VERIFICACOES * 1000));
        }
        if (verificacoes) log('Fim', verificacoes + ' verificações ok em ' + Math.round((Date.now() - inicioExecucao) / 1000) + ' s');
    } catch (e) {
        log('Monitoramento', 'ERRO: ' + ((e && e.message) || String(e)));
        await avisoPendente;
        if (MODO !== 'status' && podeAvisarFalhaReinicio(lerEstado())) await avisar('Falha no reinício automático', 'O monitoramento encontrou um erro e não concluiu o reinício da Service Layer.'
            + '\nErro: ' + explicarErro((e && (e.code || e.message)) || String(e))
            + '\nOnde: ao acessar o Service Layer Controller (' + BASE + ')'
            + '\nPróximo passo: Verificar a disponibilidade da Service Layer; se indisponível, reiniciar pelo Controller ou acionar o NOC.');
    }
    }

    return { executar };
}

// quais Service Layers: a da linha de comando (ex.: node monitoramento_sl.js status NOME) ou todas
const ALVOS = process.argv[3] ? SERVICOS.filter(s => s.nome === process.argv[3])
    : (MODO === 'teste_email' ? SERVICOS.slice(0, 1) : SERVICOS);
// logs\geral recebe só erros; a linha de início de cada execução vai só para a tela
(async () => {
    if (ERRO_CONFIG) { log('Monitoramento', 'ERRO: config.json com defeito (' + ERRO_CONFIG + '). Abra a tela de configuração e salve de novo.'); return; }
    if (!SERVICOS.length) { log('Monitoramento', 'nenhuma Service Layer cadastrada: abra a tela de configuração e cadastre (aba Service Layers).'); return; }
    if (!ALVOS.length) { log('Monitoramento', 'Service Layer ' + process.argv[3] + ' não encontrada no config.json.'); return; }
    if (ALVOS.length > 1) process.stdout.write(new Date().toLocaleTimeString('pt-BR') + ' Monitoramento: modo ' + MODO + ' · ' + ALVOS.length + ' Service Layers: ' + ALVOS.map(s => s.nome).join(', ') + '\n');
    await Promise.all(ALVOS.map(s => criarMonitor(s, SERVICOS.indexOf(s)).executar()));
})().catch(e => log('Monitoramento', 'ERRO: ' + ((e && e.message) || String(e))));