// SPS Monitoramento de Serviços - MOTOR DOS SERVIÇOS DO WINDOWS (roda junto com o da Service Layer, a cada execução da tarefa).
// Não mexe no monitoramento_sl.js: usa o mesmo config.json (e-mail, destinatários, avisos) e o mesmo modelo de e-mail.
//
// Para cada serviço marcado em config.json servicos_windows.monitorados:
//   - PARADO (ou crashou): avisa, liga de novo (se "reiniciar") e avisa quando voltar;
//   - TRAVADO: rodando, mas o log não mostra ciclo novo ("[Completed]") há mais de travado_min minutos -> reinicia;
//   - NÃO ENCONTRADO / SERVIDOR SEM ACESSO: só avisa (não há o que reiniciar);
//   - limites: no máximo N reinícios por ocorrência, com intervalo mínimo; depois avisa "acionar o NOC" a cada repetir_min.
// Registros: logs\servicos\<SERVIDOR>_<SERVIÇO>\AAAA-MM-DD.log, historico.log (mais recente no topo) e dados\servicos\...\estado.json.
// O Windows é acessado pelo servicos.ps1 (estado, logs e reinício, local ou em outro servidor).
'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFile } = require('child_process');

const PASTA = __dirname;
const lerJson = (arq) => { try { return JSON.parse(fs.readFileSync(arq, 'utf8').replace(/^﻿/, '')); } catch (e) { return null; } };
const pastaSegura = (nome) => String(nome || 'geral').replace(/[^A-Za-z0-9_-]/g, '_');
const dataArquivo = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const hora = (ms) => new Date(ms).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
const duracao = (ms) => {
    const s = Math.max(0, Math.round(ms / 1000));
    if (s >= 86400) { const d = Math.floor(s / 86400); return d + (d === 1 ? ' dia ' : ' dias ') + Math.floor((s % 86400) / 3600) + ' h'; }
    if (s >= 3600) return Math.floor(s / 3600) + ' h ' + Math.floor((s % 3600) / 60) + ' min';
    return (s >= 60 ? Math.floor(s / 60) + ' min ' : '') + (s % 60) + ' s';
};
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// chama o servicos.ps1 (ou, nos testes, o braço falso indicado em SPS_BRACO_FALSO) e devolve o JSON
function braco(args, tempoMs) {
    return new Promise((ok) => {
        const falso = process.env.SPS_BRACO_FALSO;
        const [prog, a] = falso ? [process.execPath, [falso, ...args]]
            : ['powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', path.join(PASTA, 'servicos.ps1'), ...args]];
        execFile(prog, a, { timeout: tempoMs || 180000, windowsHide: true, encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 }, (err, saida) => {
            try { ok(JSON.parse(String(saida || '').trim())); } catch (e) { ok({ ok: false, erro: (err && err.message) || 'resposta inválida do servicos.ps1' }); }
        });
    });
}

// e-mail pelo enviar_email.ps1 (o mesmo da Service Layer); nos testes, SPS_EMAIL_FALSO = pasta onde grava o HTML
function enviarEmail(assunto, para, html) {
    if (process.env.SPS_EMAIL_FALSO) {
        fs.mkdirSync(process.env.SPS_EMAIL_FALSO, { recursive: true });
        fs.writeFileSync(path.join(process.env.SPS_EMAIL_FALSO, Date.now() + '_' + Math.floor(Math.random() * 1e6) + '.html'), '<!-- ' + assunto + ' -->\n' + html);
        return Promise.resolve();
    }
    const arq = path.join(PASTA, 'email_' + Date.now() + '_' + Math.floor(Math.random() * 1000) + '.html');
    fs.writeFileSync(arq, html, 'utf8');
    return new Promise((ok, falha) => {
        execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(PASTA, 'enviar_email.ps1'), '-Assunto', assunto, '-Para', para, '-ArquivoHtml', arq],
            { timeout: 90000, windowsHide: true }, (err, s, e) => { try { fs.unlinkSync(arq); } catch (x) { } if (err) falha(new Error(String(e || err.message).trim())); else ok(); });
    });
}

async function executar(opcoes) {
    opcoes = opcoes || {};
    const agora = opcoes.agora || Date.now();
    const CONFIG = lerJson(path.join(PASTA, 'config.json')) || {};
    const TEMPOS = lerJson(path.join(PASTA, 'tempos.json')) || {};
    const sw = CONFIG.servicos_windows || {};
    const monitorados = (Array.isArray(sw.monitorados) ? sw.monitorados : []).filter(m => m && m.nome);
    if (!monitorados.length) return { verificados: 0 };
    const num = (v, padrao) => (v !== undefined && v !== '' && !isNaN(Number(v)) && Number(v) >= 0 ? Number(v) : padrao);
    const MAX_TENTATIVAS = Math.max(1, num(sw.tentativas, 3));
    const MIN_ENTRE = num(sw.minutos_entre_reinicios, 10);
    const DIAS_LOG = Math.max(1, num(TEMPOS.dias_manter_logs, 30));
    const AVISOS = CONFIG.avisos || {};
    const avisoLigado = (tipo) => AVISOS[tipo] !== false;
    const REPETIR_MS = (Number(AVISOS.repetir_min) > 0 ? Number(AVISOS.repetir_min) : 30) * 60000;
    const EMAIL_PARA = CONFIG.email_para || '';

    const r = await braco(['-Acao', 'estado']);
    const resultados = [];
    if (!r || !r.ok) { logGeral('servicos.ps1 não respondeu: ' + ((r && r.erro) || '?')); return { verificados: 0, erro: r && r.erro }; }
    const porChave = {};
    for (const s of r.servicos || []) porChave[(s.servidor + '|' + s.nome).toLowerCase()] = s;
    const errosServidor = r.errosServidor || {};

    function logGeral(t) {
        try {
            const dir = path.join(PASTA, 'logs', 'geral'); fs.mkdirSync(dir, { recursive: true });
            fs.appendFileSync(path.join(dir, dataArquivo(new Date(agora)) + '.log'), new Date(agora).toLocaleTimeString('pt-BR') + ' [serviços] ' + t + '\n');
        } catch (e) { }
    }

    for (const m of monitorados) {
        const servidor = String(m.servidor || os.hostname());
        const id = pastaSegura(servidor + '_' + m.nome);
        const exib = m.exibicao || m.nome;
        const dirLog = path.join(PASTA, 'logs', 'servicos', id);
        const dirDados = path.join(PASTA, 'dados', 'servicos', id);
        try { fs.mkdirSync(dirLog, { recursive: true }); fs.mkdirSync(dirDados, { recursive: true }); } catch (e) { }
        const arqEstado = path.join(dirDados, 'estado.json');
        const arqHist = path.join(dirLog, 'historico.log');
        const estado = lerJson(arqEstado) || {};
        const gravar = () => { try { fs.writeFileSync(arqEstado, JSON.stringify(estado)); } catch (e) { } };
        const log = (t) => {
            try {
                const quando = opcoes.agora ? new Date(agora) : new Date();   // hora real de cada linha (nos testes, a do relógio simulado)
                fs.appendFileSync(path.join(dirLog, dataArquivo(quando) + '.log'), quando.toLocaleTimeString('pt-BR') + ' ' + t + '\n');
                // guarda só os últimos DIAS_LOG dias
                const limite = dataArquivo(new Date(agora - DIAS_LOG * 86400000));
                for (const a of fs.readdirSync(dirLog)) { const x = a.match(/^(\d{4}-\d{2}-\d{2})\.log$/); if (x && x[1] < limite) fs.unlinkSync(path.join(dirLog, a)); }
            } catch (e) { }
        };
        const CAB = '# Histórico de ocorrências de ' + exib + ' (' + servidor + ') - a mais recente no topo';
        const historico = () => { try { return fs.readFileSync(arqHist, 'utf8').split('\n').filter(l => l && !l.startsWith('#')); } catch (e) { return []; } };
        const registrar = (evento, texto) => {
            const dados = String(texto || '').split('\n').filter(l => /^[^:]{1,32}: /.test(l) && !/^Próximo passo/i.test(l));
            const linha = hora(agora) + ' | ' + evento + ' | ' + dados.join(' · ');
            try { fs.writeFileSync(arqHist, [CAB, linha].concat(historico().slice(0, 2999)).join('\n') + '\n'); } catch (e) { }
        };
        // aviso por e-mail no MESMO modelo da Service Layer (faixa colorida, tabela, histórico)
        async function avisar(titulo, tipo, detalhe) {
            registrar(titulo, detalhe);
            log('AVISO: ' + titulo);
            if (!avisoLigado(tipo)) { log('E-mail: aviso "' + tipo + '" desligado na configuração: só registrado no histórico'); return; }
            if (!EMAIL_PARA) { log('E-mail: sem destinatário'); return; }
            const cor = /voltou|restabelecid/i.test(titulo) ? '#107e3e' : /reiniciando/i.test(titulo) ? '#b45309' : '#b91c1c';
            const td1 = 'padding:5px 12px 5px 0;color:#6b7280;white-space:nowrap;vertical-align:top', td2 = 'padding:5px 0;color:#111827';
            const tabela = '<table style="border-collapse:collapse;width:100%">' + String(detalhe).split('\n').filter(l => l.trim()).map(l => {
                const i = l.indexOf(': ');
                return i > 0 && i < 32 ? '<tr><td style="' + td1 + '">' + esc(l.slice(0, i)) + '</td><td style="' + td2 + '">' + esc(l.slice(i + 2)) + '</td></tr>'
                    : '<tr><td colspan="2" style="' + td2 + '">' + esc(l) + '</td></tr>';
            }).join('') + '</table>';
            const hist = historico().slice(0, 8);
            const html = '<div style="font-family:Arial,Helvetica,sans-serif;max-width:600px;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden">'
                + '<div style="background:' + cor + ';color:#fff;padding:14px 18px">'
                + '<div style="font-size:12px;opacity:.85">MONITORAMENTO · SERVIDOR ' + esc(servidor.toUpperCase()) + '</div>'
                + '<div style="font-size:19px;margin-top:2px">' + esc(titulo) + '</div></div>'
                + '<div style="padding:12px 18px 16px;font-size:14px;line-height:1.45">' + tabela
                + (hist.length ? '<div style="margin:16px 0 6px;font-size:11px;letter-spacing:.04em;color:#6b7280;text-transform:uppercase">Histórico de eventos (mais recente primeiro)</div>'
                    + '<div style="font-family:Consolas,monospace;font-size:12px;color:#374151;background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:8px 10px">' + hist.map(esc).join('<br>') + '</div>' : '')
                + '</div><div style="background:#f9fafb;border-top:1px solid #e5e7eb;padding:10px 18px;font-size:12px;color:#6b7280">'
                + 'Monitoramento de Serviços · enviado pelo servidor ' + esc(os.hostname()) + ' · ' + hora(agora) + ' · histórico completo: ' + esc(arqHist) + '</div></div>';
            try { await enviarEmail('[Serviço ' + servidor.toUpperCase() + '] ' + titulo + ' - ' + exib, EMAIL_PARA, html); log('E-mail: enviado'); }
            catch (e) { log('E-mail: FALHOU: ' + e.message); logGeral('e-mail falhou (' + exib + '): ' + e.message); }
        }

        const s = porChave[(servidor + '|' + m.nome).toLowerCase()];
        const travadoMin = Number(m.travado_min) > 0 ? Number(m.travado_min) : 0;
        // regra de "travou" escolhida na tela: estado (só parado) | log | porta | url. Cadastro antigo: log + minutos = 'log'
        const modo = m.verificacao || (m.log && travadoMin ? 'log' : 'estado');
        const memLimite = Number(m.memoria_mb) > 0 ? Number(m.memoria_mb) : 0;
        // texto que marca um ciclo concluído: o da tela; cadastro antigo (sem o campo) = "[Completed]" da Invent
        const textoCiclo = Object.prototype.hasOwnProperty.call(m, 'texto_ciclo') ? String(m.texto_ciclo || '') : '[Completed]';
        // ---------- diagnóstico ----------
        let problema = null, motivo = '';
        const vidaMs = s && s.log && (s.log.ultimoCiclo || s.log.gravadoEm) ? Date.parse(s.log.ultimoCiclo || s.log.gravadoEm) : 0;
        const desdeReinicio = estado.reiniciadoEm ? agora - estado.reiniciadoEm : Infinity;
        if (errosServidor[servidor]) { problema = 'sem_acesso'; motivo = errosServidor[servidor]; }
        else if (!s || !s.existe) { problema = 'nao_existe'; motivo = 'o serviço não existe (mais) neste servidor'; }
        else if (s.estado !== 'Running') {
            // "iniciando"/"parando" é normal por alguns minutos; parado é na hora
            const pend = /Pending/i.test(s.estado);
            if (!pend || (estado.pendenteDesde && agora - estado.pendenteDesde > 5 * 60000)) { problema = 'parado'; motivo = 'estado: ' + s.estado; }
            if (pend && !estado.pendenteDesde) { estado.pendenteDesde = agora; }
        } else if (modo === 'log' && travadoMin && desdeReinicio > travadoMin * 60000) {
            if (s.log && s.log.cicloAusente) {
                problema = 'travado'; motivo = 'rodando, mas o texto "' + textoCiclo + '" não aparece no log de hoje nem no de ontem (confira o texto na tela, se for o caso)';
            } else if (vidaMs && agora - vidaMs > travadoMin * 60000) {
                problema = 'travado'; motivo = 'rodando, mas sem ' + (textoCiclo ? 'ciclo novo' : 'gravação nova') + ' no log há ' + duracao(agora - vidaMs) + ' (limite ' + travadoMin + ' min)';
            }
        } else if ((modo === 'porta' || modo === 'url') && desdeReinicio > 2 * 60000) {
            // porta / endereço: só conta como travado na 2ª falha seguida (uma oscilação não reinicia)
            const sinal = modo === 'porta' ? s.porta : s.url;
            if (sinal && !sinal.ok) {
                estado.falhasSinal = (estado.falhasSinal || 0) + 1;
                if (estado.falhasSinal >= 2) { problema = 'travado'; motivo = 'rodando, mas ' + (modo === 'porta' ? 'a porta ' + m.porta : 'o endereço ' + m.url) + ' não responde (' + (sinal.erro || 'sem resposta') + ', ' + estado.falhasSinal + ' verificações seguidas)'; }
            } else estado.falhasSinal = 0;
        }
        // memória acima do limite (opcional, qualquer regra): 2 verificações seguidas
        if (!problema && memLimite && s && s.estado === 'Running' && desdeReinicio > 2 * 60000) {
            if (s.memoriaMB > memLimite) { estado.memAcima = (estado.memAcima || 0) + 1; if (estado.memAcima >= 2) { problema = 'memoria'; motivo = 'usando ' + s.memoriaMB + ' MB de memória (limite ' + memLimite + ' MB)'; } }
            else estado.memAcima = 0;
        }
        if (!s || !/Pending/i.test(s.estado || '')) estado.pendenteDesde = 0;
        const resumoVida = modo === 'log' ? (vidaMs ? 'última atividade no log há ' + duracao(agora - vidaMs) : 'log não encontrado')
            : modo === 'porta' && s && s.porta ? 'porta ' + m.porta + (s.porta.ok ? ' respondendo' : ' sem resposta')
            : modo === 'url' && s && s.url ? 'endereço ' + (s.url.ok ? 'respondendo (HTTP ' + s.url.status + ')' : 'sem resposta') : '';
        const linhaDados = (s && s.existe ? 'estado ' + s.estado + (s.memoriaMB ? ' · memória ' + s.memoriaMB + ' MB' : '') : '') + (resumoVida ? ' · ' + resumoVida : '')
            // a Invent põe a versão no nome do serviço: achado pelo nome sem a versão (o add-on foi atualizado)
            + (s && s.nomeReal && s.nomeReal.toLowerCase() !== String(m.nome).toLowerCase() ? ' · agora se chama ' + s.nomeReal + ' (versão nova do add-on; abra a tela e salve para atualizar o cadastro)' : '');

        // travado e já reiniciado: só está "de volta" quando aparecer um ciclo novo no log depois do reinício
        if (!problema && estado.problema === 'travado' && modo === 'log' && estado.reiniciadoEm && travadoMin && (!vidaMs || vidaMs < estado.reiniciadoEm || (s && s.log && s.log.cicloAusente))) {
            log('aguardando o primeiro ciclo no log depois do reinício · ' + linhaDados); gravar();
            resultados.push({ servidor, nome: m.nome, situacao: 'aguardando' }); continue;
        }
        // ---------- voltou ----------
        if (!problema) {
            log('ok · ' + linhaDados);
            if (estado.problema) {
                const fora = agora - (estado.desde || agora);
                if (estado.avisado) await avisar('Serviço restabelecido', 'restabelecida', exib + ' voltou a funcionar normalmente. Nenhuma ação necessária.'
                    + '\nServidor: ' + servidor + '\nServiço: ' + m.nome
                    + '\nProblema: ' + rotulo(estado.problema) + '\nFicou fora: ' + duracao(fora) + ' (de ' + hora(estado.desde) + ' até ' + hora(agora) + ')'
                    + (estado.tentativas ? '\nReinícios automáticos: ' + estado.tentativas : '') + (linhaDados ? '\nSituação: ' + linhaDados : ''));
                else registrar('Serviço restabelecido', 'Ficou fora: ' + duracao(fora));
            }
            for (const k of ['problema', 'desde', 'avisado', 'tentativas', 'ultimoReinicio', 'ultimoAvisoNoc', 'motivo']) delete estado[k];   // (falhasSinal/memAcima têm contagem própria)
            gravar(); resultados.push({ servidor, nome: m.nome, situacao: 'ok' }); continue;
        }

        // ---------- problema ----------
        log('PROBLEMA ' + rotulo(problema) + ': ' + motivo + (linhaDados ? ' · ' + linhaDados : ''));
        if (estado.problema !== problema) { estado.problema = problema; estado.desde = estado.desde || agora; estado.avisado = false; if (!estado.tentativas) estado.tentativas = 0; }
        estado.motivo = motivo;
        const podeReiniciar = m.reiniciar !== false && (problema === 'parado' || problema === 'travado' || problema === 'memoria');
        if (!estado.avisado) {
            estado.avisado = true; gravar();
            await avisar(titulo(problema), 'indisponivel', descricao(problema, exib)
                + '\nServidor: ' + servidor + '\nServiço: ' + m.nome + '\nDetectado em: ' + hora(estado.desde) + '\nMotivo: ' + motivo
                + (linhaDados ? '\nSituação: ' + linhaDados : '')
                + '\nPróximo passo: ' + (podeReiniciar ? 'O reinício automático está sendo feito agora.' : problema === 'parado' || problema === 'travado'
                    ? 'Reinício automático DESLIGADO para este serviço: reiniciar manualmente ou acionar o NOC.' : proximoSemReinicio(problema)));
        }
        let acao = 'aviso';
        if (podeReiniciar && estado.tentativas < MAX_TENTATIVAS && agora - (estado.ultimoReinicio || 0) >= MIN_ENTRE * 60000) {
            estado.tentativas++; estado.ultimoReinicio = agora; gravar();
            const comando = s.estado === 'Running' ? 'reiniciar' : 'iniciar';
            log('REINICIANDO (' + estado.tentativas + 'ª tentativa): ' + comando);
            const rr = await braco(['-Acao', comando, '-Servidor', servidor, '-Nome', m.nome].concat(m.forcar === false ? [] : ['-Forcar']));
            if (rr && rr.ok) estado.reiniciadoEm = opcoes.agora || Date.now();
            acao = rr && rr.ok ? 'reiniciado' : 'falhou';
            log('resultado: ' + (rr && rr.ok ? 'rodando de novo' : 'FALHOU: ' + ((rr && (rr.erro || rr.estado)) || '?')) + (rr && rr.passos ? ' · ' + rr.passos.join(' · ') : ''));
            await avisar(rr && rr.ok ? 'Serviço reiniciado' : 'Falha ao reiniciar o serviço', rr && rr.ok ? 'reiniciando' : 'falhas', (rr && rr.ok
                ? exib + ' foi ' + (comando === 'iniciar' ? 'ligado' : 'reiniciado') + ' automaticamente e está rodando.' + (problema === 'travado' && modo === 'log' ? ' Aguardando a próxima atividade no log para confirmar.' : '')
                : 'O monitoramento tentou ' + (comando === 'iniciar' ? 'ligar' : 'reiniciar') + ' o serviço, mas não conseguiu.')
                + '\nServidor: ' + servidor + '\nServiço: ' + m.nome + '\nProblema: ' + rotulo(problema) + ' (' + motivo + ')'
                + '\nAção executada: ' + (rr && rr.passos ? rr.passos.join(', ') : comando) + '\nTentativa: ' + estado.tentativas + 'ª de ' + MAX_TENTATIVAS
                + (rr && !rr.ok ? '\nErro: ' + (rr.erro || ('estado ' + rr.estado)) : '')
                + '\nFora desde: ' + hora(estado.desde) + ' (' + duracao(agora - estado.desde) + ')'
                + '\nPróximo passo: ' + (rr && rr.ok ? 'Nenhum, se o serviço continuar rodando. Um novo aviso é enviado se ele parar de novo.' : 'Acionar o NOC.'));
        } else if (podeReiniciar && estado.tentativas >= MAX_TENTATIVAS || !podeReiniciar) {
            // sem mais reinícios: lembra no máximo a cada repetir_min
            if (agora - (estado.ultimoAvisoNoc || estado.desde) >= REPETIR_MS) {
                estado.ultimoAvisoNoc = agora; gravar();
                await avisar('Serviço permanece com problema - acionar o NOC', 'falhas', exib + ' continua com problema.'
                    + '\nServidor: ' + servidor + '\nServiço: ' + m.nome + '\nProblema: ' + rotulo(problema) + ' (' + motivo + ')'
                    + '\nFora desde: ' + hora(estado.desde) + ' (' + duracao(agora - estado.desde) + ')'
                    + (podeReiniciar ? '\nReinícios automáticos: ' + estado.tentativas + ' (limite atingido)' : '')
                    + '\nPróximo passo: Acionar o NOC.');
            }
        } else log('aguardando o intervalo mínimo de ' + MIN_ENTRE + ' min entre reinícios');
        gravar();
        resultados.push({ servidor, nome: m.nome, situacao: problema, acao });
    }
    return { verificados: monitorados.length, resultados };
}
function rotulo(p) { return { parado: 'parado', travado: 'travado', memoria: 'memória acima do limite', nao_existe: 'não encontrado', sem_acesso: 'servidor sem acesso' }[p] || p; }
function titulo(p) { return { parado: 'Serviço parado', travado: 'Serviço travado', memoria: 'Serviço com memória acima do limite', nao_existe: 'Serviço não encontrado', sem_acesso: 'Servidor sem acesso pelo monitoramento' }[p] || 'Serviço com problema'; }
function descricao(p, exib) {
    return { parado: exib + ' está parado (não está rodando no Windows).', travado: exib + ' aparece rodando no Windows, mas parou de trabalhar.', memoria: exib + ' está usando memória acima do limite definido (costuma travar em seguida).',
        nao_existe: exib + ' não foi encontrado no servidor (pode ter sido desinstalado ou renomeado).', sem_acesso: 'O monitoramento não conseguiu acessar o servidor para conferir ' + exib + '.' }[p] || exib;
}
function proximoSemReinicio(p) {
    return p === 'sem_acesso' ? 'Conferir se o servidor está ligado e se a rede/firewall permitem o acesso (portas 135 e 445) com o usuário cadastrado.'
        : 'Conferir o serviço no servidor; se foi removido de propósito, desmarque-o na tela de configuração (Serviços do Windows).';
}

module.exports = { executar };
if (require.main === module) {
    executar().then(r => process.stdout.write(JSON.stringify(r) + '\n')).catch(e => { process.stdout.write('ERRO: ' + e.message + '\n'); process.exitCode = 1; });
}
