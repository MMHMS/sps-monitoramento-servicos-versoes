﻿# Instala o Monitoramento da Service Layer NESTE servidor, na pasta onde está este arquivo (com barra de progresso).
# Chamado pelo INSTALAR.vbs (dois cliques, pede permissão de administrador). Rodar de novo repara e atualiza o Node.
# JÁ INSTALADO neste servidor (tarefa "Monitoramento Service Layer" existe): atualiza NA PASTA DE LÁ, copiando só os
# arquivos do programa — config.json (conexões e senhas), tempos.json, logs, dados e node ficam como estão.
#   -Destino <pasta>  instala/atualiza nessa pasta (o atualizar.ps1 passa a pasta atual)
#   -SemJanela        sem janela, tudo no console; termina com código 0 (ok) ou 1 (erro) — usado pelo atualizador
param([string]$Destino, [switch]$SemJanela)
Add-Type -AssemblyName System.Drawing   # gera o ícone; a janela é WPF (ui-janela.ps1)
$origem = Split-Path -Parent $MyInvocation.MyCommand.Path
$nomeTarefa = 'Monitoramento Service Layer'
$nomeAtualizador = 'Monitoramento de Servicos - Atualizador'; $pastaTarefas = '\SPS Group\'
$script:deuErro = $false
# onde instalar: -Destino; senão a pasta da instalação existente (pela tarefa); senão a pasta deste arquivo
$pasta = $origem
$tarefaExistente = Get-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue
if ($Destino) { $pasta = $Destino.TrimEnd('\') }
elseif ($tarefaExistente) {
    $pastaAntiga = "$($tarefaExistente.Actions[0].WorkingDirectory)".Trim('"').TrimEnd('\')
    if ($pastaAntiga -and (Test-Path -LiteralPath (Join-Path $pastaAntiga 'monitoramento_sl.js'))) { $pasta = $pastaAntiga }
}
$mesmaPasta = ([IO.Path]::GetFullPath($pasta).TrimEnd('\') -eq [IO.Path]::GetFullPath($origem).TrimEnd('\'))
$tituloJanela = 'Monitoramento de Serviços - Instalação'
$tituloTopo = 'Instalando o Monitoramento de Serviços'
$script:abrirConfiguracao = $false

# ícone com o cubo da logo SPS em vários tamanhos (fica nítido em qualquer lugar do Windows)
function Gerar-Icone($logoPng, $destinoIco) {
    $logo = New-Object Drawing.Bitmap($logoPng)
    $tamanhos = @(16, 24, 32, 48, 64, 256)
    $pngs = New-Object System.Collections.ArrayList
    foreach ($t in $tamanhos) {
        $bmp = New-Object Drawing.Bitmap($t, $t)
        $g = [Drawing.Graphics]::FromImage($bmp)
        $g.SmoothingMode = 'AntiAlias'; $g.InterpolationMode = 'HighQualityBicubic'; $g.PixelOffsetMode = 'HighQuality'
        # fundo branco com cantos arredondados e borda clara
        $r = [Math]::Max(2, [int]($t * 0.2)); $d = $r * 2; $l = $t - 1
        $forma = New-Object Drawing.Drawing2D.GraphicsPath
        $forma.AddArc(0, 0, $d, $d, 180, 90); $forma.AddArc($l - $d, 0, $d, $d, 270, 90)
        $forma.AddArc($l - $d, $l - $d, $d, $d, 0, 90); $forma.AddArc(0, $l - $d, $d, $d, 90, 90); $forma.CloseFigure()
        $g.FillPath([Drawing.Brushes]::White, $forma)
        $g.DrawPath((New-Object Drawing.Pen([Drawing.Color]::FromArgb(205, 215, 228), [Math]::Max(1, $t / 64))), $forma)
        # cubo da logo (recorte quadrado em volta do cubo: x 54-240, y 43-256)
        $m = [int]([Math]::Max(1, $t * 0.12))
        $g.DrawImage($logo, (New-Object Drawing.Rectangle($m, $m, ($t - 2 * $m), ($t - 2 * $m))), (New-Object Drawing.Rectangle(35, 37, 224, 224)), 'Pixel')
        $g.Dispose()
        $ms = New-Object IO.MemoryStream
        $bmp.Save($ms, [Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
        [void]$pngs.Add($ms.ToArray())
    }
    $logo.Dispose()
    # arquivo .ico: cabeçalho, uma entrada por tamanho e as imagens PNG
    $fs = [IO.File]::Create($destinoIco); $w = New-Object IO.BinaryWriter($fs)
    $w.Write([UInt16]0); $w.Write([UInt16]1); $w.Write([UInt16]$tamanhos.Count)
    $pos = 6 + 16 * $tamanhos.Count
    for ($i = 0; $i -lt $tamanhos.Count; $i++) {
        $lado = if ($tamanhos[$i] -ge 256) { 0 } else { $tamanhos[$i] }
        $w.Write([Byte]$lado); $w.Write([Byte]$lado); $w.Write([Byte]0); $w.Write([Byte]0)
        $w.Write([UInt16]1); $w.Write([UInt16]32); $w.Write([UInt32]$pngs[$i].Length); $w.Write([UInt32]$pos)
        $pos += $pngs[$i].Length
    }
    foreach ($png in $pngs) { $w.Write([byte[]]$png) }
    $w.Close()
}

# ---------- janela (WPF, mesmo visual da tela de configuração) ou console (atualizador: -SemJanela) ----------
. (Join-Path $origem 'ui-janela.ps1')
$script:SemJanela = [bool]$SemJanela
if (-not $SemJanela) {
    # ícone com o cubo da logo SPS (gerado antes de abrir a janela, para ela já usar)
    try { if (Test-Path -LiteralPath (Join-Path $origem 'logo_sps.png')) { Gerar-Icone (Join-Path $origem 'logo_sps.png') (Join-Path $origem 'logo_sps.ico') } } catch { }
    Abrir-Janela $tituloJanela $tituloTopo 'SPS Group · Monitoramento de Serviços' $origem
}

function Instalar {
    try {
        Etapa 3 'Conferindo permissão de administrador...'
        $admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        if (-not $admin) { throw 'O instalador precisa de permissão de administrador (responda Sim na pergunta do Windows).' }
        $versaoNova = try { ([IO.File]::ReadAllText((Join-Path $origem 'versao.txt'))).Trim() } catch { '' }
        if ($versaoNova) { Feito ('versão ' + $versaoNova) }
        Feito ('pasta de instalação: ' + $pasta)

        if (-not $mesmaPasta) {
            # atualização: copia SÓ os arquivos do programa; nunca config.json/tempos.json (conexões, senhas, tempos),
            # nem as pastas logs, dados, node e atualizacoes
            Etapa 6 'Copiando os arquivos do programa...'
            if (-not (Test-Path -LiteralPath $pasta)) { New-Item -ItemType Directory -Force $pasta | Out-Null }
            $protegidos = @('config.json', 'tempos.json')
            $copiados = 0
            Get-ChildItem -LiteralPath $origem -File | Where-Object { $protegidos -notcontains $_.Name.ToLower() -and $_.Extension -ne '.log' } | ForEach-Object {
                Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $pasta $_.Name) -Force; $copiados++
            }
            Feito ("$copiados arquivos do programa atualizados (config.json, tempos.json, logs e dados mantidos)")
        }

        Etapa 8 'Desbloqueando os arquivos...'
        Get-ChildItem -LiteralPath $pasta -Recurse | Unblock-File
        Feito 'arquivos desbloqueados'

        # Node.js dentro da pasta (node\node.exe): LTS mais nova do site oficial, conferida pelo SHA-256.
        # Sem internet: mantém o da pasta ou usa um Node instalado no Windows.
        Etapa 12 'Procurando a versão mais nova do Node.js (LTS)...'
        $pastaNode = Join-Path $pasta 'node'
        $node = Join-Path $pastaNode 'node.exe'
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $ProgressPreference = 'SilentlyContinue'
            # (a lista vem como um bloco só no PowerShell 5.1: percorre item a item)
            $versoes = (Invoke-WebRequest 'https://nodejs.org/dist/index.json' -UseBasicParsing -TimeoutSec 30).Content | ConvertFrom-Json
            $lts = $versoes | ForEach-Object { $_ } | Where-Object { $_.lts -and ($_.files -contains 'win-x64-exe') } | Select-Object -First 1
            if (-not $lts) { throw 'lista de versões sem LTS para Windows' }
            $atual = if (Test-Path -LiteralPath $node) { (& $node -v).Trim() } else { '' }
            if ($atual -ne $lts.version) {
                New-Item -ItemType Directory -Force $pastaNode | Out-Null
                $url = 'https://nodejs.org/dist/' + $lts.version + '/win-x64/node.exe'
                $baixado = Join-Path $pastaNode 'node_baixando.exe'
                if (Test-Path -LiteralPath $baixado) { Remove-Item -LiteralPath $baixado -Force }
                Etapa 15 ('Baixando o Node.js ' + $lts.version + ' LTS...')
                $total = 0
                try { $total = [long](Invoke-WebRequest $url -Method Head -UseBasicParsing -TimeoutSec 30).Headers['Content-Length'] } catch { }
                $wc = New-Object Net.WebClient
                $download = $wc.DownloadFileTaskAsync($url, $baixado)
                while (-not $download.IsCompleted) {
                    if ($total -gt 0 -and (Test-Path -LiteralPath $baixado)) {
                        $ja = (Get-Item -LiteralPath $baixado).Length
                        Progresso ([Math]::Min(64, 15 + [int](49 * $ja / $total)))
                        Detalhe ('{0:N1} de {1:N1} MB' -f ($ja / 1MB), ($total / 1MB))
                    }
                    Atualizar-Tela; Start-Sleep -Milliseconds 150
                }
                if ($download.IsFaulted) { throw $download.Exception.InnerException }
                Etapa 66 'Conferindo o arquivo baixado (SHA-256)...'
                $somas = (Invoke-WebRequest ('https://nodejs.org/dist/' + $lts.version + '/SHASUMS256.txt') -UseBasicParsing -TimeoutSec 30).Content
                $esperado = (($somas -split "`n") | Where-Object { $_ -match '\swin-x64/node\.exe\s*$' } | Select-Object -First 1) -replace '\s.*$', ''
                $obtido = (Get-FileHash -LiteralPath $baixado -Algorithm SHA256).Hash
                if (-not $esperado -or $obtido -ne $esperado.ToUpper()) { Remove-Item -LiteralPath $baixado -Force; throw 'o arquivo baixado não confere com o SHA-256 oficial' }
                Move-Item -LiteralPath $baixado -Destination $node -Force
                Feito ('Node.js ' + $lts.version + ' LTS baixado do site oficial (SHA-256 conferido)' + $(if ($atual) { " - antes: $atual" } else { '' }))
            } else { Feito ('Node.js ' + $atual + ' já é a LTS mais nova') }
        } catch {
            $motivo = $_.Exception.Message
            if (Test-Path -LiteralPath $node) { Feito ('Node.js da pasta mantido (' + (& $node -v).Trim() + ') - não deu para atualizar: ' + $motivo) }
            else {
                $cmdNode = Get-Command node.exe -ErrorAction SilentlyContinue
                $node = if ($cmdNode) { $cmdNode.Source } elseif (Test-Path "$env:ProgramFiles\nodejs\node.exe") { "$env:ProgramFiles\nodejs\node.exe" } else { '' }
                if (-not $node) { throw "Não consegui baixar o Node.js ($motivo) e não há Node instalado neste servidor.`nInstale a versão LTS (Windows Installer .msi, 64 bits): https://nodejs.org/pt/download`nDepois rode o INSTALAR.vbs de novo." }
                Feito ('Node.js do Windows (' + (& $node -v).Trim() + ') - sem internet para baixar: ' + $motivo)
            }
        }
        $versaoNode = (& $node -v).Trim()
        if ([int]($versaoNode.TrimStart('v').Split('.')[0]) -lt 18) { throw "Node $versaoNode é antigo: o monitoramento precisa do 18 ou mais novo." }

        Etapa 70 'Preparando a configuração...'
        if (-not (Test-Path -LiteralPath (Join-Path $pasta 'config.json'))) {
            $cfg = [ordered]@{ controller_usuario = ''; controller_senha_cripto = ''; smtp_servidor = ''; smtp_porta = 587; smtp_ssl = $true
                smtp_usuario = ''; smtp_senha_cripto = ''; email_remetente = ''; email_para = ''; servicos = @() }
            [IO.File]::WriteAllText((Join-Path $pasta 'config.json'), ([pscustomobject]$cfg | ConvertTo-Json -Depth 3), (New-Object Text.UTF8Encoding $false))
            Feito 'configuração inicial criada'
        } else { Feito 'configuração existente mantida' }
        # tempos: o pacote traz o padrão (tempos.padrao.json); o tempos.json do cliente nunca é sobrescrito
        $arqTempos = Join-Path $pasta 'tempos.json'
        if (-not (Test-Path -LiteralPath $arqTempos) -and (Test-Path -LiteralPath (Join-Path $pasta 'tempos.padrao.json'))) {
            Copy-Item -LiteralPath (Join-Path $pasta 'tempos.padrao.json') -Destination $arqTempos; Feito 'tempos padrão criados'
        } else { Feito 'tempos existentes mantidos' }
        foreach ($sub in 'logs', 'dados', 'atualizacoes') { New-Item -ItemType Directory -Force (Join-Path $pasta $sub) | Out-Null }

        Etapa 76 'Gerando o ícone...'
        $ico = Join-Path $pasta 'logo_sps.ico'
        if (Test-Path -LiteralPath (Join-Path $pasta 'logo_sps.png')) { Gerar-Icone (Join-Path $pasta 'logo_sps.png') $ico; Feito 'ícone gerado' }

        Etapa 84 'Criando a tarefa agendada...'
        # monitoramento.js = Service Layer (igual a antes) + serviços do Windows, no mesmo processo
        $acao = New-ScheduledTaskAction -Execute $node -Argument 'monitoramento.js' -WorkingDirectory $pasta
        $gatilho = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 1)
        $regras = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 15) `
            -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
        # se a tarefa já roda com um usuário escolhido na tela de configuração, não volta para SYSTEM
        $existente = Get-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue
        $contaAtual = if ($existente) { "$($existente.Principal.UserId)" } else { '' }
        if ($contaAtual -and $contaAtual -ne 'S-1-5-18' -and $contaAtual -notmatch '^(NT AUTHORITY\\)?(SYSTEM|SISTEMA)$') {
            # troca só a AÇÃO (o programa que ela roda): a conta e a senha guardadas no Agendador ficam como estão
            try { Set-ScheduledTask -TaskName $nomeTarefa -Action $acao -ErrorAction Stop | Out-Null; Feito "tarefa agendada atualizada para monitoramento.js (mantida a conta $contaAtual)" }
            catch { Aviso "não consegui atualizar o programa da tarefa (roda com $contaAtual): $($_.Exception.Message). Os serviços do Windows só passam a ser vigiados depois de aplicar a conta de novo na tela (Agendador do Windows > Aplicar na tarefa)." }
        } else {
            # instalação nova: a tarefa nasce PARADA (liga pela tela, depois de configurar); reinstalar mantém ligada se já estava
            $estavaLigada = $existente -and ([string]$existente.State -ne 'Disabled')
            $quem = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
            Register-ScheduledTask -TaskName $nomeTarefa -Action $acao -Trigger $gatilho -Settings $regras -Principal $quem `
                -Description 'Monitoramento da Service Layer (SPS Group): verifica, reinicia e avisa por e-mail.' -Force | Out-Null
            if ($estavaLigada) { Feito "tarefa agendada '$nomeTarefa' atualizada e mantida LIGADA (SYSTEM, a cada 1 minuto)" }
            else { Disable-ScheduledTask -TaskName $nomeTarefa | Out-Null; Feito "tarefa agendada '$nomeTarefa' criada PARADA (ligar na tela, aba Tarefa agendada)" }
        }

        # atualizador: SISTEMA, a cada minuto - mas o "cmd" só abre o atualizar.ps1 se houver pedido (custo quase zero).
        # O atualizar.ps1 confere de novo o carimbo da SPS e a impressão digital antes de instalar.
        Etapa 89 'Criando o atualizador...'
        $pedidoAtu = Join-Path $pasta 'atualizacoes\pedido.json'
        $argsAtu = "/c if exist `"$pedidoAtu`" powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $pasta 'atualizar.ps1')`""
        $tAtu = Get-ScheduledTask -TaskName $nomeAtualizador -TaskPath $pastaTarefas -ErrorAction SilentlyContinue
        if ($tAtu -and "$($tAtu.Actions[0].Arguments)" -eq $argsAtu) { Feito "atualizador '$nomeAtualizador' já configurado" }
        else {
            $acaoAtu = New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\cmd.exe" -Argument $argsAtu
            $gatAtu = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 1)
            $quemAtu = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
            $regrasAtu = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 30) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
            Register-ScheduledTask -TaskName $nomeAtualizador -TaskPath $pastaTarefas -Action $acaoAtu -Trigger $gatAtu -Principal $quemAtu -Settings $regrasAtu `
                -Description 'Monitoramento de Serviços (SPS Group): instala a versão nova pedida na tela de configuração (aba Versão), conferindo o carimbo da SPS.' -Force | Out-Null
            Feito "atualizador '$pastaTarefas$nomeAtualizador' criado (SISTEMA; só age quando há pedido)"
        }

        Etapa 93 'Criando o ícone na área de trabalho...'
        $atalho = Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'Monitoramento da Service Layer.lnk'
        $ws = New-Object -ComObject WScript.Shell
        $lnk = $ws.CreateShortcut($atalho)
        $lnk.TargetPath = "$env:SystemRoot\System32\wscript.exe"
        $lnk.Arguments = '"' + (Join-Path $pasta 'abrir_monitoramento.vbs') + '"'
        $lnk.WorkingDirectory = $pasta
        $lnk.IconLocation = $(if (Test-Path -LiteralPath $ico) { "$ico,0" } else { "$env:SystemRoot\System32\shell32.dll,21" })
        $lnk.Description = 'Configuração e situação do Monitoramento da Service Layer'
        $lnk.Save()
        Feito 'ícone "Monitoramento da Service Layer" na área de trabalho'
        # o manual abre pelo botão Manual da tela: remove o ícone do PDF criado por uma versão anterior
        $lnkManual = Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'Manual do Monitoramento.lnk'
        if (Test-Path -LiteralPath $lnkManual) { Remove-Item -LiteralPath $lnkManual -Force -ErrorAction SilentlyContinue }

        Etapa 100 'Instalação concluída'
        $script:proximoPasso = 'Próximo passo: abra a configuração, cadastre as Service Layers e o e-mail, salve, teste e, em Agendador do Windows, clique em Iniciar monitoramento.'
    } catch {
        Falhou $_.Exception.Message
    }
}

Instalar
if ($SemJanela) { exit $(if ($script:deuErro) { 1 } else { 0 }) }
$abrir = Concluir (-not $script:deuErro) $(if ($script:deuErro) { 'Corrija o problema acima e rode o INSTALAR.vbs de novo.' } else { $script:proximoPasso }) 'Abrir configuração'
if ($abrir) { & (Join-Path $pasta 'configurar_monitoramento.ps1') }