// SPS Monitoramento de Serviços - ENTRADA da tarefa agendada (a cada 1 minuto).
// Roda os dois monitoramentos no mesmo processo, lado a lado:
//   - monitoramento_sl.js: a Service Layer, EXATAMENTE como antes (mesmos argumentos: status, teste_email, memoria...);
//   - monitoramento_servicos.js: os serviços do Windows marcados na tela (só no modo normal "monitorar").
// Um erro num não derruba o outro.
const modo = process.argv[2] || 'monitorar';
require('./monitoramento_sl.js');
if (modo === 'monitorar' || modo === 'vigiar') {
    require('./monitoramento_servicos.js').executar().catch(e => {
        try {
            const fs = require('fs'), path = require('path');
            const d = new Date(), dir = path.join(__dirname, 'logs', 'geral');
            fs.mkdirSync(dir, { recursive: true });
            fs.appendFileSync(path.join(dir, d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0') + '.log'),
                d.toLocaleTimeString('pt-BR') + ' [serviços] ERRO: ' + ((e && e.message) || e) + '\n');
        } catch (x) { }
    });
}
