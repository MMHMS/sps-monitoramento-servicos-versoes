// SPS Monitoramento de Serviços - ATUALIZAÇÃO ("Atualizar versão" na tela de configuração, aba Versão).
//
// A SPS publica cada versão no GitHub (repositório MMHMS/sps-monitoramento-servicos-versoes):
//   - versao.json = ficha da última versão (número, data, novidades, pacote, tamanho, SHA-256)
//                   + ASSINATURA Ed25519 com a chave privada da SPS ("carimbo");
//   - pacotes/SPS-Monitoramento-Servicos-<versão>.zip
// Uso (Node 18 ou mais novo, sem dependências):
//   node atualizacao.js versao             -> versão instalada (versao.txt)
//   node atualizacao.js verificar          -> {"atual","disponivel","temNova"} ou {"erro"} (uma linha JSON)
//   node atualizacao.js baixar             -> lê a ficha de novo, confere o carimbo, baixa, confere o SHA-256 e grava
//                                             atualizacoes\pedido.json  ->  "OK <versão>" ou "ERRO: motivo"
//   node atualizacao.js conferir <pedido>  -> usado pelo atualizar.ps1 (SISTEMA) antes de instalar: "OK <versão> <zip>" ou "ERRO: motivo"
// Quem instala é a tarefa do Windows "\SPS Group\Monitoramento de Servicos - Atualizador" (atualizar.ps1),
// que confere tudo de novo com ESTE arquivo da versão já instalada.
'use strict';
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const PASTA = __dirname;
const PRODUTO = 'SPS Monitoramento de Serviços';

/** Chave PÚBLICA da SPS (o carimbo). A privada fica só com o dono do produto. */
const CHAVE_PUBLICA_SPS = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAYUbrYLrFpqrsv4x1qASXRYPWMZNGfKqsuHCU+LEsw3c=
-----END PUBLIC KEY-----`;

const REPO = 'MMHMS/sps-monitoramento-servicos-versoes';
const ORIGEM = (process.env.SPS_ATUALIZACAO_ORIGEM || `https://raw.githubusercontent.com/${REPO}/main/`).replace(/\/?$/, '/');
// a ficha vem pela API do GitHub (o "raw" fica minutos em cache); o "raw" fica de reserva
const FICHA_API = `https://api.github.com/repos/${REPO}/contents/versao.json?ref=main`;
const PASTA_ATU = path.join(PASTA, 'atualizacoes');
const ARQ_PEDIDO = path.join(PASTA_ATU, 'pedido.json');

function versaoInstalada() {
    try { return fs.readFileSync(path.join(PASTA, 'versao.txt'), 'utf8').replace(/^﻿/, '').trim() || '0'; } catch (e) { return '0'; }
}
/** Texto exato que é assinado: a ficha sem o campo "assinatura", na ordem em que veio. */
function textoAssinado(ficha) {
    const resto = Object.assign({}, ficha);
    delete resto.assinatura;
    return JSON.stringify(resto);
}
function carimboValido(ficha, chave) {
    if (!ficha || !ficha.assinatura) return false;
    try {
        return crypto.verify(null, Buffer.from(textoAssinado(ficha), 'utf8'), crypto.createPublicKey(chave || CHAVE_PUBLICA_SPS), Buffer.from(ficha.assinatura, 'base64'));
    } catch (e) { return false; }
}
/** Compara versões AAAA.MM.DD[.N]: > 0 se a for mais nova que b. */
function compararVersoes(a, b) {
    const pa = String(a).split('.').map(n => parseInt(n, 10) || 0), pb = String(b).split('.').map(n => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length, 4); i++) {
        const d = (pa[i] || 0) - (pb[i] || 0);
        if (d) return d;
    }
    return 0;
}
/** A ficha vem da internet: confere cada campo antes de usar (nome de arquivo seguro etc.). */
function fichaCoerente(f) {
    if (!f || f.produto !== PRODUTO) return 'a ficha não é do ' + PRODUTO;
    if (!/^\d{4}\.\d{2}\.\d{2}(\.\d+)?$/.test(f.versao || '')) return 'número de versão inválido na ficha';
    if (!/^pacotes\/SPS-Monitoramento-Servicos-[0-9][0-9.]{3,30}\.zip$/.test(f.arquivo || '')) return 'nome de pacote inválido na ficha';
    if (!/^[0-9a-f]{64}$/.test(f.sha256 || '')) return 'SHA-256 inválido na ficha';
    if (!(f.tamanho > 10000 && f.tamanho < 95 * 1048576)) return 'tamanho do pacote fora do esperado';
    if (!Array.isArray(f.novidades)) return 'ficha sem novidades';
    return '';
}

async function lerFicha() {
    const cab = { 'User-Agent': 'SPS-Monitoramento-Servicos' };
    if (!process.env.SPS_ATUALIZACAO_ORIGEM) {
        try {
            const api = await fetch(FICHA_API, { signal: AbortSignal.timeout(20000), headers: Object.assign({ Accept: 'application/vnd.github.raw+json' }, cab) });
            if (api.ok) return await api.json();
        } catch (e) { /* sem a API (ou limite de 60/hora): segue pelo "raw" */ }
    }
    const r = await fetch(ORIGEM + 'versao.json', { signal: AbortSignal.timeout(20000), cache: 'no-store', headers: cab });
    if (r.status === 404) throw new Error('a SPS ainda não publicou nenhuma versão na vitrine (HTTP 404)');
    if (!r.ok) throw new Error('a vitrine de versões respondeu HTTP ' + r.status);
    return await r.json();
}
async function fichaConferida() {
    let ficha;
    try { ficha = await lerFicha(); }
    catch (e) { throw new Error(e && e.name === 'TimeoutError' ? 'a vitrine de versões não respondeu em 20 s (o servidor tem acesso à internet?)' : (e.cause && e.cause.code) || e.message); }
    const problema = fichaCoerente(ficha);
    if (problema) throw new Error(problema);
    if (!carimboValido(ficha)) throw new Error('a ficha da versão NÃO tem o carimbo da SPS - atualização recusada por segurança.');
    return ficha;
}

async function sha256Arquivo(arq) {
    const h = crypto.createHash('sha256');
    for await (const parte of fs.createReadStream(arq)) h.update(parte);
    return h.digest('hex');
}

async function verificar() {
    const atual = versaoInstalada();
    const ficha = await fichaConferida();
    return { atual, disponivel: ficha, temNova: compararVersoes(ficha.versao, atual) > 0 };
}

async function baixar() {
    const ficha = await fichaConferida();
    const atual = versaoInstalada();
    if (compararVersoes(ficha.versao, atual) <= 0) throw new Error('a versão publicada (' + ficha.versao + ') não é mais nova que a instalada (' + atual + ')');
    fs.mkdirSync(PASTA_ATU, { recursive: true });
    try { fs.unlinkSync(path.join(PASTA_ATU, 'estado-instalador.json')); } catch (e) { }
    const destino = path.join(PASTA_ATU, ficha.arquivo.split('/').pop());
    const parcial = destino + '.parcial';
    try {
        const r = await fetch(ORIGEM + ficha.arquivo, { signal: AbortSignal.timeout(10 * 60000), headers: { 'User-Agent': 'SPS-Monitoramento-Servicos' } });
        if (!r.ok) throw new Error('download recusado (HTTP ' + r.status + ')');
        fs.writeFileSync(parcial, Buffer.from(await r.arrayBuffer()));
        if (fs.statSync(parcial).size !== ficha.tamanho || await sha256Arquivo(parcial) !== ficha.sha256) {
            throw new Error('o pacote baixado não confere com a ficha (impressão digital diferente). Nada foi instalado.');
        }
        fs.renameSync(parcial, destino);
    } finally { try { fs.unlinkSync(parcial); } catch (e) { } }
    // pedido para a tarefa do Windows (ela confere carimbo e SHA-256 de novo antes de instalar)
    fs.writeFileSync(ARQ_PEDIDO, JSON.stringify({ ficha, pacote: destino, pedidoPor: process.env.USERNAME || '?', pedidoEm: new Date().toISOString() }, null, 2));
    return ficha.versao;
}

async function conferir(arqPedido) {
    if (!arqPedido || !fs.existsSync(arqPedido)) throw new Error('pedido não encontrado');
    const pedido = JSON.parse(fs.readFileSync(arqPedido, 'utf8').replace(/^﻿/, ''));
    const problema = fichaCoerente(pedido.ficha);
    if (problema) throw new Error(problema);
    if (!carimboValido(pedido.ficha)) throw new Error('a ficha não tem o carimbo da SPS');
    // nunca "volta" para uma versão igual ou mais antiga (mesmo com o carimbo)
    const atual = versaoInstalada();
    if (compararVersoes(pedido.ficha.versao, atual) <= 0) throw new Error('a versão ' + pedido.ficha.versao + ' não é mais nova que a instalada (' + atual + ')');
    // o pacote tem que estar na pasta de atualizações desta instalação
    // (caminho "de verdade" dos dois lados: o Windows aceita o mesmo caminho escrito curto, ex. MARCIO~1, ou longo)
    if (!pedido.pacote || !fs.existsSync(pedido.pacote)) throw new Error('pacote não encontrado');
    const pacote = fs.realpathSync.native(path.resolve(String(pedido.pacote)));
    if (path.dirname(pacote).toLowerCase() !== fs.realpathSync.native(PASTA_ATU).toLowerCase()) throw new Error('pacote fora da pasta de atualizações');
    if (fs.statSync(pacote).size !== pedido.ficha.tamanho) throw new Error('tamanho do pacote diferente da ficha');
    if (await sha256Arquivo(pacote) !== pedido.ficha.sha256) throw new Error('impressão digital (SHA-256) do pacote diferente da ficha');
    return pedido.ficha.versao + ' ' + pacote;
}

module.exports = { PRODUTO, CHAVE_PUBLICA_SPS, textoAssinado, carimboValido, compararVersoes, fichaCoerente, versaoInstalada };

if (require.main === module) {
    const cmd = process.argv[2];
    const linha = (t) => process.stdout.write(t + '\n');
    (async () => {
        if (cmd === 'versao') linha(versaoInstalada());
        else if (cmd === 'verificar') {
            try { linha(JSON.stringify(await verificar())); } catch (e) { linha(JSON.stringify({ atual: versaoInstalada(), erro: e.message })); }
        } else if (cmd === 'baixar') linha('OK ' + await baixar());
        else if (cmd === 'conferir') linha('OK ' + await conferir(process.argv[3]));
        else { linha('ERRO: use versao | verificar | baixar | conferir <pedido.json>'); process.exitCode = 1; }
    })().catch(e => { linha('ERRO: ' + (e && e.message || String(e))); process.exitCode = 1; });
}
