﻿<#
  SPS Monitoramento de Serviços - BRAÇO NO WINDOWS dos serviços (chamado pelo monitoramento_servicos.js e pela tela).
  Responde sempre UMA linha JSON (UTF-8) na saída.

  -Acao listar    -Servidor NOME   todos os serviços daquele servidor (nome, exibição, estado, início, programa)
                                   + os arquivos de log de HOJE da pasta de cada programa (padrão Invent: logs\AAAA\MM\dd_*.log)
  -Acao estado                     situação de TODOS os serviços marcados no config.json (servicos_windows.monitorados):
                                   estado, início, PID, memória e a última atividade do log (último "[Completed]" ou a gravação)
  -Acao reiniciar -Servidor NOME -Nome SERVICO [-Forcar]
                                   rodando = para e liga de novo; parado = só liga. -Forcar: se não parar em 60 s, encerra o processo.
  -Acao testar    -Servidor NOME   confere o acesso ao servidor (para a tela)

  Servidores (config.json servicos_windows.servidores): endereco vazio = ESTE servidor. Outro servidor: pelo endereço (IP ou nome),
  com o usuário do cadastro (senha criptografada pela máquina, DPAPI LocalMachine) ou, sem usuário, com a conta que roda a tarefa.
  Precisa das portas do WMI (135 + dinâmicas) para os serviços e do compartilhamento C$ (445) para ler os logs.
#>
param([string]$Acao = 'estado', [string]$Servidor = '', [string]$Nome = '', [switch]$Forcar)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Security
$pasta = Split-Path -Parent $MyInvocation.MyCommand.Path
function Responder($obj) { [Console]::Out.Write(($obj | ConvertTo-Json -Depth 6 -Compress)); exit 0 }

$cfg = $null
try { $cfg = [IO.File]::ReadAllText((Join-Path $pasta 'config.json')) | ConvertFrom-Json } catch { }
$sw = if ($cfg -and $cfg.PSObject.Properties.Name -contains 'servicos_windows') { $cfg.servicos_windows } else { $null }
$servidores = @(if ($sw -and $sw.servidores) { $sw.servidores | ForEach-Object { $_ } })
function Cadastro($nome) {
    $s = $servidores | Where-Object { "$($_.nome)" -eq $nome } | Select-Object -First 1
    if ($s) { return $s }
    # sem cadastro: este servidor (pelo nome da máquina) ou o próprio nome como endereço
    if (-not $nome -or $nome -eq $env:COMPUTERNAME) { return [pscustomobject]@{ nome = $env:COMPUTERNAME; endereco = ''; usuario = ''; senha_cripto = '' } }
    return [pscustomobject]@{ nome = $nome; endereco = $nome; usuario = ''; senha_cripto = '' }
}
function Eh-Local($s) { $e = "$($s.endereco)".Trim(); return (-not $e -or $e -eq '.' -or $e -eq 'localhost' -or $e -eq '127.0.0.1' -or $e -ieq $env:COMPUTERNAME) }
function Credencial($s) {
    if (-not "$($s.usuario)".Trim() -or -not "$($s.senha_cripto)") { return $null }
    $texto = [Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($s.senha_cripto), $null, 'LocalMachine'))
    return New-Object Management.Automation.PSCredential("$($s.usuario)".Trim(), (ConvertTo-SecureString $texto -AsPlainText -Force))
}
# sessão CIM (local = sem sessão); remoto pelo DCOM (porta 135), que costuma estar liberado entre servidores do domínio
$sessoes = @{}
function Sessao($s) {
    if (Eh-Local $s) { return $null }
    if ($sessoes.ContainsKey($s.nome)) { return $sessoes[$s.nome] }
    $op = New-CimSessionOption -Protocol Dcom
    $cred = Credencial $s
    $sess = if ($cred) { New-CimSession -ComputerName "$($s.endereco)".Trim() -SessionOption $op -Credential $cred -OperationTimeoutSec 30 } else { New-CimSession -ComputerName "$($s.endereco)".Trim() -SessionOption $op -OperationTimeoutSec 30 }
    $sessoes[$s.nome] = $sess; return $sess
}
function Servicos-Cim($s, $filtro) {
    $p = @{ ClassName = 'Win32_Service' }; if ($filtro) { $p.Filter = $filtro }
    $sess = Sessao $s; if ($sess) { $p.CimSession = $sess }
    return @(Get-CimInstance @p)
}
# caminho de arquivo daquele servidor: local = igual; remoto = \\endereco\C$\...
$unidades = @{}
function Caminho-Arquivo($s, $caminho) {
    if (Eh-Local $s) { return $caminho }
    if ($caminho -notmatch '^([A-Za-z]):\\(.*)$') { return $caminho }
    $raiz = '\\' + "$($s.endereco)".Trim() + '\' + $Matches[1] + '$'
    $resto = $Matches[2]
    $cred = Credencial $s
    if ($cred -and -not $unidades.ContainsKey($raiz)) {
        # conecta o compartilhamento com o usuário do cadastro (sem letra de unidade; some ao terminar)
        try { New-PSDrive -Name ('SPS' + $unidades.Count) -PSProvider FileSystem -Root $raiz -Credential $cred -Scope Script | Out-Null } catch { }
        $unidades[$raiz] = $true
    }
    return (Join-Path $raiz $resto)
}
# nome sem a versão na frente: "25.12.30.53022_TaxPlusNfeSendCancel" -> "TaxPlusNfeSendCancel"
function Base-Nome($n) { return ("$n" -replace '^\d+(\.\d+)+_', '') }
# acha o serviço pela base do nome (a Invent troca a versão no nome a cada atualização do add-on);
# havendo mais de um (versão velha esquecida), prefere o que está rodando e, depois, a versão maior
function Achar-PelaBase($s, $nome) {
    $base = Base-Nome $nome
    if (-not $base -or $base.Length -lt 4) { return $null }
    $cands = @(Servicos-Cim $s ("Name LIKE '%" + ($base -replace "'", "''" -replace '\[', '[[]') + "'") | Where-Object { (Base-Nome $_.Name) -ieq $base })
    return ($cands | Sort-Object @{ e = { "$($_.State)" -ne 'Running' } }, @{ e = { $_.Name }; Descending = $true } | Select-Object -First 1)
}
function Pasta-Programa($pathName) {
    $exe = if ("$pathName" -match '^"([^"]+)"') { $Matches[1] } elseif ("$pathName" -match '^(\S+\.exe)') { $Matches[1] } else { '' }
    if (-not $exe) { return '' }; return (Split-Path $exe)
}
# padrão salvo: C:\...\logs\{AAAA}\{MM}\{DD}_Nome.log  ->  arquivo de uma data
function Arquivo-Do-Dia($padrao, [datetime]$d) { return ($padrao -replace '\{AAAA\}', $d.ToString('yyyy') -replace '\{MM\}', $d.ToString('MM') -replace '\{DD\}', $d.ToString('dd')) }
# última atividade do log.
#  $texto vazio  -> vale QUALQUER gravação (hora da última gravação do arquivo) — serviços customizados;
#  $texto ("[Completed]" na Invent, ou o que a pessoa indicar) -> hora da última linha com esse texto: um serviço que só
#  grava ERRO (travado) não conta como vivo. Procura no arquivo de hoje e, se não achar, no de ontem.
#  Não achou o texto em nenhum dos dois: cicloAusente = true (o motor trata como "sem ciclo").
function Vida-Do-Log($s, $padrao, $texto) {
    $r = [ordered]@{ arquivo = ''; existe = $false; gravadoEm = $null; ultimoCiclo = $null; cicloAusente = $false }
    foreach ($d in @((Get-Date), (Get-Date).AddDays(-1))) {
        $arq = Caminho-Arquivo $s (Arquivo-Do-Dia $padrao $d)
        if (-not (Test-Path -LiteralPath $arq)) { continue }
        $info = Get-Item -LiteralPath $arq
        if (-not $r.existe) { $r.arquivo = $arq; $r.existe = $true; $r.gravadoEm = $info.LastWriteTime.ToString('o') }
        if (-not $texto) { break }
        # lê só o fim do arquivo (não carrega logs grandes inteiros)
        $fs = [IO.File]::Open($arq, 'Open', 'Read', 'ReadWrite')
        try {
            $tam = [Math]::Min($fs.Length, 262144); [void]$fs.Seek(-$tam, 'End')
            $buf = New-Object byte[] $tam; [void]$fs.Read($buf, 0, $tam)
        } finally { $fs.Close() }
        $linhas = [Text.Encoding]::UTF8.GetString($buf) -split "`r?`n"
        for ($i = $linhas.Count - 1; $i -ge 0; $i--) {
            if ($linhas[$i].IndexOf($texto, [StringComparison]::OrdinalIgnoreCase) -lt 0) { continue }
            # hora: cabeçalho log4net da Invent (":HH:mm:ss0 :::::") ou qualquer HH:mm:ss na linha ou até 4 linhas acima
            for ($k = $i; $k -ge [Math]::Max(0, $i - 4) -and -not $r.ultimoCiclo; $k--) {
                if ($linhas[$k] -match ':(\d{2}):(\d{2}):(\d{2})\d?\s*:::::' -or $linhas[$k] -match '(?<!\d)([01]\d|2[0-3]):([0-5]\d):([0-5]\d)(?!\d)') {
                    $h = $d.Date.AddHours([int]$Matches[1]).AddMinutes([int]$Matches[2]).AddSeconds([int]$Matches[3])
                    if ($h -gt $info.LastWriteTime.AddMinutes(1)) { $h = $h.AddDays(-1) }
                    $r.ultimoCiclo = $h.ToString('o')
                }
            }
            if (-not $r.ultimoCiclo) { $r.ultimoCiclo = $info.LastWriteTime.ToString('o') }
            break
        }
        if ($r.ultimoCiclo) { break }
    }
    if ($texto -and $r.existe -and -not $r.ultimoCiclo) { $r.cicloAusente = $true }
    return $r
}
# a porta do serviço responde? (conexão TCP a partir deste servidor, até 5 s)
function Testar-Porta($s, [int]$porta) {
    $alvo = if (Eh-Local $s) { '127.0.0.1' } else { "$($s.endereco)".Trim() }
    $c = New-Object Net.Sockets.TcpClient; $ini = Get-Date
    try { $ok = $c.ConnectAsync($alvo, $porta).Wait(5000) -and $c.Connected; return @{ ok = [bool]$ok; ms = [int]((Get-Date) - $ini).TotalMilliseconds; erro = $(if ($ok) { '' } else { "a porta $porta de $alvo não respondeu em 5 s" }) } }
    catch { return @{ ok = $false; ms = [int]((Get-Date) - $ini).TotalMilliseconds; erro = $_.Exception.InnerException.Message } } finally { $c.Close() }
}
# o endereço (URL) responde? Qualquer resposta HTTP abaixo de 500 vale (401 sem login também), como no teste da Service Layer
function Testar-Url($url) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls
    [Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }   # certificado próprio do servidor interno
    $ini = Get-Date
    try { $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 15 -Method Get; return @{ ok = $true; status = [int]$r.StatusCode; ms = [int]((Get-Date) - $ini).TotalMilliseconds } }
    catch {
        $resp = $_.Exception.Response
        if ($resp) { $cod = [int]$resp.StatusCode; return @{ ok = ($cod -lt 500); status = $cod; ms = [int]((Get-Date) - $ini).TotalMilliseconds; erro = "HTTP $cod" } }
        return @{ ok = $false; status = 0; ms = [int]((Get-Date) - $ini).TotalMilliseconds; erro = $_.Exception.Message }
    }
}

try {
    if ($Acao -eq 'testar') {
        $s = Cadastro $Servidor
        $n = @(Servicos-Cim $s "Name='Schedule'").Count
        Responder @{ ok = $true; servidor = $s.nome; local = (Eh-Local $s); mensagem = $(if (Eh-Local $s) { 'este servidor' } else { 'conectado' }) }
    }
    if ($Acao -eq 'listar') {
        $s = Cadastro $Servidor
        $lista = Servicos-Cim $s $null
        $logsPorPasta = @{}
        $itens = foreach ($x in $lista) {
            $pastaExe = Pasta-Programa $x.PathName
            $logs = @()
            # qualquer serviço cujo programa grave no padrão <pasta>\logs\AAAA\MM\dd_*.log (Invent e customizados que sigam o padrão);
            # programas do próprio Windows ficam de fora (pasta Windows), para a leitura ser rápida
            if ($pastaExe -and $pastaExe -notmatch '^[A-Za-z]:\\Windows\\') {
                if (-not $logsPorPasta.ContainsKey($pastaExe)) {
                    $hoje = Get-Date
                    $dir = Caminho-Arquivo $s (Join-Path $pastaExe ("logs\{0:yyyy}\{0:MM}" -f $hoje))
                    $logsPorPasta[$pastaExe] = @(Get-ChildItem -LiteralPath $dir -Filter ("{0:dd}_*.log" -f $hoje) -ErrorAction SilentlyContinue |
                        Sort-Object LastWriteTime -Descending | Select-Object -First 60 | ForEach-Object { @{ nome = $_.Name; gravadoEm = $_.LastWriteTime.ToString('o') } })
                }
                $logs = $logsPorPasta[$pastaExe]
            }
            [ordered]@{ nome = $x.Name; exibicao = $x.DisplayName; estado = "$($x.State)"; inicio = "$($x.StartMode)"; programa = "$($x.PathName)"; pastaPrograma = $pastaExe; logsHoje = $logs }
        }
        Responder @{ ok = $true; servidor = $s.nome; local = (Eh-Local $s); servicos = @($itens) }
    }
    if ($Acao -eq 'procurarlog') {
        # procura os logs de um serviço (só leitura): na pasta do programa e na pasta acima dela, até 4 níveis,
        # arquivos .log/.txt gravados nos últimos 3 dias; devolve os mais recentes com o caminho DAQUELE servidor
        $s = Cadastro $Servidor
        $pastaProg = "$Nome".Trim()
        if (-not $pastaProg) { throw 'falta a pasta do programa' }
        $locais = @($pastaProg, (Split-Path $pastaProg)) | Where-Object { $_ -and $_.Length -gt 3 } | Select-Object -Unique
        $desde = (Get-Date).AddDays(-3)
        $vistos = @{}; $achados = New-Object Collections.ArrayList
        foreach ($l in $locais) {
            $real = Caminho-Arquivo $s $l
            foreach ($f in @(Get-ChildItem -LiteralPath $real -Recurse -Depth 4 -File -Include *.log, *.txt -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -ge $desde } | Select-Object -First 3000)) {
                if ($vistos.ContainsKey($f.FullName)) { continue }; $vistos[$f.FullName] = 1
                # caminho de rede (\\end\C$\...) volta para o caminho do servidor (C:\...)
                $local = if (Eh-Local $s) { $f.FullName } elseif ($f.FullName -match '^\\\\[^\\]+\\([A-Za-z])\$\\(.*)$') { "$($Matches[1]):\$($Matches[2])" } else { $f.FullName }
                [void]$achados.Add([ordered]@{ caminho = $local; gravadoEm = $f.LastWriteTime.ToString('o'); kb = [int]($f.Length / 1KB) })
            }
        }
        Responder @{ ok = $true; servidor = $s.nome; logs = @($achados | Sort-Object { $_.gravadoEm } -Descending | Select-Object -First 25) }
    }
    if ($Acao -eq 'estado') {
        $mon = @(if ($sw -and $sw.monitorados) { $sw.monitorados | ForEach-Object { $_ } })
        $porServidor = $mon | Group-Object { "$($_.servidor)" }
        $saida = New-Object Collections.ArrayList; $erros = @{}
        foreach ($g in $porServidor) {
            $s = Cadastro $g.Name
            try {
                $nomes = @($g.Group | ForEach-Object { "Name='" + ("$($_.nome)" -replace "'", "''") + "'" })
                $achados = @{}; foreach ($x in (Servicos-Cim $s ($nomes -join ' OR '))) { $achados[$x.Name.ToLower()] = $x }
                # não achou pelo nome exato: procura pelo nome SEM a versão (a Invent põe a versão no nome e ele muda ao atualizar o add-on)
                foreach ($m in $g.Group) { if (-not $achados.ContainsKey("$($m.nome)".ToLower())) { $y = Achar-PelaBase $s "$($m.nome)"; if ($y) { $achados["$($m.nome)".ToLower()] = $y } } }
                $procs = @{}
                $pids = @($achados.Values | Where-Object { $_.ProcessId } | ForEach-Object { $_.ProcessId })
                if ($pids.Count) {
                    $p = @{ ClassName = 'Win32_Process'; Filter = (($pids | ForEach-Object { "ProcessId=$_" }) -join ' OR ') }; $sess = Sessao $s; if ($sess) { $p.CimSession = $sess }
                    foreach ($pr in @(Get-CimInstance @p)) { $procs[[int]$pr.ProcessId] = $pr }
                }
                foreach ($m in $g.Group) {
                    $x = $achados["$($m.nome)".ToLower()]
                    $item = [ordered]@{ servidor = $s.nome; nome = "$($m.nome)"; nomeReal = $(if ($x) { "$($x.Name)" } else { '' }); existe = [bool]$x; estado = ''; inicio = ''; pid = 0; memoriaMB = 0; cpuSeg = 0; log = $null }
                    if ($x) {
                        $item.estado = "$($x.State)"; $item.inicio = "$($x.StartMode)"; $item.pid = [int]$x.ProcessId
                        $pr = $procs[[int]$x.ProcessId]
                        if ($pr) { $item.memoriaMB = [int]($pr.WorkingSetSize / 1MB); $item.cpuSeg = [int](([double]$pr.KernelModeTime + [double]$pr.UserModeTime) / 1e7) }
                    }
                    # texto do ciclo: o da tela; cadastro antigo (sem o campo) = "[Completed]" da Invent
                    $textoCiclo = if ($m.PSObject.Properties.Name -contains 'texto_ciclo') { "$($m.texto_ciclo)".Trim() } else { '[Completed]' }
                    if ("$($m.log)".Trim()) { try { $item.log = Vida-Do-Log $s "$($m.log)".Trim() $textoCiclo } catch { $item.log = @{ erro = $_.Exception.Message } } }
                    if ([int]"0$($m.porta)" -gt 0 -and $x -and "$($x.State)" -eq 'Running') { $item.porta = Testar-Porta $s ([int]$m.porta) }
                    if ("$($m.url)".Trim() -and $x -and "$($x.State)" -eq 'Running') { $item.url = Testar-Url "$($m.url)".Trim() }
                    [void]$saida.Add($item)
                }
            } catch { $erros[$s.nome] = $_.Exception.Message }
        }
        Responder @{ ok = $true; agora = (Get-Date).ToString('o'); servicos = @($saida); errosServidor = $erros }
    }
    if ($Acao -in 'reiniciar', 'iniciar') {
        $s = Cadastro $Servidor
        $x = @(Servicos-Cim $s ("Name='" + ($Nome -replace "'", "''") + "'")) | Select-Object -First 1
        if (-not $x) { $x = Achar-PelaBase $s $Nome }
        if (-not $x) { throw "serviço '$Nome' não encontrado em $($s.nome)" }
        $Nome = "$($x.Name)"   # pode ser o nome novo (versão nova do add-on)
        $sess = Sessao $s
        $passos = @()
        # espera pelo RELÓGIO (cada consulta ao Windows leva 1-2 s: contar voltas dobrava o tempo)
        function Esperar($alvo, $seg) {
            $limite = (Get-Date).AddSeconds($seg)
            do {
                $y = @(Servicos-Cim $s ("Name='" + ($Nome -replace "'", "''") + "'")) | Select-Object -First 1
                if ("$($y.State)" -eq $alvo) { return $y }
                Start-Sleep -Seconds 1
            } while ((Get-Date) -lt $limite)
            return $y
        }
        if ($Acao -eq 'reiniciar' -and "$($x.State)" -ne 'Stopped') {
            $r = Invoke-CimMethod -InputObject $x -MethodName StopService
            $passos += "parar (código $($r.ReturnValue))"
            $y = Esperar 'Stopped' 60
            if ("$($y.State)" -ne 'Stopped') {
                if (-not $Forcar) { throw "o serviço não parou em 60 s (estado $($y.State)); encerrar o processo à força está desligado para ele" }
                if ($y.ProcessId) {
                    $p = @{ ClassName = 'Win32_Process'; Filter = "ProcessId=$($y.ProcessId)" }; if ($sess) { $p.CimSession = $sess }
                    $proc = Get-CimInstance @p
                    if ($proc) { [void](Invoke-CimMethod -InputObject $proc -MethodName Terminate); $passos += "processo $($y.ProcessId) encerrado à força" }
                }
                $y = Esperar 'Stopped' 20
            }
            $x = $y
        }
        $r = Invoke-CimMethod -InputObject $x -MethodName StartService
        $passos += "ligar (código $($r.ReturnValue))"
        $y = Esperar 'Running' 60
        Responder @{ ok = ("$($y.State)" -eq 'Running'); servidor = $s.nome; nome = $Nome; estado = "$($y.State)"; pid = [int]$y.ProcessId; passos = $passos }
    }
    Responder @{ ok = $false; erro = "ação desconhecida: $Acao" }
} catch {
    Responder @{ ok = $false; erro = $_.Exception.Message }
} finally {
    foreach ($s in $sessoes.Values) { try { Remove-CimSession $s } catch { } }
}
