﻿# Abre uma senha criptografada do config.json (chave DESTA máquina) e devolve os bytes em base64.
# Chamado pelo monitoramento_sl.js:  abrir_senha.ps1 -Campo controller_senha_cripto
param([string]$Campo)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security
$pasta = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfg = [IO.File]::ReadAllText((Join-Path $pasta 'config.json')) | ConvertFrom-Json
$cripto = [string]$cfg.$Campo
if (-not $cripto) { exit 0 }
[Console]::Write([Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($cripto), $null, 'LocalMachine')))