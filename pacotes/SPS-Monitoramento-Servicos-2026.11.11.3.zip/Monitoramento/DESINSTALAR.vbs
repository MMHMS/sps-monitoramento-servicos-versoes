' Desinstala o Monitoramento da Service Layer (dois cliques; pede permissao de administrador).
Dim fso, pasta, unidade
Set fso = CreateObject("Scripting.FileSystemObject")
pasta = fso.GetParentFolderName(WScript.ScriptFullName)
' unidade de rede mapeada (ex.: Z:) some quando pede administrador: troca pelo caminho \\servidor\pasta
If Mid(pasta, 2, 1) = ":" Then
    Set unidade = fso.GetDrive(Left(pasta, 2))
    If unidade.DriveType = 3 Then pasta = unidade.ShareName & Mid(pasta, 3)
End If
CreateObject("Shell.Application").ShellExecute "powershell.exe", "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & pasta & "\desinstalar.ps1""", pasta, "runas", 0
