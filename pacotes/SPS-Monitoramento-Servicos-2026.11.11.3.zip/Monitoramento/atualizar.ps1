<#
  SPS Monitoramento de Servicos - ATUALIZADOR (tarefa do Windows "\SPS Group\Monitoramento de Servicos - Atualizador").

  Roda como SISTEMA, a cada minuto, mas so abre este script quando a tela de configuracao
  (aba Versao, botao "Atualizar") deixou um pedido em <pasta do monitoramento>\atualizacoes\pedido.json.

  Passos:
    1. confere de novo o pacote com o atualizacao.js da versao JA INSTALADA
       (carimbo da SPS na ficha + SHA-256 e tamanho do zip) - sem isso, nao instala nada;
    2. extrai o zip numa pasta temporaria e roda o instalar.ps1 sem janela (por cima, mantendo
       config.json, tempos.json, logs, dados e o Node);
    3. escreve o andamento em atualizacoes\estado-instalador.json (a tela mostra)
       e tudo em logs\atualizacao.log.
#>
$ErrorActionPreference = 'Stop'
# o Node escreve em UTF-8: sem isto os acentos das mensagens chegam estragados
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
$Programa = $PSScriptRoot
$Pasta = Join-Path $Programa 'atualizacoes'
$Pedido = Join-Path $Pasta 'pedido.json'
if (-not (Test-Path -LiteralPath $Pedido)) { exit 0 }   # nada pedido: sai sem fazer nada

$Log = Join-Path $Programa 'logs\atualizacao.log'
$Utf8 = New-Object Text.UTF8Encoding($false)
function Log([string]$t) {
    New-Item -ItemType Directory -Force (Split-Path $Log) | Out-Null
    [IO.File]::AppendAllText($Log, "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $t`r`n", $Utf8)
}
function Estado([string]$fase, [string]$mensagem) {
    $json = @{ fase = $fase; mensagem = $mensagem; quando = (Get-Date).ToString('o') } | ConvertTo-Json -Compress
    [IO.File]::WriteAllText((Join-Path $Pasta 'estado-instalador.json'), $json, $Utf8)
}

# uma atualizacao por vez (trava com validade de 30 min, caso algo tenha caido no meio)
$Trava = Join-Path $Pasta 'instalando.trava'
if ((Test-Path -LiteralPath $Trava) -and ((Get-Date) - (Get-Item -LiteralPath $Trava).LastWriteTime).TotalMinutes -lt 30) { exit 0 }
Set-Content -LiteralPath $Trava (Get-Date -Format o) -Encoding ASCII

$EmAndamento = Join-Path $Pasta 'pedido-em-andamento.json'
$Temp = $null
try {
    Move-Item -LiteralPath $Pedido $EmAndamento -Force   # o pedido nao roda duas vezes
    Log '----- pedido de atualizacao recebido -----'
    Estado 'conferindo' 'Conferindo o carimbo da SPS e a impressao digital do pacote...'

    # 1. conferencia com a versao instalada
    $node = Join-Path $Programa 'node\node.exe'
    if (-not (Test-Path -LiteralPath $node)) { $cmdNode = Get-Command node.exe -ErrorAction SilentlyContinue; $node = if ($cmdNode) { $cmdNode.Source } else { '' } }
    $conferir = Join-Path $Programa 'atualizacao.js'
    if (-not $node -or -not (Test-Path -LiteralPath $conferir)) { throw 'instalacao atual incompleta (Node ou atualizacao.js ausente)' }
    $saida = (& $node $conferir conferir $EmAndamento | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $saida -notmatch '^OK (\S+) (.+)$') { throw "pacote recusado: $saida" }
    $versao = $Matches[1]; $zip = $Matches[2].Trim()
    Log "pacote conferido: versao $versao ($zip)"
    Estado 'instalando' "Instalando a versao $versao..."

    # 2. extrai e instala por cima (sem janela), na MESMA pasta onde o monitoramento esta hoje
    $Temp = Join-Path $env:TEMP "sps-monitoramento-atualizacao-$versao"
    if (Test-Path -LiteralPath $Temp) { Remove-Item -LiteralPath $Temp -Recurse -Force }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::ExtractToDirectory($zip, $Temp)
    $instalador = Get-ChildItem -LiteralPath $Temp -Recurse -Filter 'instalar.ps1' | Select-Object -First 1
    if (-not $instalador) { throw 'instalar.ps1 nao encontrado no pacote' }
    Log "instalando a partir de $($instalador.DirectoryName) em $Programa"
    $saidaInst = (& powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $instalador.FullName -Destino $Programa -SemJanela 2>&1 | Out-String)
    $codigo = $LASTEXITCODE
    Log $saidaInst.Trim()
    if ($codigo -ne 0) { throw "o instalador terminou com erro (codigo $codigo). Veja $Log" }
    Estado 'concluido' "Versao $versao instalada."
    Log "versao $versao instalada"
} catch {
    $msg = $_.Exception.Message
    Log "ERRO: $msg"
    try { Estado 'erro' "Atualizacao nao concluida: $msg" } catch { }
} finally {
    Remove-Item -LiteralPath $EmAndamento -Force -ErrorAction SilentlyContinue
    if ($Temp -and (Test-Path -LiteralPath $Temp)) { Remove-Item -LiteralPath $Temp -Recurse -Force -ErrorAction SilentlyContinue }
    # o pacote baixado nao serve mais: instalado ou recusado, uma nova tentativa baixa de novo
    Get-ChildItem -LiteralPath $Pasta -Filter 'SPS-Monitoramento-Servicos-*.zip*' -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $Trava -Force -ErrorAction SilentlyContinue
}
