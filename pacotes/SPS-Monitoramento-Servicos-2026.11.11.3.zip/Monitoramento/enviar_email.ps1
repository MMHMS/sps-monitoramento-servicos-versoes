﻿# Envia o e-mail do monitoramento pelo SMTP do config.json (senha criptografada pela máquina).
# Chamado pelo monitoramento_sl.js; não precisa rodar na mão.
param([string]$Assunto, [string]$Para, [string]$ArquivoHtml)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security
$pasta = Split-Path -Parent $MyInvocation.MyCommand.Path

$cfg = [IO.File]::ReadAllText((Join-Path $pasta 'config.json')) | ConvertFrom-Json
if ($cfg.smtp_senha_cripto) {
    $texto = [Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($cfg.smtp_senha_cripto), $null, 'LocalMachine'))
} else {
    $texto = [string]$cfg.smtp_senha
}
$cred = New-Object Management.Automation.PSCredential($cfg.smtp_usuario, (ConvertTo-SecureString $texto -AsPlainText -Force))
$html = [IO.File]::ReadAllText($ArquivoHtml, [Text.Encoding]::UTF8)
$destinatarios = $Para -split '[,;]' | ForEach-Object { $_.Trim() } | Where-Object { $_ }

# servidores de e-mail atuais exigem TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Send-MailMessage -SmtpServer $cfg.smtp_servidor -Port $cfg.smtp_porta -UseSsl:([bool]$cfg.smtp_ssl) -Credential $cred `
    -From $cfg.email_remetente -To $destinatarios -Subject $Assunto -Body $html -BodyAsHtml -Encoding UTF8