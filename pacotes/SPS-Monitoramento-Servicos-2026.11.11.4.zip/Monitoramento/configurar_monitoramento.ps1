﻿# SPS Monitoramento de Serviços - TELA DE CONFIGURAÇÃO (WPF, visual do SPS MCP Consultor: cartões, modo dia/noite).
# Lê e grava os MESMOS arquivos da versão anterior: config.json (Service Layers, Controller, e-mail, avisos) e tempos.json.
# As senhas são criptografadas com a chave DESTA máquina (DPAPI LocalMachine): só este servidor consegue abrir.
# Abrir: ícone "Monitoramento da Service Layer" na área de trabalho (abrir_monitoramento.vbs, como administrador).
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Xaml, System.Security
Add-Type -Namespace Monit -Name Dwm -MemberDefinition '[DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr h, int a, ref int v, int s);'
# identidade própria na barra de tarefas (senão agrupa com o PowerShell)
Add-Type -Namespace Monit -Name App -MemberDefinition '[DllImport("shell32.dll", CharSet = CharSet.Unicode)] public static extern int SetCurrentProcessExplicitAppUserModelID(string id);'
[void][Monit.App]::SetCurrentProcessExplicitAppUserModelID('SPSGroup.MonitoramentoServiceLayer')

$pasta = Split-Path -Parent $MyInvocation.MyCommand.Path
$arqConfig = Join-Path $pasta 'config.json'
$arqTempos = Join-Path $pasta 'tempos.json'
$nomeTarefa = 'Monitoramento Service Layer'
$nomeAtualizador = 'Monitoramento de Servicos - Atualizador'
$TITULO = 'Monitoramento de Serviços'

# ---------- arquivos ----------
function Ler-Json($arq) {
    if (Test-Path -LiteralPath $arq) { try { return [IO.File]::ReadAllText($arq) | ConvertFrom-Json } catch { } }
    return $null
}
function Gravar-Json($arq, $obj) {
    [IO.File]::WriteAllText($arq, ($obj | ConvertTo-Json -Depth 6), (New-Object Text.UTF8Encoding $false))
}
function Valor($obj, $nome, $padrao) {
    if ($obj -and ($obj.PSObject.Properties.Name -contains $nome) -and "$($obj.$nome)" -ne '') { return $obj.$nome }
    return $padrao
}
# confere se os servidores dos caminhos existem na rede (consulta de DNS, só leitura); devolve os que não foram encontrados
function Servidores-NaoEncontrados($caminhos) {
    $faltam = @()
    $nomes = @($caminhos | ForEach-Object { try { ([Uri]"$_").Host } catch { } } | Where-Object { $_ } | Sort-Object -Unique)
    foreach ($n in $nomes) { try { [void][Net.Dns]::GetHostAddresses($n) } catch { $faltam += $n } }
    return $faltam
}
function Cripto($texto) {
    [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($texto), $null, 'LocalMachine'))
}
function TemSenha($cripto, $texto) { return [bool](("$cripto" -ne '') -or ("$texto" -ne '')) }

# ---------- log de alterações: quem mudou o quê e quando ----------
# logs\alteracoes\USUARIO\AAAA-MM.log: uma linha por campo alterado, a mais recente no topo. Senha nunca vai para o log.
$script:quemExecuta = [Security.Principal.WindowsIdentity]::GetCurrent().Name
$script:quemLogado = $script:quemExecuta
try {
    $sessao = (Get-Process -Id $PID).SessionId
    $explorer = Get-CimInstance Win32_Process -Filter "Name='explorer.exe'" -ErrorAction Stop | Where-Object { $_.SessionId -eq $sessao } | Select-Object -First 1
    if ($explorer) { $dono = Invoke-CimMethod -InputObject $explorer -MethodName GetOwner -ErrorAction Stop; if ($dono.User) { $script:quemLogado = "$($dono.Domain)\$($dono.User)" } }
} catch { }
function Texto-Log($v) {
    if ($null -eq $v) { return '(vazio)' }
    if ($v -is [bool]) { if ($v) { return 'Sim' } else { return 'Não' } }
    $t = "$v".Trim(); if ($t -eq '') { return '(vazio)' }; return $t
}
function Mudou($onde, $antes, $depois) {
    $a = Texto-Log $antes; $d = Texto-Log $depois
    if ($a -ceq $d) { return }
    return "$onde | antes: $a | depois: $d"
}
function Registrar-Alteracoes($itens) {
    $itens = @($itens | Where-Object { $_ })
    if (-not $itens.Count) { return }
    try {
        $quem = $script:quemLogado + $(if ($script:quemExecuta -ne $script:quemLogado) { " (executado como $($script:quemExecuta))" } else { '' })
        $agora = (Get-Date).ToString('dd/MM/yyyy HH:mm:ss')
        $dir = Join-Path $pasta ('logs\alteracoes\' + ($script:quemLogado -replace '[^A-Za-z0-9_.-]', '_'))
        [void][IO.Directory]::CreateDirectory($dir)
        $arq = Join-Path $dir ((Get-Date).ToString('yyyy-MM') + '.log')
        $cabecalho = "# Alterações na configuração do monitoramento feitas por $($script:quemLogado) - a mais recente no topo"
        $novas = @($itens | ForEach-Object { "$agora | $quem | máquina $env:COMPUTERNAME | $_" })
        $antigas = @()
        if (Test-Path -LiteralPath $arq) { $antigas = @([IO.File]::ReadAllLines($arq) | Where-Object { $_ -and -not $_.StartsWith('#') }) }
        [IO.File]::WriteAllLines($arq, [string[]](@($cabecalho) + $novas + $antigas), (New-Object Text.UTF8Encoding $true))
    } catch { Aviso ("A alteração foi feita, mas não consegui gravar o log de alterações:`n" + $_.Exception.Message) 'Warning' | Out-Null }
}

$cfg = Ler-Json $arqConfig
$tmp = Ler-Json $arqTempos

# campo, padrão, nome na tela, explicação, grupo  (os grupos da Service Layer ficam na página dela; "Logs" em Tempos gerais)
$camposTempo = @(
    @('segundos_entre_verificacoes', 10, 'Intervalo entre verificações', 'segundos entre um teste e outro', 'Verificação'),
    @('segundos_por_execucao', 50, 'Duração de cada execução', 'segundos verificando a cada minuto (menor que 60)', 'Verificação'),
    @('segundos_sem_resposta', 30, 'Tempo máximo de espera', 'segundos sem resposta = Service Layer parada', 'Quando considerar falha'),
    @('segundos_lentidao', 10, 'Limite de lentidão', 'segundos; respondeu acima disso = lenta', 'Quando considerar falha'),
    @('falhas_sem_resposta', 1, 'Parada: reiniciar após', 'verificações seguidas sem resposta (1 = na hora)', 'Quando considerar falha'),
    @('falhas_lentidao', 3, 'Lenta: reiniciar após', 'verificações seguidas lentas', 'Quando considerar falha'),
    @('segundos_confirmar', 30, 'Espera da confirmação', 'segundos aguardando o Controller confirmar', 'Reinício'),
    @('comandos_por_execucao', 3, 'Tentativas de ligar', 'vezes que manda o start se não confirmar', 'Reinício'),
    @('minutos_esperar_voltar', 5, 'Espera pela volta', 'minutos; depois avisa "acionar o NOC"', 'Reinício'),
    @('minutos_entre_reinicios', 0, 'Intervalo entre reinícios', 'minutos mínimos entre um e outro (0 = sem)', 'Reinício'),
    @('horas_parar_reinicio', 24, 'Suspender reinício após', 'horas fora sem parar; avisa 1x por dia (0 = nunca)', 'Reinício'),
    @('minutos_medir_memoria', 15, 'Medir a memória a cada', 'minutos (0 = não mede)', 'Memória'),
    @('alerta_memoria_gb', 0, 'Alerta de memória', 'GB; acima disso manda e-mail (0 = desligado)', 'Memória'),
    @('limite_memoria_gb', 0, 'Reinício por memória', 'GB; acima disso reinicia (0 = desligado)', 'Memória'),
    @('medicoes_memoria', 3, 'Confirmar memória alta em', 'medições seguidas antes de reiniciar', 'Memória'),
    @('janela_reinicio_memoria', '00:00-05:00', 'Horário permitido', 'reinício por memória só neste horário', 'Memória'),
    @('dias_manter_logs', 30, 'Guardar os logs por', 'dias (os mais antigos são apagados)', 'Logs')
)
$tiposAviso = @(@('indisponivel', 'Indisponível'), @('reiniciando', 'Reiniciando'), @('restabelecida', 'Restabelecida'),
    @('memoria', 'Memória elevada'), @('falhas', 'Falha no reinício / acionar o NOC'))

# =====================================================================================================
# APARÊNCIA: identidade SPS (as mesmas cores do SPS MCP Consultor e do painel do SPS MCP B1)
# =====================================================================================================
$TEMAS = @{
    claro  = @{ Fundo = '#F4F6FB'; Cartao = '#FFFFFF'; Texto = '#1A1D3A'; TextoSec = '#5D6380'; Borda = '#DFE3EE'; Campo = '#FFFFFF'; CampoBorda = '#CDD3E1'
                Selecao = '#E9EEFB'; Hover = '#F1F4FA'; Titulo = '#0C0068'; Primario = '#0C0068'; Link = '#0085E5'
                Ok = '#0F7D5F'; OkFundo = '#E3F6F1'; Erro = '#B3261E'; ErroFundo = '#FBE9E7'; Alerta = '#7A4B00'; AlertaFundo = '#FFF4DC' }
    escuro = @{ Fundo = '#0B1020'; Cartao = '#171D31'; Texto = '#E4E8F2'; TextoSec = '#9AA3B9'; Borda = '#2A3350'; Campo = '#0F1424'; CampoBorda = '#33405F'
                Selecao = '#22305A'; Hover = '#1D2540'; Titulo = '#C3CDFF'; Primario = '#3D52D5'; Link = '#7FB2FF'
                Ok = '#4FD1A5'; OkFundo = '#12342B'; Erro = '#FF8F87'; ErroFundo = '#3B1D1F'; Alerta = '#FFCF70'; AlertaFundo = '#36290F' }
}
$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Monitoramento de Serviços - Configuração" Width="1120" Height="800" MinWidth="760" MinHeight="520"
        WindowStartupLocation="CenterScreen" Background="{DynamicResource B.Fundo}"
        FontFamily="Segoe UI Variable Text, Segoe UI" FontSize="13" UseLayoutRounding="True" SnapsToDevicePixels="True" TextOptions.TextFormattingMode="Display">
  <Window.Resources>
    <LinearGradientBrush x:Key="B.Degrade" StartPoint="0,0" EndPoint="1,0">
      <GradientStop Color="#00C7B0" Offset="0"/><GradientStop Color="#00A5CD" Offset="0.5"/><GradientStop Color="#0085E5" Offset="1"/>
    </LinearGradientBrush>
    <Style x:Key="BotaoBase" TargetType="Button">
      <Setter Property="Cursor" Value="Hand"/><Setter Property="Padding" Value="16,8"/><Setter Property="FontSize" Value="13"/>
      <Setter Property="BorderThickness" Value="1"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button">
        <Border x:Name="B" CornerRadius="8" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" Padding="{TemplateBinding Padding}">
          <ContentPresenter HorizontalAlignment="{TemplateBinding HorizontalContentAlignment}" VerticalAlignment="Center"/></Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="Opacity" Value="0.86"/></Trigger>
          <Trigger Property="IsPressed" Value="True"><Setter TargetName="B" Property="Opacity" Value="0.72"/></Trigger>
          <Trigger Property="IsEnabled" Value="False"><Setter TargetName="B" Property="Opacity" Value="0.45"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="BotaoPrimario" TargetType="Button" BasedOn="{StaticResource BotaoBase}">
      <Setter Property="Background" Value="{DynamicResource B.Primario}"/><Setter Property="BorderBrush" Value="{DynamicResource B.Primario}"/>
      <Setter Property="Foreground" Value="White"/><Setter Property="FontWeight" Value="SemiBold"/></Style>
    <Style x:Key="BotaoSecundario" TargetType="Button" BasedOn="{StaticResource BotaoBase}">
      <Setter Property="Background" Value="{DynamicResource B.Cartao}"/><Setter Property="BorderBrush" Value="{DynamicResource B.Borda}"/>
      <Setter Property="Foreground" Value="{DynamicResource B.Titulo}"/></Style>
    <Style x:Key="BotaoPerigo" TargetType="Button" BasedOn="{StaticResource BotaoSecundario}">
      <Setter Property="Foreground" Value="{DynamicResource B.Erro}"/></Style>
    <Style x:Key="BotaoLink" TargetType="Button" BasedOn="{StaticResource BotaoBase}">
      <Setter Property="Background" Value="Transparent"/><Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Foreground" Value="{DynamicResource B.Link}"/><Setter Property="Padding" Value="6,6"/>
      <Setter Property="HorizontalContentAlignment" Value="Left"/></Style>
    <!-- "adicionar": caixa tracejada da largura toda, ícone + num círculo -->
    <Style x:Key="BotaoAdicionar" TargetType="Button">
      <Setter Property="Cursor" Value="Hand"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/><Setter Property="Foreground" Value="{DynamicResource B.Link}"/>
      <Setter Property="HorizontalAlignment" Value="Stretch"/><Setter Property="Margin" Value="0,2,0,0"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button">
        <Grid x:Name="G" Background="Transparent" MinHeight="44">
          <Rectangle x:Name="R" RadiusX="9" RadiusY="9" StrokeDashArray="5 4" StrokeThickness="1.3" Stroke="{DynamicResource B.CampoBorda}"/>
          <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="0,8">
            <Border x:Name="C" Width="22" Height="22" CornerRadius="11" Background="{DynamicResource B.Selecao}" Margin="0,0,10,0">
              <TextBlock Text="&#xE710;" FontFamily="Segoe MDL2 Assets" FontSize="10" Foreground="{DynamicResource B.Link}" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border>
            <ContentPresenter VerticalAlignment="Center" TextElement.FontWeight="SemiBold"/>
          </StackPanel>
        </Grid>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="R" Property="Stroke" Value="{DynamicResource B.Link}"/><Setter TargetName="R" Property="Fill" Value="{DynamicResource B.Hover}"/></Trigger>
          <Trigger Property="IsPressed" Value="True"><Setter TargetName="G" Property="Opacity" Value="0.75"/></Trigger>
          <Trigger Property="IsEnabled" Value="False"><Setter TargetName="G" Property="Opacity" Value="0.4"/><Setter Property="Cursor" Value="Arrow"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="Entrada" TargetType="TextBox">
      <Setter Property="Foreground" Value="{DynamicResource B.Texto}"/><Setter Property="CaretBrush" Value="{DynamicResource B.Texto}"/>
      <Setter Property="Background" Value="{DynamicResource B.Campo}"/><Setter Property="BorderBrush" Value="{DynamicResource B.CampoBorda}"/>
      <Setter Property="Padding" Value="7,0"/><Setter Property="Height" Value="38"/><Setter Property="VerticalContentAlignment" Value="Center"/><Setter Property="FontSize" Value="13"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="TextBox">
        <Border x:Name="B" CornerRadius="7" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1">
          <ScrollViewer x:Name="PART_ContentHost" Margin="{TemplateBinding Padding}" VerticalAlignment="{TemplateBinding VerticalContentAlignment}"/></Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="BorderBrush" Value="{DynamicResource B.TextoSec}"/></Trigger>
          <Trigger Property="IsKeyboardFocused" Value="True"><Setter TargetName="B" Property="BorderBrush" Value="{DynamicResource B.Link}"/><Setter TargetName="B" Property="BorderThickness" Value="1.5"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="Senha" TargetType="PasswordBox">
      <Setter Property="Foreground" Value="{DynamicResource B.Texto}"/><Setter Property="CaretBrush" Value="{DynamicResource B.Texto}"/>
      <Setter Property="Background" Value="{DynamicResource B.Campo}"/><Setter Property="BorderBrush" Value="{DynamicResource B.CampoBorda}"/>
      <Setter Property="Padding" Value="7,0"/><Setter Property="Height" Value="38"/><Setter Property="VerticalContentAlignment" Value="Center"/><Setter Property="FontSize" Value="13"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="PasswordBox">
        <Border x:Name="B" CornerRadius="7" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1">
          <ScrollViewer x:Name="PART_ContentHost" Margin="{TemplateBinding Padding}" VerticalAlignment="Center"/></Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="BorderBrush" Value="{DynamicResource B.TextoSec}"/></Trigger>
          <Trigger Property="IsKeyboardFocused" Value="True"><Setter TargetName="B" Property="BorderBrush" Value="{DynamicResource B.Link}"/><Setter TargetName="B" Property="BorderThickness" Value="1.5"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="Chave" TargetType="CheckBox">
      <Setter Property="Cursor" Value="Hand"/><Setter Property="Foreground" Value="{DynamicResource B.Texto}"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="CheckBox">
        <StackPanel Orientation="Horizontal" Background="Transparent">
          <Border x:Name="T" Width="34" Height="18" CornerRadius="9" Background="{DynamicResource B.CampoBorda}" VerticalAlignment="Center">
            <Ellipse x:Name="E" Width="14" Height="14" Fill="White" HorizontalAlignment="Left" Margin="2,0"/></Border>
          <ContentPresenter Margin="9,0,0,0" VerticalAlignment="Center"/>
        </StackPanel>
        <ControlTemplate.Triggers>
          <Trigger Property="IsChecked" Value="True"><Setter TargetName="T" Property="Background" Value="{DynamicResource B.Link}"/><Setter TargetName="E" Property="HorizontalAlignment" Value="Right"/></Trigger>
          <Trigger Property="IsEnabled" Value="False"><Setter Property="Opacity" Value="0.5"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <!-- escolha lado a lado (servidor, filtro): botões que ficam marcados -->
    <Style x:Key="Segmento" TargetType="RadioButton">
      <Setter Property="Cursor" Value="Hand"/><Setter Property="Foreground" Value="{DynamicResource B.TextoSec}"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="RadioButton">
        <Border x:Name="B" CornerRadius="7" Padding="12,5" Margin="0,0,6,6" Background="{DynamicResource B.Hover}"><ContentPresenter HorizontalAlignment="Center"/></Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="Background" Value="{DynamicResource B.Selecao}"/></Trigger>
          <Trigger Property="IsChecked" Value="True"><Setter TargetName="B" Property="Background" Value="{DynamicResource B.Primario}"/><Setter Property="Foreground" Value="White"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="Lista" TargetType="ComboBox">
      <Setter Property="Foreground" Value="{DynamicResource B.Texto}"/><Setter Property="FontSize" Value="12.5"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ComboBox">
        <Grid>
          <ToggleButton Focusable="False" ClickMode="Press" Cursor="Hand" IsChecked="{Binding IsDropDownOpen, Mode=TwoWay, RelativeSource={RelativeSource TemplatedParent}}">
            <ToggleButton.Template><ControlTemplate TargetType="ToggleButton">
              <Border x:Name="B" CornerRadius="7" Background="{DynamicResource B.Campo}" BorderBrush="{DynamicResource B.CampoBorda}" BorderThickness="1">
                <TextBlock Text="&#xE70D;" FontFamily="Segoe MDL2 Assets" FontSize="10" HorizontalAlignment="Right" VerticalAlignment="Center" Margin="0,0,11,0" Foreground="{DynamicResource B.TextoSec}"/></Border>
              <ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="BorderBrush" Value="{DynamicResource B.TextoSec}"/></Trigger></ControlTemplate.Triggers>
            </ControlTemplate></ToggleButton.Template>
          </ToggleButton>
          <ContentPresenter IsHitTestVisible="False" Margin="10,7,30,7" VerticalAlignment="Center" Content="{TemplateBinding SelectionBoxItem}"/>
          <Popup IsOpen="{TemplateBinding IsDropDownOpen}" Placement="Bottom" AllowsTransparency="True" Focusable="False" PopupAnimation="Fade">
            <Border Background="{DynamicResource B.Cartao}" BorderBrush="{DynamicResource B.Borda}" BorderThickness="1" CornerRadius="8" Margin="0,4,0,0"
                    MinWidth="{Binding ActualWidth, RelativeSource={RelativeSource TemplatedParent}}" MaxHeight="280" Padding="4">
              <ScrollViewer><ItemsPresenter/></ScrollViewer></Border>
          </Popup>
        </Grid>
      </ControlTemplate></Setter.Value></Setter>
      <Setter Property="ItemContainerStyle"><Setter.Value><Style TargetType="ComboBoxItem">
        <Setter Property="Foreground" Value="{DynamicResource B.Texto}"/><Setter Property="Cursor" Value="Hand"/>
        <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ComboBoxItem">
          <Border x:Name="B" CornerRadius="6" Padding="10,6" Background="Transparent"><ContentPresenter/></Border>
          <ControlTemplate.Triggers><Trigger Property="IsHighlighted" Value="True"><Setter TargetName="B" Property="Background" Value="{DynamicResource B.Selecao}"/></Trigger></ControlTemplate.Triggers>
        </ControlTemplate></Setter.Value></Setter>
      </Style></Setter.Value></Setter>
    </Style>
    <Style x:Key="Opcao" TargetType="RadioButton">
      <Setter Property="Cursor" Value="Hand"/><Setter Property="Foreground" Value="{DynamicResource B.Texto}"/><Setter Property="Margin" Value="0,0,0,8"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="RadioButton">
        <StackPanel Orientation="Horizontal" Background="Transparent">
          <Border x:Name="C" Width="18" Height="18" CornerRadius="9" BorderThickness="1.5" BorderBrush="{DynamicResource B.CampoBorda}" Background="{DynamicResource B.Campo}" VerticalAlignment="Center">
            <Ellipse x:Name="P" Width="8" Height="8" Fill="{DynamicResource B.Link}" Visibility="Collapsed"/></Border>
          <ContentPresenter Margin="9,0,0,0" VerticalAlignment="Center"/>
        </StackPanel>
        <ControlTemplate.Triggers><Trigger Property="IsChecked" Value="True">
          <Setter TargetName="P" Property="Visibility" Value="Visible"/><Setter TargetName="C" Property="BorderBrush" Value="{DynamicResource B.Link}"/></Trigger></ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
    <Style x:Key="ItemMenu" TargetType="ListBoxItem">
      <Setter Property="Cursor" Value="Hand"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ListBoxItem">
        <Border x:Name="B" CornerRadius="9" Padding="12,7" Margin="0,0,0,2" Background="Transparent" BorderThickness="1" BorderBrush="Transparent"><ContentPresenter/></Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="Background" Value="{DynamicResource B.Hover}"/></Trigger>
          <Trigger Property="IsSelected" Value="True"><Setter TargetName="B" Property="Background" Value="{DynamicResource B.Selecao}"/><Setter TargetName="B" Property="BorderBrush" Value="{DynamicResource B.Link}"/></Trigger>
          <Trigger Property="IsEnabled" Value="False"><Setter Property="Cursor" Value="Arrow"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
  </Window.Resources>
  <DockPanel Background="{DynamicResource B.Fundo}">
    <StackPanel DockPanel.Dock="Top">
      <Border Background="{DynamicResource B.Cartao}" Padding="24,12"><DockPanel>
        <StackPanel DockPanel.Dock="Right" Orientation="Horizontal" VerticalAlignment="Center">
          <Border x:Name="SeloTopo" CornerRadius="12" Padding="10,4" Margin="0,0,14,0" VerticalAlignment="Center">
            <StackPanel Orientation="Horizontal"><Ellipse x:Name="SeloBola" Width="8" Height="8" Margin="0,0,7,0" VerticalAlignment="Center"/><TextBlock x:Name="SeloTexto" FontSize="12"/></StackPanel></Border>
          <TextBlock x:Name="TxtVersao" Foreground="{DynamicResource B.TextoSec}" FontSize="12" VerticalAlignment="Center" Margin="0,0,14,0"/>
          <Button x:Name="BtnManual" Style="{StaticResource BotaoSecundario}" Padding="12,6" Margin="0,0,8,0"/>
          <Button x:Name="BtnTema" Style="{StaticResource BotaoSecundario}" Padding="12,6"/>
        </StackPanel>
        <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
          <Border CornerRadius="8" Background="White" Padding="8,4"><Image x:Name="Logo" Height="34" RenderOptions.BitmapScalingMode="HighQuality"/></Border>
          <Border Width="1" Height="30" Background="{DynamicResource B.Borda}" Margin="16,0"/>
          <StackPanel VerticalAlignment="Center">
            <TextBlock Text="Monitoramento de Serviços" FontSize="17" FontWeight="SemiBold" Foreground="{DynamicResource B.Titulo}"/>
            <TextBlock Text="Service Layer e serviços do Windows · reinício automático e avisos" FontSize="12" Foreground="{DynamicResource B.TextoSec}"/>
          </StackPanel>
        </StackPanel>
      </DockPanel></Border>
      <Border Height="4" Background="{StaticResource B.Degrade}"/>
    </StackPanel>
    <Border DockPanel.Dock="Bottom" Background="{DynamicResource B.Cartao}" BorderBrush="{DynamicResource B.Borda}" BorderThickness="0,1,0,0" Padding="24,12"><DockPanel>
      <StackPanel DockPanel.Dock="Right" Orientation="Horizontal">
        <Button x:Name="BtnSalvar" Content="Salvar" Style="{StaticResource BotaoPrimario}" MinWidth="104" IsEnabled="False"/>
      </StackPanel>
      <StackPanel VerticalAlignment="Center" Margin="0,0,16,0">
        <TextBlock x:Name="TxtStatus" Text="Sem alterações." Foreground="{DynamicResource B.TextoSec}" TextTrimming="CharacterEllipsis"/>
        <!-- barra "trabalhando": faixa no degradê SPS correndo enquanto testa, envia ou atualiza -->
        <Grid x:Name="Ocupado" Width="260" Height="5" Margin="0,7,0,0" HorizontalAlignment="Left" ClipToBounds="True" Visibility="Collapsed">
          <Border CornerRadius="2.5" Background="{DynamicResource B.Borda}"/>
          <Border Width="80" CornerRadius="2.5" HorizontalAlignment="Left" Background="{StaticResource B.Degrade}">
            <Border.RenderTransform><TranslateTransform/></Border.RenderTransform>
            <Border.Triggers><EventTrigger RoutedEvent="Loaded"><BeginStoryboard><Storyboard RepeatBehavior="Forever">
              <DoubleAnimation Storyboard.TargetProperty="(UIElement.RenderTransform).(TranslateTransform.X)" From="-80" To="260" Duration="0:0:1.3"/>
            </Storyboard></BeginStoryboard></EventTrigger></Border.Triggers>
          </Border>
        </Grid>
      </StackPanel>
    </DockPanel></Border>
    <Border DockPanel.Dock="Left" Width="256" Background="{DynamicResource B.Cartao}" BorderBrush="{DynamicResource B.Borda}" BorderThickness="0,0,1,0">
      <ListBox x:Name="Menu" Margin="12,14" Background="Transparent" BorderThickness="0" ItemContainerStyle="{StaticResource ItemMenu}"
               ScrollViewer.HorizontalScrollBarVisibility="Disabled"/>
    </Border>
    <ScrollViewer x:Name="Area" VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled" Padding="24,20,24,24"/>
  </DockPanel>
</Window>
'@
$janela = [Windows.Markup.XamlReader]::Parse($xaml)
foreach ($n in 'SeloTopo', 'SeloBola', 'SeloTexto', 'TxtVersao', 'BtnManual', 'BtnTema', 'Logo', 'BtnSalvar', 'TxtStatus', 'Ocupado', 'Menu', 'Area') { Set-Variable -Name $n -Value $janela.FindName($n) }
$arqIco = Join-Path $pasta 'logo_sps.ico'
# ícone lido para a MEMÓRIA ("OnLoad"): aberto direto do arquivo, a tela segurava o logo_sps.ico e o instalador da
# atualização não conseguia regravá-lo (falhava com "arquivo em uso" — visto na atualização para a 2026.11.11.3)
if (Test-Path -LiteralPath $arqIco) { try { $janela.Icon = [Windows.Media.Imaging.BitmapFrame]::Create([Uri]$arqIco, [Windows.Media.Imaging.BitmapCreateOptions]::None, [Windows.Media.Imaging.BitmapCacheOption]::OnLoad) } catch { } }
$arqLogo = Join-Path $pasta 'logo_sps.png'
if (Test-Path -LiteralPath $arqLogo) { try { $b = New-Object Windows.Media.Imaging.BitmapImage; $b.BeginInit(); $b.CacheOption = 'OnLoad'; $b.UriSource = [Uri]$arqLogo; $b.EndInit(); $Logo.Source = $b } catch { } }

# ---------- peças da tela ----------
function Bombear { [void][Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Windows.Threading.DispatcherPriority]::Background, [Action] {}) }
function Recurso($el, $prop, $chave) { $el.SetResourceReference($prop, $chave) }
function T($texto, $tam = 13, $chave = 'B.Texto', $peso = 'Normal') {
    $t = New-Object Windows.Controls.TextBlock; $t.Text = "$texto"; $t.FontSize = $tam; $t.FontWeight = $peso; $t.TextWrapping = 'Wrap'
    Recurso $t ([Windows.Controls.TextBlock]::ForegroundProperty) $chave; return $t
}
function Icone($codigo, $tam = 14, $chave = 'B.Link') { $i = T ([string][char]$codigo) $tam $chave; $i.FontFamily = 'Segoe MDL2 Assets'; $i.TextWrapping = 'NoWrap'; return $i }
function Aviso($texto, $icone = 'Information', $botoes = 'OK') { return [string][Windows.MessageBox]::Show($janela, $texto, $TITULO, $botoes, $icone) }
function Botao($texto, $estilo, $acao, $icone = 0) {
    $b = New-Object Windows.Controls.Button; $b.Style = $janela.FindResource($estilo)
    if ($icone) { $sp = New-Object Windows.Controls.StackPanel; $sp.Orientation = 'Horizontal'; $i = Icone $icone 13 $(if ($estilo -eq 'BotaoPrimario') { 'B.Cartao' } else { 'B.Link' }); $i.Margin = '0,2,8,0'
        if ($estilo -eq 'BotaoPrimario') { $i.Foreground = 'White' }; [void]$sp.Children.Add($i); $tx = New-Object Windows.Controls.TextBlock; $tx.Text = $texto; [void]$sp.Children.Add($tx); $b.Content = $sp }
    else { $b.Content = $texto }
    if ($acao) { $b.Add_Click($acao) }
    return $b
}
function Texto-Botao($b, $texto) { if ($b.Content -is [Windows.Controls.StackPanel]) { $b.Content.Children[1].Text = $texto } else { $b.Content = $texto } }
function Ler-Texto-Botao($b) { if ($b.Content -is [Windows.Controls.StackPanel]) { $b.Content.Children[1].Text } else { "$($b.Content)" } }
# cartão: título + explicação ao lado; devolve a pilha onde entram os campos
function Cartao($pagina, $titulo, $explicacao) {
    $b = New-Object Windows.Controls.Border; $b.CornerRadius = 12; $b.BorderThickness = 1; $b.Padding = '20,16,20,16'; $b.Margin = '0,0,0,14'
    Recurso $b ([Windows.Controls.Border]::BackgroundProperty) 'B.Cartao'; Recurso $b ([Windows.Controls.Border]::BorderBrushProperty) 'B.Borda'
    $p = New-Object Windows.Controls.StackPanel; $b.Child = $p
    $cab = New-Object Windows.Controls.WrapPanel; $cab.Margin = '0,0,0,14'
    [void]$cab.Children.Add((T $titulo 15 'B.Titulo' 'SemiBold'))
    if ($explicacao) { $x = T $explicacao 12 'B.TextoSec'; $x.Margin = '10,3,0,0'; [void]$cab.Children.Add($x) }
    [void]$p.Children.Add($cab); [void]$pagina.Children.Add($b)
    return $p
}
# campo: rótulo em cima, controle embaixo
function Campo($pai, $rotulo, $controle, $largura = 300, $ajuda = $null) {
    $p = New-Object Windows.Controls.StackPanel; $p.Margin = '0,0,14,14'; $p.Width = $largura
    $l = T $rotulo 12 'B.TextoSec'; $l.Margin = '1,0,0,5'; [void]$p.Children.Add($l); [void]$p.Children.Add($controle)
    if ($ajuda) { $a = T $ajuda 11.5 'B.TextoSec'; $a.Margin = '1,4,0,0'; $a.Opacity = 0.85; [void]$p.Children.Add($a) }
    [void]$pai.Children.Add($p); return $p
}
function Linha($pai) { $w = New-Object Windows.Controls.WrapPanel; [void]$pai.Children.Add($w); return $w }
# caixa de texto com exemplo em cinza (some ao digitar). Devolve o Grid; o TextBox fica em .Tag
function Caixa($exemplo, $valor = '') {
    $g = New-Object Windows.Controls.Grid
    $t = New-Object Windows.Controls.TextBox; $t.Style = $janela.FindResource('Entrada'); $t.Text = "$valor"
    $d = T $exemplo 13 'B.TextoSec'; $d.Margin = '10,0,0,0'; $d.VerticalAlignment = 'Center'; $d.IsHitTestVisible = $false; $d.Opacity = 0.6; $d.TextWrapping = 'NoWrap'
    $d.Visibility = $(if ($t.Text) { 'Collapsed' } else { 'Visible' })
    [void]$g.Children.Add($t); [void]$g.Children.Add($d); $t.Tag = $d
    $t.Add_TextChanged({ (Dica-De $this).Visibility = $(if ($this.Text) { 'Collapsed' } else { 'Visible' }); Marcar-Alterado })
    $g.Tag = $t; return $g
}
# a dica da caixa do nome da Service Layer guarda (dica, linha): aceita os dois formatos
function Dica-De($t) { if ($t.Tag -is [array]) { $t.Tag[0] } else { $t.Tag } }
function Texto-De($caixa) { "$($caixa.Tag.Text)" }
function Definir($caixa, $texto) { $caixa.Tag.Text = "$texto" }
# senha em dois estados: SALVA (selo verde "Senha salva" + Trocar; nunca aparece) ou DIGITAR (caixa de senha)
function CaixaSenha($temSalva) {
    $g = New-Object Windows.Controls.Grid
    $sb = New-Object Windows.Controls.Border; $sb.CornerRadius = 7; $sb.BorderThickness = 1; $sb.Padding = '10,0,4,0'; $sb.Height = 38
    Recurso $sb ([Windows.Controls.Border]::BackgroundProperty) 'B.OkFundo'; Recurso $sb ([Windows.Controls.Border]::BorderBrushProperty) 'B.Ok'
    $sd = New-Object Windows.Controls.DockPanel; $sb.Child = $sd
    $trocar = Botao 'Trocar' 'BotaoLink' $null; $trocar.Padding = '8,4'; [Windows.Controls.DockPanel]::SetDock($trocar, 'Right'); [void]$sd.Children.Add($trocar)
    $cad = Icone 0xE72E 13 'B.Ok'; $cad.VerticalAlignment = 'Center'; $cad.Margin = '0,1,8,0'; [Windows.Controls.DockPanel]::SetDock($cad, 'Left'); [void]$sd.Children.Add($cad)
    $ts = T 'Senha salva (criptografada)' 13 'B.Ok' 'SemiBold'; $ts.VerticalAlignment = 'Center'; $ts.TextWrapping = 'NoWrap'; $ts.TextTrimming = 'CharacterEllipsis'; [void]$sd.Children.Add($ts)
    $dg = New-Object Windows.Controls.Grid
    $pw = New-Object Windows.Controls.PasswordBox; $pw.Style = $janela.FindResource('Senha')
    $dica = T 'digite a senha' 13 'B.TextoSec'; $dica.Margin = '10,0,0,0'; $dica.VerticalAlignment = 'Center'; $dica.IsHitTestVisible = $false; $dica.Opacity = 0.6
    $manter = Botao 'Manter a salva' 'BotaoLink' $null; $manter.Padding = '8,4'; $manter.HorizontalAlignment = 'Right'; $manter.Visibility = 'Collapsed'
    [void]$dg.Children.Add($pw); [void]$dg.Children.Add($dica); [void]$dg.Children.Add($manter)
    [void]$g.Children.Add($sb); [void]$g.Children.Add($dg)
    $s = [pscustomobject]@{ el = $g; pw = $pw; dica = $dica; salva = $sb; digitar = $dg; manter = $manter }
    $pw.Tag = $s; $trocar.Tag = $s; $manter.Tag = $s
    $pw.Add_PasswordChanged({ $this.Tag.dica.Visibility = $(if ($this.Password) { 'Collapsed' } else { 'Visible' }); Marcar-Alterado })
    $trocar.Add_Click({ $x = $this.Tag; $x.salva.Visibility = 'Collapsed'; $x.digitar.Visibility = 'Visible'; $x.manter.Visibility = 'Visible'; $x.dica.Text = 'nova senha'; [void]$x.pw.Focus() })
    $manter.Add_Click({ $x = $this.Tag; Definir-Senha $x $true })
    Definir-Senha $s $temSalva
    return $s
}
function Definir-Senha($s, $temSalva) {
    $s.pw.Password = ''; $s.manter.Visibility = 'Collapsed'; $s.dica.Text = 'digite a senha'
    if ($temSalva) { $s.salva.Visibility = 'Visible'; $s.digitar.Visibility = 'Collapsed' } else { $s.salva.Visibility = 'Collapsed'; $s.digitar.Visibility = 'Visible' }
}
# senha digitada agora; vazio = manter a salva
function Senha-Digitada($s) { if ($s.salva.Visibility -eq 'Visible') { return '' }; return $s.pw.Password }
function Chave($texto, $marcado) { $c = New-Object Windows.Controls.CheckBox; $c.Style = $janela.FindResource('Chave'); $c.Content = $texto; $c.IsChecked = [bool]$marcado; $c.Add_Click({ Marcar-Alterado }); return $c }
function Selo($texto, $tipo) {
    $c = New-Object Windows.Controls.Border; $c.CornerRadius = 10; $c.Padding = '9,2'; $c.VerticalAlignment = 'Center'
    Recurso $c ([Windows.Controls.Border]::BackgroundProperty) (@{ ok = 'B.OkFundo'; alerta = 'B.AlertaFundo'; erro = 'B.ErroFundo'; neutro = 'B.Hover' }[$tipo])
    $c.Child = (T $texto 11.5 (@{ ok = 'B.Ok'; alerta = 'B.Alerta'; erro = 'B.Erro'; neutro = 'B.TextoSec' }[$tipo])); $c.Child.TextWrapping = 'NoWrap'; return $c
}
# caixa de resultado (testes): texto em fonte fixa, rolagem própria
function NovaSaida($pai, $altura = 170) {
    $r = New-Object Windows.Controls.TextBox; $r.Style = $janela.FindResource('Entrada'); $r.IsReadOnly = $true; $r.TextWrapping = 'Wrap'
    $r.FontFamily = 'Consolas'; $r.FontSize = 12; $r.Height = $altura; $r.Padding = '8,6'; $r.VerticalScrollBarVisibility = 'Auto'; $r.AcceptsReturn = $true; $r.VerticalContentAlignment = 'Top'
    Recurso $r ([Windows.Controls.TextBox]::BackgroundProperty) 'B.Fundo'
    [void]$pai.Children.Add($r); return $r
}
function Saida($caixa, $texto) { $caixa.AppendText(((Get-Date).ToString('HH:mm:ss') + ' ' + ($texto -replace "`r?`n", "`r`n") + "`r`n")); $caixa.ScrollToEnd(); Bombear }
# barra 'trabalhando' no rodapé (liga/desliga)
function Trabalhando($sim) { $Ocupado.Visibility = $(if ($sim) { 'Visible' } else { 'Collapsed' }); Bombear }
function Aguarde($botao, $texto = 'Aguarde...') { $botao.Tag = Ler-Texto-Botao $botao; Texto-Botao $botao $texto; $botao.IsEnabled = $false; $janela.Cursor = [Windows.Input.Cursors]::Wait; Trabalhando $true }
function Pronto($botao) { if ($botao.Tag -is [string]) { Texto-Botao $botao $botao.Tag }; $botao.IsEnabled = $true; $janela.Cursor = $null; Trabalhando $false }
function Nova-Pagina { $p = New-Object Windows.Controls.StackPanel; $p.MaxWidth = 900; $p.HorizontalAlignment = 'Left'; return $p }

# ---------- controle de alterações: o Salvar só acende quando algo muda ----------
$script:alterado = $false
$script:carregando = $true
function Marcar-Alterado {
    if ($script:carregando) { return }
    $script:alterado = $true; $BtnSalvar.IsEnabled = $true
    Recurso $TxtStatus ([Windows.Controls.TextBlock]::ForegroundProperty) 'B.Alerta'; $TxtStatus.Text = '● Alterações não salvas - clique em Salvar.'
}
function Status($texto, $chave = 'B.TextoSec') { Recurso $TxtStatus ([Windows.Controls.TextBlock]::ForegroundProperty) $chave; $TxtStatus.Text = $texto; Bombear }

# =====================================================================================================
# PÁGINAS
# =====================================================================================================
$paginas = [ordered]@{}

# ---------- Service Layer ----------
$pgSL = Nova-Pagina; $paginas['sl'] = $pgSL
$c = Cartao $pgSL 'Acesso ao Service Layer Controller' 'o mesmo login para todas as Service Layers'
$l = Linha $c
$txtCtlUsuario = Caixa 'ex.: B1SiteUser' (Valor $cfg 'controller_usuario' '')
Campo $l 'Usuário do Controller' $txtCtlUsuario 320 | Out-Null
$senhaCtl = CaixaSenha (TemSenha (Valor $cfg 'controller_senha_cripto' '') (Valor $cfg 'controller_senha' ''))
Campo $l 'Senha' $senhaCtl.el 320 'criptografada com a chave deste servidor' | Out-Null

$c = Cartao $pgSL 'Service Layers monitoradas' 'até 5 · digite só o NOME do servidor (não o IP): os caminhos se preenchem sozinhos'
$painelSL = New-Object Windows.Controls.StackPanel; [void]$c.Children.Add($painelSL)
$linhasSL = New-Object System.Collections.ArrayList
$MAX_SL = 5
$btnMais = New-Object Windows.Controls.Button; $btnMais.Style = $janela.FindResource('BotaoAdicionar')
$btnMais.Add_Click({ Adicionar-LinhaSL '' '' '' $true; Marcar-Alterado; [void]$linhasSL[$linhasSL.Count - 1].Nome.Tag.Focus() })
[void]$c.Children.Add($btnMais)
$dicaSL = T 'Desligue "Reiniciar sozinho" para só avisar (não reinicia aquela Service Layer).' 12 'B.TextoSec'; $dicaSL.Margin = '2,8,0,0'; [void]$c.Children.Add($dicaSL)
function Reposicionar-LinhasSL {
    foreach ($x in $linhasSL) { $x.Botao.IsEnabled = ($linhasSL.Count -gt 1) }
    $btnMais.IsEnabled = ($linhasSL.Count -lt $MAX_SL)
    $btnMais.Content = $(if ($linhasSL.Count -lt $MAX_SL) { "Adicionar Service Layer   ($($linhasSL.Count) de $MAX_SL)" } else { "Limite de $MAX_SL Service Layers" })
}
function Adicionar-LinhaSL($nome, $sl, $ctl, $reinicia) {
    if ($linhasSL.Count -ge $MAX_SL) { return }
    # linha compacta (nome + caminhos por extenso + Reiniciar sozinho + Editar + x); "Editar" abre os campos em linhas inteiras
    $b = New-Object Windows.Controls.Border; $b.CornerRadius = 9; $b.BorderThickness = 1; $b.Padding = '12,8,8,8'; $b.Margin = '0,0,0,8'
    Recurso $b ([Windows.Controls.Border]::BorderBrushProperty) 'B.Borda'; Recurso $b ([Windows.Controls.Border]::BackgroundProperty) 'B.Fundo'
    $pilha = New-Object Windows.Controls.StackPanel; $b.Child = $pilha
    $d = New-Object Windows.Controls.DockPanel; [void]$pilha.Children.Add($d)
    $bx = Botao '' 'BotaoLink' $null; $bx.Content = (Icone 0xE711 12 'B.Erro'); $bx.ToolTip = 'Remover esta Service Layer'; $bx.VerticalAlignment = 'Center'
    [Windows.Controls.DockPanel]::SetDock($bx, 'Right'); [void]$d.Children.Add($bx)
    $ed = Botao 'Editar' 'BotaoLink' { $c = $this.Tag; $c.Visibility = $(if ($c.Visibility -eq 'Visible') { 'Collapsed' } else { 'Visible' }) } 0xE70F
    $ed.VerticalAlignment = 'Center'; $ed.Margin = '8,0,0,0'; [Windows.Controls.DockPanel]::SetDock($ed, 'Right'); [void]$d.Children.Add($ed)
    $cr = Chave 'Reiniciar sozinho' $reinicia; $cr.VerticalAlignment = 'Center'; $cr.Margin = '12,0,0,0'; [Windows.Controls.DockPanel]::SetDock($cr, 'Right'); [void]$d.Children.Add($cr)
    $ic = Icone 0xE968 16; $ic.Margin = '0,3,10,0'; $ic.VerticalAlignment = 'Top'; [Windows.Controls.DockPanel]::SetDock($ic, 'Left'); [void]$d.Children.Add($ic)
    $txt = New-Object Windows.Controls.StackPanel; $txt.VerticalAlignment = 'Center'; [void]$d.Children.Add($txt)
    $tit = T '' 14 'B.Titulo' 'SemiBold'; [void]$txt.Children.Add($tit)
    $det = T '' 11.5 'B.TextoSec'; $det.TextWrapping = 'NoWrap'; $det.TextTrimming = 'CharacterEllipsis'; [void]$txt.Children.Add($det)
    $campos = New-Object Windows.Controls.StackPanel; $campos.Margin = '26,12,0,0'; [void]$pilha.Children.Add($campos); $ed.Tag = $campos
    $tn = Caixa 'SERVIDOR' $nome; $ts = Caixa 'https://SERVIDOR:50000/b1s/v1/' $sl; $tc = Caixa 'https://SERVIDOR:40000/ServiceLayerController/' $ctl
    $tn.Width = 260; $tn.HorizontalAlignment = 'Left'
    foreach ($par in @(@('Nome do servidor (não o IP)', $tn), @('Caminho da Service Layer', $ts), @('Caminho do Service Layer Controller', $tc))) {
        $l = T $par[0] 11.5 'B.TextoSec'; $l.Margin = '1,0,0,4'; [void]$campos.Children.Add($l); $par[1].Margin = '0,0,0,10'; [void]$campos.Children.Add($par[1])
    }
    # Service Layer já salva começa fechada (só a linha); nova começa aberta
    $campos.Visibility = $(if ("$nome".Trim()) { 'Collapsed' } else { 'Visible' })
    $linha = [pscustomobject]@{ Borda = $b; Nome = $tn; SL = $ts; Ctl = $tc; Reinicia = $cr; Botao = $bx; UltimoNome = "$nome".Trim(); Campos = $campos; Titulo = $tit; Detalhe = $det }
    foreach ($cx in @($tn, $ts, $tc)) { $cx.Tag.Add_LostFocus({ Atualizar-Linhas-SL }) }
    $tn.Tag.Tag = @($tn.Tag.Tag, $linha)   # dica + linha (a dica continua no índice 0; Dica-De entende os dois formatos)
    $tn.Tag.Add_TextChanged({
        $l = $this.Tag[1]
        $n = $this.Text.Trim(); $ant = $l.UltimoNome
        $slAnt = if ($ant) { 'https://' + $ant + ':50000/b1s/v1/' } else { '' }
        $ctlAnt = if ($ant) { 'https://' + $ant + ':40000/ServiceLayerController/' } else { '' }
        if (-not (Texto-De $l.SL).Trim() -or (Texto-De $l.SL) -eq $slAnt) { Definir $l.SL $(if ($n) { 'https://' + $n + ':50000/b1s/v1/' } else { '' }) }
        if (-not (Texto-De $l.Ctl).Trim() -or (Texto-De $l.Ctl) -eq $ctlAnt) { Definir $l.Ctl $(if ($n) { 'https://' + $n + ':40000/ServiceLayerController/' } else { '' }) }
        $l.UltimoNome = $n
    })
    $bx.Tag = $linha; $bx.Add_Click({ Remover-LinhaSL $this.Tag })
    [void]$painelSL.Children.Add($b); [void]$linhasSL.Add($linha)
    Reposicionar-LinhasSL; Atualizar-Linhas-SL
}
# texto da linha compacta: nome e os dois caminhos por extenso
function Atualizar-Linhas-SL {
    foreach ($l in $linhasSL) {
        $n = (Texto-De $l.Nome).Trim()
        $l.Titulo.Text = $(if ($n) { $n } else { 'Service Layer nova' })
        $l.Detalhe.Text = 'Service Layer: ' + $(if ((Texto-De $l.SL).Trim()) { (Texto-De $l.SL).Trim() } else { '-' }) + '   ·   Controller: ' + $(if ((Texto-De $l.Ctl).Trim()) { (Texto-De $l.Ctl).Trim() } else { '-' })
        $l.Detalhe.ToolTip = $l.Detalhe.Text
    }
}
function Remover-LinhaSL($linha) {
    if ($linhasSL.Count -le 1) { return }
    $painelSL.Children.Remove($linha.Borda); $linhasSL.Remove($linha); Reposicionar-LinhasSL; Marcar-Alterado
}
$listaSL = Valor $cfg 'servicos' $null
if ($listaSL) { foreach ($s in @($listaSL)) { Adicionar-LinhaSL $s.nome $s.service_layer $s.controller ($s.reiniciar -ne $false) } } else { Adicionar-LinhaSL '' '' '' $true }

$c = Cartao $pgSL 'Testar conexão' 'entra no Controller de cada Service Layer e mostra status e memória (não reinicia nada)'
$btnTestarSL = Botao 'Testar conexão (todas)' 'BotaoSecundario' { Rodar-Monitoramento 'status' $this } 0xE9D9
$btnTestarSL.HorizontalAlignment = 'Left'; $btnTestarSL.Margin = '0,0,0,10'; [void]$c.Children.Add($btnTestarSL)
$resAcesso = NovaSaida $c 170

# tempos da Service Layer (os mesmos campos de antes, agrupados)
$caixasTempo = @{}
function Cartao-Tempos($pagina, $grupos, $titulo, $expl) {
    $c = Cartao $pagina $titulo $expl
    $grupo = ''
    foreach ($t in $camposTempo | Where-Object { $grupos -contains $_[4] }) {
        if ($t[4] -ne $grupo -and @($grupos).Count -gt 1) { $grupo = $t[4]; $h = T $grupo.ToUpper() 11 'B.TextoSec' 'SemiBold'; $h.Margin = '0,6,0,8'; [void]$c.Children.Add($h) }
        $d = New-Object Windows.Controls.DockPanel; $d.Margin = '0,0,0,8'
        $r = T $t[2] 13 'B.Texto'; $r.Width = 230; $r.VerticalAlignment = 'Center'; [Windows.Controls.DockPanel]::SetDock($r, 'Left'); [void]$d.Children.Add($r)
        $cx = Caixa '' (Valor $tmp $t[0] $t[1]); $cx.Width = $(if ($t[0] -eq 'janela_reinicio_memoria') { 120 } else { 80 }); $cx.Tag.TextAlignment = 'Right'
        [Windows.Controls.DockPanel]::SetDock($cx, 'Left'); [void]$d.Children.Add($cx)
        $e = T $t[3] 12 'B.TextoSec'; $e.Margin = '12,0,0,0'; $e.VerticalAlignment = 'Center'; [void]$d.Children.Add($e)
        [void]$c.Children.Add($d); $caixasTempo[$t[0]] = $cx
    }
}
Cartao-Tempos $pgSL @('Verificação', 'Quando considerar falha', 'Reinício', 'Memória') 'Tempos e limites da Service Layer' 'valor vazio ou inválido = padrão'

# ---------- E-mail e avisos ----------
$pgEmail = Nova-Pagina; $paginas['email'] = $pgEmail
$c = Cartao $pgEmail 'Servidor de e-mail (SMTP)' 'um só e-mail para todos os avisos do monitoramento'
$l = Linha $c
$txtSmtp = Caixa 'ex.: smtp.office365.com' (Valor $cfg 'smtp_servidor' ''); Campo $l 'Servidor SMTP' $txtSmtp 300 | Out-Null
$txtPorta = Caixa '587' (Valor $cfg 'smtp_porta' 587); Campo $l 'Porta' $txtPorta 100 | Out-Null
$chkSsl = Chave 'Usar SSL/TLS' (Valor $cfg 'smtp_ssl' $true); $chkSsl.Margin = '0,22,0,0'; [void]$l.Children.Add($chkSsl)
$l = Linha $c
$txtSmtpUsuario = Caixa 'ex.: alertas@empresa.com.br' (Valor $cfg 'smtp_usuario' ''); Campo $l 'Usuário do e-mail' $txtSmtpUsuario 320 | Out-Null
$senhaSmtp = CaixaSenha (TemSenha (Valor $cfg 'smtp_senha_cripto' '') (Valor $cfg 'smtp_senha' '')); Campo $l 'Senha do e-mail' $senhaSmtp.el 320 | Out-Null
$l = Linha $c
$txtRemetente = Caixa 'normalmente o mesmo usuário do e-mail' (Valor $cfg 'email_remetente' ''); Campo $l 'Remetente' $txtRemetente 300 | Out-Null

# destinatários: um e-mail por linha, "+" para incluir; no config.json continua "a@x, b@y" (o monitoramento lê igual)
$c = Cartao $pgEmail 'Destinatários' 'quem recebe os avisos'
$painelPara = New-Object Windows.Controls.StackPanel; [void]$c.Children.Add($painelPara)
$linhasPara = New-Object System.Collections.ArrayList
$btnMaisPara = New-Object Windows.Controls.Button; $btnMaisPara.Style = $janela.FindResource('BotaoAdicionar'); $btnMaisPara.Content = 'Adicionar destinatário'
$btnMaisPara.Add_Click({ Adicionar-Destinatario ''; Marcar-Alterado; [void]$linhasPara[$linhasPara.Count - 1].Caixa.Tag.Focus() })
[void]$c.Children.Add($btnMaisPara)
function Adicionar-Destinatario($email) {
    $d = New-Object Windows.Controls.DockPanel; $d.Margin = '0,0,0,8'; $d.MaxWidth = 560; $d.HorizontalAlignment = 'Left'; $d.Width = 560
    $ic = Icone 0xE715 14 'B.TextoSec'; $ic.VerticalAlignment = 'Center'; $ic.Margin = '2,0,12,0'; [Windows.Controls.DockPanel]::SetDock($ic, 'Left'); [void]$d.Children.Add($ic)
    $bx = Botao '' 'BotaoLink' $null; $bx.Content = (Icone 0xE711 12 'B.Erro'); $bx.ToolTip = 'Tirar este destinatário'; $bx.Margin = '6,0,0,0'
    [Windows.Controls.DockPanel]::SetDock($bx, 'Right'); [void]$d.Children.Add($bx)
    $cx = Caixa 'nome@empresa.com.br' $email; [void]$d.Children.Add($cx)
    $linha = [pscustomobject]@{ Painel = $d; Caixa = $cx; Botao = $bx }; $bx.Tag = $linha
    $bx.Add_Click({ $l = $this.Tag; if ($linhasPara.Count -le 1) { Definir $l.Caixa ''; return }; $painelPara.Children.Remove($l.Painel); $linhasPara.Remove($l); Marcar-Alterado })
    [void]$painelPara.Children.Add($d); [void]$linhasPara.Add($linha)
}
function Destinatarios { @($linhasPara | ForEach-Object { (Texto-De $_.Caixa).Trim() } | Where-Object { $_ }) }
$listaPara = @("$(Valor $cfg 'email_para' '')" -split '[,;]' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
if ($listaPara.Count) { foreach ($e in $listaPara) { Adicionar-Destinatario $e } } else { Adicionar-Destinatario '' }

$avisosCfg = Valor $cfg 'avisos' $null
$c = Cartao $pgEmail 'Avisos enviados' 'desligado = só fica registrado no histórico'
$w = Linha $c; $chkAvisos = @{}
foreach ($ta in $tiposAviso) {
    $ck = Chave $ta[1] (-not ($avisosCfg -and ($avisosCfg.PSObject.Properties.Name -contains $ta[0]) -and $avisosCfg.($ta[0]) -eq $false))
    $ck.Margin = '0,0,26,12'; [void]$w.Children.Add($ck); $chkAvisos[$ta[0]] = $ck
}
foreach ($par in @(@('repetir', 'Repetir "continua fora" / "acionar o NOC" a cada', 'repetir_min', 30), @('mem', 'Alerta de memória elevada no máximo a cada', 'memoria_min', 60))) {
    $d = New-Object Windows.Controls.DockPanel; $d.Margin = '0,4,0,8'
    $r = T $par[1] 13; $r.Width = 330; $r.VerticalAlignment = 'Center'; [Windows.Controls.DockPanel]::SetDock($r, 'Left'); [void]$d.Children.Add($r)
    $cx = Caixa '' (Valor $avisosCfg $par[2] $par[3]); $cx.Width = 80; $cx.Tag.TextAlignment = 'Right'; [Windows.Controls.DockPanel]::SetDock($cx, 'Left'); [void]$d.Children.Add($cx)
    $m = T 'minutos' 12 'B.TextoSec'; $m.Margin = '10,0,0,0'; $m.VerticalAlignment = 'Center'; [void]$d.Children.Add($m)
    [void]$c.Children.Add($d)
    if ($par[0] -eq 'repetir') { $txtRepetir = $cx } else { $txtAlertaMem = $cx }
}
$c = Cartao $pgEmail 'Testar o e-mail' 'envia um aviso de teste para os destinatários (igual aos de verdade)'
$btnTestarEmail = Botao 'Enviar e-mail de teste' 'BotaoSecundario' { Rodar-Monitoramento 'teste_email' $this } 0xE724
$btnTestarEmail.HorizontalAlignment = 'Left'; $btnTestarEmail.Margin = '0,0,0,10'; [void]$c.Children.Add($btnTestarEmail)
$resEmail = NovaSaida $c 120

# ---------- Agendador do Windows ----------
$pgTarefa = Nova-Pagina; $paginas['tarefa'] = $pgTarefa
$c = Cartao $pgTarefa 'Tarefa agendada' "'$nomeTarefa' roda o monitoramento a cada 1 minuto"
$lblTarefa = T '' 13.5; $lblTarefa.LineHeight = 22; $lblTarefa.Margin = '0,0,0,12'; [void]$c.Children.Add($lblTarefa)
$w = Linha $c
$btnInfo = Botao 'Atualizar informações' 'BotaoSecundario' { Aguarde $this 'Atualizando...'; Mostrar-Tarefa; Start-Sleep -Milliseconds 200; Pronto $this } 0xE72C
$btnInfo.Margin = '0,0,10,0'; [void]$w.Children.Add($btnInfo)
$btnLigar = Botao 'Iniciar monitoramento' 'BotaoPrimario' { Ligar-Desligar $this }; [void]$w.Children.Add($btnLigar)
$n = T 'Iniciar liga a tarefa (roda a cada 1 minuto). Parar desliga sem desinstalar.' 12 'B.TextoSec'; $n.Margin = '2,10,0,0'; [void]$c.Children.Add($n)

$c = Cartao $pgTarefa 'Executar a tarefa como' 'conta do Windows que roda o monitoramento'
$rdSystem = New-Object Windows.Controls.RadioButton; $rdSystem.Style = $janela.FindResource('Opcao'); $rdSystem.Content = 'Conta do sistema (SYSTEM) - padrão, não depende de senha'; $rdSystem.GroupName = 'conta'
$rdUsuario = New-Object Windows.Controls.RadioButton; $rdUsuario.Style = $janela.FindResource('Opcao'); $rdUsuario.Content = 'Usuário do Windows (ex.: o cliente usa pasta compartilhada ou não permite SYSTEM)'; $rdUsuario.GroupName = 'conta'
[void]$c.Children.Add($rdSystem); [void]$c.Children.Add($rdUsuario)
$l = Linha $c; $l.Margin = '27,6,0,0'
$txtContaUsuario = Caixa 'ex.: DOMINIO\usuario'; $campoContaU = Campo $l 'Usuário' $txtContaUsuario 260
$txtContaSenha = New-Object Windows.Controls.PasswordBox; $txtContaSenha.Style = $janela.FindResource('Senha'); $campoContaS = Campo $l 'Senha' $txtContaSenha 260
$n = T 'A senha não fica gravada no config: o próprio Agendador do Windows guarda. Se ela vencer ou for trocada, a tarefa para de rodar: volte aqui, digite a nova e clique em Aplicar. Prefira um usuário de serviço com senha que não expira.' 12 'B.TextoSec'
$n.Margin = '27,0,0,12'; [void]$c.Children.Add($n)
function Ajustar-Conta { foreach ($x in @($campoContaU, $campoContaS)) { $x.IsEnabled = [bool]$rdUsuario.IsChecked; $x.Opacity = $(if ($rdUsuario.IsChecked) { 1 } else { 0.5 }) } }
$rdSystem.Add_Checked({ Ajustar-Conta }); $rdUsuario.Add_Checked({ Ajustar-Conta })
$w = Linha $c
$btnConta = Botao 'Aplicar na tarefa' 'BotaoSecundario' { Aplicar-Conta $this } 0xE8FB; $btnConta.Margin = '0,0,12,10'; [void]$w.Children.Add($btnConta)
$n = T 'Troca a conta da tarefa, libera a pasta e roda uma vez para testar.' 12 'B.TextoSec'; $n.VerticalAlignment = 'Center'; $n.Margin = '0,0,0,10'; [void]$w.Children.Add($n)
$resTarefa = NovaSaida $c 120

# ---------- Logs e registros (chave interna 'tempos': o dias_manter_logs fica no tempos.json) ----------
$pgTempos = Nova-Pagina; $paginas['tempos'] = $pgTempos
Cartao-Tempos $pgTempos @('Logs') 'Logs e registros' 'vale para a Service Layer e para os serviços do Windows'
$c = Cartao $pgTempos 'Onde ficam os registros' ''
[void]$c.Children.Add((T ("Service Layer: $pasta\logs\<NOME>\AAAA-MM-DD.log e historico.log (o mais recente no topo)`nServiços do Windows: $pasta\logs\servicos\<SERVIDOR>_<SERVIÇO>\AAAA-MM-DD.log e historico.log`nAlterações nesta tela: $pasta\logs\alteracoes\<usuário>\AAAA-MM.log (nunca apagados)`nAtualizações de versão: $pasta\logs\atualizacao.log") 12.5 'B.TextoSec'))

# ---------- Serviços do Windows ----------
# Serviços do Windows: servidores (este + outros por IP/nome) e os serviços que precisam ficar SEMPRE rodando.
# Gravado em config.json "servicos_windows" { servidores[], monitorados[] }; quem vigia é o monitoramento_servicos.js (mesma tarefa).
$pgServ = Nova-Pagina; $paginas['servicos'] = $pgServ
$swCfg = Valor $cfg 'servicos_windows' $null
$ESTE = $env:COMPUTERNAME
$script:marcados = [ordered]@{}   # "servidor|nome" (minúsculas) -> configuração do serviço marcado
# serviços da Invent: o ciclo concluído grava "[Completed]" no log
$REGEX_INVENT = 'TaxPlus|InvoiceOne|InventApp'
# como perceber que o serviço TRAVOU (rodando, mas sem trabalhar): cada serviço trava de um jeito, quem escolhe é a pessoa
$REGRAS_TRAVADO = @(
    @('estado', 'só se parar (não olha travado)'),
    @('log', 'o log parar de andar'),
    @('porta', 'uma porta parar de responder'),
    @('url', 'um endereço (URL) parar de responder'))
# serviço marcado com todos os campos. Cadastro antigo sem 'verificacao': log + minutos = regra do log; sem 'texto_ciclo' = "[Completed]"
function Novo-Marcado($srv, $nome, $exib, $m = $null) {
    $lg = "$(Valor $m 'log' '')"; $mn = [int](Valor $m 'travado_min' 0)
    $vf = "$(Valor $m 'verificacao' '')"; if ($vf -notin 'estado', 'log', 'porta', 'url') { $vf = $(if ($lg -and $mn) { 'log' } else { 'estado' }) }
    $tc = if ($m -and ($m.PSObject.Properties.Name -contains 'texto_ciclo')) { "$($m.texto_ciclo)" } elseif ($m) { '[Completed]' } elseif ("$nome $exib" -match $REGEX_INVENT) { '[Completed]' } else { '' }
    return [pscustomobject]@{ servidor = "$srv"; nome = "$nome"; exibicao = $(if ($exib) { "$exib" } else { "$nome" }); reiniciar = -not ($m -and $m.reiniciar -eq $false)
        verificacao = $vf; travado_min = $mn; log = $lg; texto_ciclo = $tc; porta = [int](Valor $m 'porta' 0); url = "$(Valor $m 'url' '')"; memoria_mb = [int](Valor $m 'memoria_mb' 0)
        forcar = -not ($m -and $m.forcar -eq $false) }
}
# texto da regra para o log de alterações e o status
function Texto-Regra($m) {
    switch ("$($m.verificacao)") {
        'log' { "travado se o log ficar $($m.travado_min) min sem $(if ($m.texto_ciclo) { 'uma linha com ' + $m.texto_ciclo } else { 'gravar' }) ($($m.log))" }
        'porta' { "travado se a porta $($m.porta) não responder" }
        'url' { "travado se o endereço $($m.url) não responder" }
        default { 'só se parar' }
    }
}
foreach ($m in @(Valor $swCfg 'monitorados' @())) {
    if ($m -and $m.nome) { $script:marcados[("$($m.servidor)|$($m.nome)").ToLower()] = Novo-Marcado $m.servidor $m.nome (Valor $m 'exibicao' $m.nome) $m }
}
$script:listas = @{}               # servidor -> serviços lidos ("Ler serviços")
$script:servidorAtual = $ESTE
$script:filtroServ = 'todos'
$REGEX_CONHECIDOS = '^(TaxPlus|BankPlus|InvoiceOne|InventApp|SBO|B1|SAPB1|SLD)|Service ?Layer|SAP Business One|TaxOne|BankPlus|Invent'
function BotaoAdicionar($texto, $acao) { $b = New-Object Windows.Controls.Button; $b.Style = $janela.FindResource('BotaoAdicionar'); $b.Content = $texto; if ($acao) { $b.Add_Click($acao) }; return $b }
# roda o servicos.ps1 sem travar a janela e devolve o JSON
function Rodar-Servicos($argumentos) {
    $psi = New-Object Diagnostics.ProcessStartInfo('powershell.exe', "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$(Join-Path $pasta 'servicos.ps1')`" $argumentos")
    $psi.WorkingDirectory = $pasta; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true; $psi.RedirectStandardOutput = $true; $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
    $proc = [Diagnostics.Process]::Start($psi); $saida = $proc.StandardOutput.ReadToEndAsync()
    while (-not $proc.HasExited) { Bombear; Start-Sleep -Milliseconds 60 }
    try { return ($saida.Result | ConvertFrom-Json) } catch { return [pscustomobject]@{ ok = $false; erro = 'resposta inválida: ' + $saida.Result } }
}

$c = Cartao $pgServ 'Servidores' 'este servidor + os que ele enxerga pela rede (IP ou nome)'
$painelSrv = New-Object Windows.Controls.StackPanel; [void]$c.Children.Add($painelSrv)
$linhasSrv = New-Object System.Collections.ArrayList
$btnMaisSrv = BotaoAdicionar 'Adicionar servidor (IP ou nome)' { Adicionar-Servidor '' '' '' $false $false; Marcar-Alterado; Desenhar-Seletor }
[void]$c.Children.Add($btnMaisSrv)
$n = T 'Salve antes de ler um servidor novo.' 12 'B.TextoSec'
$n.Margin = '2,8,0,0'; [void]$c.Children.Add($n)
# cada servidor numa linha compacta (ícone, nome, endereço, situação, Ler serviços); "Editar" abre os campos
function Adicionar-Servidor($nome, $endereco, $usuario, $temSenha, $ehEste) {   # ($ehEste: $este seria a mesma variável que $ESTE)
    $b = New-Object Windows.Controls.Border; $b.CornerRadius = 9; $b.BorderThickness = 1; $b.Padding = '12,8,8,8'; $b.Margin = '0,0,0,8'
    Recurso $b ([Windows.Controls.Border]::BorderBrushProperty) 'B.Borda'; Recurso $b ([Windows.Controls.Border]::BackgroundProperty) 'B.Fundo'
    $pilha = New-Object Windows.Controls.StackPanel; $b.Child = $pilha
    $d = New-Object Windows.Controls.DockPanel; [void]$pilha.Children.Add($d)
    $linha = [pscustomobject]@{ Borda = $b; Este = [bool]$ehEste; Nome = $null; Endereco = $null; Usuario = $null; Senha = $null; Chip = $null; Campos = $null; Titulo = $null; Detalhe = $null }
    $ler = Botao 'Ler serviços' 'BotaoSecundario' { Ler-Servicos $this.Tag $this } 0xE72C; $ler.Tag = $linha; $ler.Padding = '12,6'; $ler.VerticalAlignment = 'Center'; $ler.Margin = '8,0,0,0'
    if (-not $ehEste) {
        $bx = Botao '' 'BotaoLink' $null; $bx.Content = (Icone 0xE711 12 'B.Erro'); $bx.ToolTip = 'Tirar este servidor'; $bx.VerticalAlignment = 'Center'; $bx.Tag = $linha
        $bx.Add_Click({ $l = $this.Tag; $painelSrv.Children.Remove($l.Borda); $linhasSrv.Remove($l); Marcar-Alterado; Desenhar-Seletor }); [Windows.Controls.DockPanel]::SetDock($bx, 'Right'); [void]$d.Children.Add($bx)
    }
    [Windows.Controls.DockPanel]::SetDock($ler, 'Right'); [void]$d.Children.Add($ler)
    if (-not $ehEste) {
        $ed = Botao 'Editar' 'BotaoLink' { $l = $this.Tag; $l.Campos.Visibility = $(if ($l.Campos.Visibility -eq 'Visible') { 'Collapsed' } else { 'Visible' }) } 0xE70F
        $ed.Tag = $linha; $ed.VerticalAlignment = 'Center'; $ed.Margin = '8,0,0,0'; [Windows.Controls.DockPanel]::SetDock($ed, 'Right'); [void]$d.Children.Add($ed)
    }
    $chip = Selo $(if ($ehEste) { 'este servidor' } else { 'ainda não lido' }) 'neutro'; $chip.Margin = '8,0,0,0'; [Windows.Controls.DockPanel]::SetDock($chip, 'Right'); [void]$d.Children.Add($chip); $linha.Chip = $chip
    $sp = New-Object Windows.Controls.StackPanel; $sp.Orientation = 'Horizontal'; $sp.VerticalAlignment = 'Center'
    $ic = Icone $(if ($ehEste) { 0xE977 } else { 0xE968 }) 16; $ic.Margin = '0,2,10,0'; [void]$sp.Children.Add($ic)
    $linha.Titulo = T $(if ($ehEste) { $ESTE } else { $nome }) 14 'B.Titulo' 'SemiBold'; $linha.Titulo.VerticalAlignment = 'Center'; [void]$sp.Children.Add($linha.Titulo)
    $linha.Detalhe = T '' 12 'B.TextoSec'; $linha.Detalhe.VerticalAlignment = 'Center'; $linha.Detalhe.Margin = '10,0,0,0'; [void]$sp.Children.Add($linha.Detalhe)
    [void]$d.Children.Add($sp)
    if ($ehEste) { $linha.Detalhe.Text = '(este servidor, onde o monitoramento roda)' }
    else {
        $campos = New-Object Windows.Controls.StackPanel; $campos.Margin = '26,12,0,0'; [void]$pilha.Children.Add($campos); $linha.Campos = $campos
        $w = New-Object Windows.Controls.WrapPanel; [void]$campos.Children.Add($w)
        $linha.Nome = Caixa 'ex.: SRVWEB' $nome; Campo $w 'Nome (aparece nos avisos)' $linha.Nome 160 | Out-Null
        $linha.Endereco = Caixa 'IP ou nome na rede' $endereco; Campo $w 'Endereço' $linha.Endereco 160 | Out-Null
        $linha.Usuario = Caixa 'DOMINIO\usuario' $usuario; Campo $w 'Usuário com acesso (opcional)' $linha.Usuario 190 | Out-Null
        $linha.Senha = CaixaSenha $temSenha; Campo $w 'Senha' $linha.Senha.el 200 | Out-Null
        $ex = T ("Usuário e senha: a tarefa agendada roda como SYSTEM e, na rede, aparece como a conta do computador $ESTE`$. " +
            "Se essa conta não for administradora neste servidor, informe aqui um usuário do domínio que seja (de preferência um usuário de serviço, com senha que não expira). " +
            "Em branco: usa a conta da tarefa. O acesso é pelas portas 135 (serviços) e 445 (logs).") 11.5 'B.TextoSec'
        $ex.Margin = '1,0,14,4'; [void]$campos.Children.Add($ex)
        foreach ($cx in @($linha.Nome, $linha.Endereco, $linha.Usuario)) { $cx.Tag.Add_LostFocus({ Desenhar-Seletor; Atualizar-Linhas-Servidor }) }
        # servidor já salvo começa fechado (só a linha); servidor novo começa com os campos abertos
        $campos.Visibility = $(if ($nome) { 'Collapsed' } else { 'Visible' })
    }
    [void]$painelSrv.Children.Add($b); [void]$linhasSrv.Add($linha)
    Atualizar-Linhas-Servidor
}
# título e detalhe da linha compacta conforme os campos (endereço · com usuário / usa a conta da tarefa)
function Atualizar-Linhas-Servidor {
    foreach ($l in $linhasSrv | Where-Object { -not $_.Este }) {
        $n = (Texto-De $l.Nome).Trim(); $e = (Texto-De $l.Endereco).Trim(); $u = (Texto-De $l.Usuario).Trim()
        $l.Titulo.Text = $(if ($n) { $n } else { 'Servidor novo' })
        $l.Detalhe.Text = $(if ($e) { $e } else { 'sem endereço' }) + '   ·   ' + $(if ($u) { "acesso com $u" } else { 'acesso com a conta da tarefa' })
    }
}
function Nome-Servidor($l) { if ($l.Este) { $ESTE } else { (Texto-De $l.Nome).Trim() } }
Adicionar-Servidor $ESTE '' '' $false $true
foreach ($s in @(Valor $swCfg 'servidores' @())) { if ($s -and $s.nome) { Adicionar-Servidor $s.nome $s.endereco $s.usuario ([bool]"$($s.senha_cripto)") $false } }
function Ler-Servicos($linha, $botao) {
    $nome = Nome-Servidor $linha
    if (-not $nome) { Aviso 'Digite o nome do servidor antes.' 'Warning' | Out-Null; return }
    if (-not $linha.Este -and $script:alterado) { if ((Aviso 'Para ler outro servidor, salve antes (o endereço, o usuário e a senha são usados já salvos).' 'Question' 'OKCancel') -ne 'OK' -or -not (Salvar)) { return } }
    Aguarde $botao 'Lendo...'
    try {
        $r = Rodar-Servicos "-Acao listar -Servidor `"$nome`""
        if ($r.ok) {
            $script:listas[$nome] = @($r.servicos)
            $linha.Chip.Child.Text = "conectado · $(@($r.servicos).Count) serviços"; Recurso $linha.Chip ([Windows.Controls.Border]::BackgroundProperty) 'B.OkFundo'; Recurso $linha.Chip.Child ([Windows.Controls.TextBlock]::ForegroundProperty) 'B.Ok'
            $script:servidorAtual = $nome
        } else {
            $linha.Chip.Child.Text = 'sem acesso'; $linha.Chip.ToolTip = $r.erro; Recurso $linha.Chip ([Windows.Controls.Border]::BackgroundProperty) 'B.ErroFundo'; Recurso $linha.Chip.Child ([Windows.Controls.TextBlock]::ForegroundProperty) 'B.Erro'
            Aviso ("Não consegui ler os serviços de $nome`n`n$($r.erro)`n`nConfira o endereço, o usuário (administrador naquele servidor) e se a rede/firewall liberam as portas 135 e 445.") 'Warning' | Out-Null
        }
    } finally { Pronto $botao }
    Desenhar-Seletor; Desenhar-Servicos
}

# ---------- lista dos serviços do servidor escolhido ----------
$c = Cartao $pgServ 'Serviços' 'marque só os que precisam ficar SEMPRE rodando'
$selSrv = New-Object Windows.Controls.WrapPanel; [void]$c.Children.Add($selSrv)
$barraFiltro = New-Object Windows.Controls.DockPanel; $barraFiltro.Margin = '0,4,0,10'; [void]$c.Children.Add($barraFiltro)
$fil = New-Object Windows.Controls.WrapPanel; [Windows.Controls.DockPanel]::SetDock($fil, 'Right'); [void]$barraFiltro.Children.Add($fil)
foreach ($f in @(@('todos', 'Todos'), @('rodando', 'Rodando'), @('parados', 'Parados'))) {
    $rb = New-Object Windows.Controls.RadioButton; $rb.Style = $janela.FindResource('Segmento'); $rb.GroupName = 'filtroServ'; $rb.Content = $f[1]; $rb.Tag = $f[0]; $rb.Margin = '6,0,0,0'
    $rb.IsChecked = ($f[0] -eq $script:filtroServ); $rb.Add_Checked({ $script:filtroServ = $this.Tag; Desenhar-Servicos }); [void]$fil.Children.Add($rb)
}
$txtBusca = Caixa 'procurar pelo nome' ''; $txtBusca.Width = 280; $txtBusca.HorizontalAlignment = 'Left'; $txtBusca.VerticalAlignment = 'Center'; [void]$barraFiltro.Children.Add($txtBusca)
$txtBusca.Tag.Add_TextChanged({ Desenhar-Servicos })
$listaServ = New-Object Windows.Controls.StackPanel; [void]$c.Children.Add($listaServ)
function Desenhar-Seletor {
    $selSrv.Children.Clear()
    $nomes = @($linhasSrv | ForEach-Object { Nome-Servidor $_ } | Where-Object { $_ })
    if ($nomes -notcontains $script:servidorAtual) { $script:servidorAtual = $ESTE }
    foreach ($n in $nomes) {
        $rb = New-Object Windows.Controls.RadioButton; $rb.Style = $janela.FindResource('Segmento'); $rb.GroupName = 'srvServ'; $rb.Tag = $n
        $qtd = @($script:marcados.Values | Where-Object { $_.servidor -ieq $n }).Count
        $rb.Content = $n + $(if ($qtd) { "  ·  $qtd marcado$(if ($qtd -ne 1) { 's' })" } else { '' })
        $rb.IsChecked = ($n -eq $script:servidorAtual); $rb.Add_Checked({ $script:servidorAtual = $this.Tag; Desenhar-Servicos }); [void]$selSrv.Children.Add($rb)
    }
}
function Eh-Conhecido($s) { return ("$($s.nome) $($s.exibicao) $($s.programa)" -match $REGEX_CONHECIDOS) }
function Desenhar-Servicos {
    $listaServ.Children.Clear()
    $srv = $script:servidorAtual
    $lidos = $script:listas[$srv]
    $itens = New-Object System.Collections.ArrayList
    $vistos = @{}
    foreach ($s in @($lidos)) { if ($s) { [void]$itens.Add($s); $vistos[$s.nome.ToLower()] = 1 } }
    # marcado com o nome de uma versão anterior do add-on (a Invent põe a versão no nome): passa a usar o nome atual
    if ($lidos) {
        foreach ($k in @($script:marcados.Keys)) {
            $m = $script:marcados[$k]
            if ($m.servidor -ine $srv -or $vistos.ContainsKey($m.nome.ToLower())) { continue }
            $novo = @($lidos | Where-Object { (Base-Nome $_.nome) -ieq (Base-Nome $m.nome) } | Sort-Object @{ e = { $_.estado -ne 'Running' } }, @{ e = { $_.nome }; Descending = $true }) | Select-Object -First 1
            if ($novo) {
                $script:marcados.Remove($k); $antigo = $m.nome; $m.nome = $novo.nome; $m.exibicao = $novo.exibicao
                $script:marcados[("$srv|$($novo.nome)").ToLower()] = $m; Marcar-Alterado
                Status "● '$antigo' agora se chama '$($novo.nome)' (versão nova do add-on): a marcação acompanhou. Clique em Salvar." 'B.Alerta'
            }
        }
    }
    # marcados deste servidor que não vieram na leitura (ou o servidor ainda não foi lido)
    foreach ($m in $script:marcados.Values) { if ($m.servidor -ieq $srv -and -not $vistos.ContainsKey($m.nome.ToLower())) { [void]$itens.Add([pscustomobject]@{ nome = $m.nome; exibicao = $m.exibicao; estado = $(if ($lidos) { 'NaoEncontrado' } else { '' }); inicio = ''; programa = ''; pastaPrograma = ''; logsHoje = @() }) } }
    $busca = (Texto-De $txtBusca).Trim()
    # filtro: Todos / Rodando / Parados + busca pelo nome; os marcados vêm primeiro
    $mostrar = @($itens | Where-Object {
        ($script:filtroServ -eq 'todos' -or ($script:filtroServ -eq 'rodando' -and $_.estado -eq 'Running') -or ($script:filtroServ -eq 'parados' -and $_.estado -ne 'Running')) -and
        (-not $busca -or "$($_.nome) $($_.exibicao)" -like "*$busca*")
    } | Sort-Object @{ e = { -not $script:marcados.Contains(("$srv|$($_.nome)").ToLower()) } }, exibicao)
    if (-not $lidos -and -not $mostrar.Count) { [void]$listaServ.Children.Add((T "Clique em 'Ler serviços' no servidor $srv para ver a lista." 13 'B.TextoSec')); return }
    if (-not $mostrar.Count) { [void]$listaServ.Children.Add((T 'Nenhum serviço com este filtro ou busca.' 13 'B.TextoSec')); return }
    $limite = 300
    foreach ($s in ($mostrar | Select-Object -First $limite)) { Desenhar-LinhaServico $s $srv }
    if ($mostrar.Count -gt $limite) { [void]$listaServ.Children.Add((T "... e mais $($mostrar.Count - $limite). Use a busca para achar o serviço." 12 'B.TextoSec')) }
}
function Desenhar-LinhaServico($s, $srv) {
    $chave = ("$srv|$($s.nome)").ToLower()
    $m = $script:marcados[$chave]
    $bd = New-Object Windows.Controls.Border; $bd.BorderThickness = '0,1,0,0'; $bd.Padding = '4,9'; Recurso $bd ([Windows.Controls.Border]::BorderBrushProperty) 'B.Borda'
    $d = New-Object Windows.Controls.DockPanel; $bd.Child = $d
    $cb = New-Object Windows.Controls.CheckBox; $cb.Style = $janela.FindResource('Chave'); $cb.IsChecked = [bool]$m; $cb.Margin = '0,2,14,0'; $cb.VerticalAlignment = 'Top'
    $cb.ToolTip = 'Precisa ficar sempre rodando'; $cb.Tag = @($chave, $s, $srv)
    $cb.Add_Click({
        $k, $sv, $sr = $this.Tag
        if ($this.IsChecked) {
            $script:marcados[$k] = Novo-Marcado $sr $sv.nome $sv.exibicao
        } else { $script:marcados.Remove($k) }
        Marcar-Alterado; Desenhar-Seletor; Desenhar-Servicos
        # marcou: vigia SÓ se está rodando. O "travado" depende do log certo, então quem indica o arquivo é a pessoa
        # (log errado = reinício à toa de um serviço bom); a procura automática só traz SUGESTÕES para a lista
        if ($this.IsChecked) {
            $mk = $script:marcados[$k]
            if (-not @($sv.logsHoje | Where-Object { $_ }).Count -and $sv.pastaPrograma -and -not $script:logsAchados.ContainsKey(("$sr|$($sv.pastaPrograma)").ToLower())) { Procurar-Logs $sv $sr }
            Status "● $($mk.exibicao): vigia se está rodando. Para perceber TRAVADO, escolha em 'Considerar travado quando' (log, porta ou endereço). Clique em Salvar." 'B.Alerta'
        }
    })
    [Windows.Controls.DockPanel]::SetDock($cb, 'Left'); [void]$d.Children.Add($cb)
    $estado = "$($s.estado)"
    $chip = Selo $(switch ($estado) { 'Running' { 'rodando' } 'Stopped' { 'parado' } 'NaoEncontrado' { 'não encontrado' } '' { 'não lido' } default { $estado } }) $(if ($estado -eq 'Running') { 'ok' } elseif ($m -and $estado -in 'Stopped', 'NaoEncontrado') { 'erro' } else { 'neutro' })
    $chip.VerticalAlignment = 'Top'; $chip.Margin = '10,2,0,0'; [Windows.Controls.DockPanel]::SetDock($chip, 'Right'); [void]$d.Children.Add($chip)
    $sp = New-Object Windows.Controls.StackPanel; [void]$d.Children.Add($sp)
    [void]$sp.Children.Add((T $(if ($s.exibicao) { $s.exibicao } else { $s.nome }) 13 'B.Titulo' 'SemiBold'))
    $sub = T ("$($s.nome)" + $(if ($s.inicio) { " · início $($s.inicio)" } else { '' })) 11.5 'B.TextoSec'; [void]$sp.Children.Add($sub)
    if (-not $m) { [void]$listaServ.Children.Add($bd); return }
    # opções do serviço marcado, em linhas "rótulo | campos" alinhadas: se parar / travado quando / campos da regra / memória
    # (cada serviço trava de um jeito: quem escolhe a regra é a pessoa)
    $op = New-Object Windows.Controls.StackPanel; $op.Margin = '0,10,0,0'; [void]$sp.Children.Add($op)
    $w = Linha-Opcao $op 'Se parar'
    $cr = Chave 'reiniciar sozinho' $m.reiniciar; $cr.Tag = $m; $cr.Add_Click({ $this.Tag.reiniciar = [bool]$this.IsChecked }); [void]$w.Children.Add($cr)
    $w = Linha-Opcao $op 'Travado quando'
    $cbV = New-Object Windows.Controls.ComboBox; $cbV.Style = $janela.FindResource('Lista'); $cbV.Width = 300
    foreach ($o in $REGRAS_TRAVADO) { $it = New-Object Windows.Controls.ComboBoxItem; $it.Tag = $o[0]; $it.Content = $o[1]; [void]$cbV.Items.Add($it); if ($o[0] -eq $m.verificacao) { $cbV.SelectedItem = $it } }
    if ($cbV.SelectedIndex -lt 0) { $cbV.SelectedIndex = 0 }
    [void]$w.Children.Add($cbV)
    # um painel por regra; só o da regra escolhida aparece
    $pLog = New-Object Windows.Controls.StackPanel; [void]$op.Children.Add($pLog)
    $pPorta = New-Object Windows.Controls.StackPanel; [void]$op.Children.Add($pPorta)
    $pUrl = New-Object Windows.Controls.StackPanel; [void]$op.Children.Add($pUrl)
    Montar-RegraLog $pLog $m $s $srv
    # porta: conexão TCP a partir deste servidor
    $w = Linha-Opcao $pPorta 'Porta'
    $cxP = Caixa 'ex.: 8080' $(if ($m.porta) { $m.porta } else { '' }); $cxP.Width = 110; $cxP.Margin = '0,0,10,0'; $cxP.Tag.Tag = @($cxP.Tag.Tag, $m)
    $cxP.Tag.Add_TextChanged({ $v = 0; $x = $this.Text.Trim(); $this.Tag[1].porta = $(if (-not $x) { 0 } elseif ([int]::TryParse($x, [ref]$v)) { $v } else { -1 }) })
    [void]$w.Children.Add($cxP); [void]$w.Children.Add((Dica-Opcao 'testada a partir deste servidor · travado na 2ª verificação seguida sem resposta'))
    # endereço (URL): respondeu abaixo de 500 = vivo
    $w = Linha-Opcao $pUrl 'Endereço'
    $cxU = Caixa 'http://servidor:porta/caminho' $m.url; $cxU.Width = 400; $cxU.Tag.Tag = @($cxU.Tag.Tag, $m)
    $cxU.Tag.Add_TextChanged({ $this.Tag[1].url = $this.Text.Trim() })
    [void]$w.Children.Add($cxU)
    $w = Linha-Opcao $pUrl ''
    [void]$w.Children.Add((Dica-Opcao 'respondeu (mesmo com erro abaixo de 500) = vivo · travado na 2ª verificação seguida sem resposta'))
    # memória (opcional, vale com qualquer regra): acima do limite em 2 verificações seguidas = travado
    $w = Linha-Opcao $op 'Memória acima de'
    $cxM = Caixa 'MB' $(if ($m.memoria_mb) { $m.memoria_mb } else { '' }); $cxM.Width = 110; $cxM.Tag.TextAlignment = 'Right'; $cxM.Margin = '0,0,10,0'; $cxM.Tag.Tag = @($cxM.Tag.Tag, $m)
    $cxM.Tag.Add_TextChanged({ $v = 0; $x = $this.Text.Trim(); $this.Tag[1].memoria_mb = $(if (-not $x) { 0 } elseif ([int]::TryParse($x, [ref]$v)) { $v } else { -1 }) })
    [void]$w.Children.Add($cxM)
    [void]$w.Children.Add((Dica-Opcao ('MB também é travado · opcional, em branco = não olha' + $(if ($s.memoriaMB) { " · agora: $($s.memoriaMB) MB" } else { '' }))))
    $cbV.Tag = @($m, $pLog, $pPorta, $pUrl)
    $cbV.Add_SelectionChanged({
        $mm, $a, $b, $c = $this.Tag
        $mm.verificacao = "$($this.SelectedItem.Tag)"
        Mostrar-Regra $mm $a $b $c; Marcar-Alterado
        if ($mm.verificacao -eq 'log' -and -not $mm.log) { Status "● $($mm.exibicao): indique o arquivo de log (digite, cole ou clique em Procurar...) e clique em Salvar." 'B.Alerta' }
    })
    Mostrar-Regra $m $pLog $pPorta $pUrl
    [void]$listaServ.Children.Add($bd)
}
# linha de opção: rótulo de largura fixa à esquerda (todos alinhados) + os campos; devolve onde entram os campos
function Linha-Opcao($pai, $rotulo) {
    $d = New-Object Windows.Controls.DockPanel; $d.Margin = '0,0,0,8'; [void]$pai.Children.Add($d)
    $l = T $rotulo 12.5 'B.TextoSec'; $l.Width = 130; $l.VerticalAlignment = 'Center'; [Windows.Controls.DockPanel]::SetDock($l, 'Left'); [void]$d.Children.Add($l)
    $w = New-Object Windows.Controls.WrapPanel; $w.VerticalAlignment = 'Center'; [void]$d.Children.Add($w); return $w
}
function Dica-Opcao($texto) { $t = T $texto 11.5 'B.TextoSec'; $t.VerticalAlignment = 'Center'; $t.Opacity = 0.85; return $t }
function Mostrar-Regra($m, $pLog, $pPorta, $pUrl) {
    $pLog.Visibility = $(if ($m.verificacao -eq 'log') { 'Visible' } else { 'Collapsed' })
    $pPorta.Visibility = $(if ($m.verificacao -eq 'porta') { 'Visible' } else { 'Collapsed' })
    $pUrl.Visibility = $(if ($m.verificacao -eq 'url') { 'Visible' } else { 'Collapsed' })
}
# regra "o log parar de andar": caminho do arquivo (digitar, colar ou Procurar...), sugestões achadas, minutos e o texto do ciclo
function Montar-RegraLog($p, $m, $s, $srv) {
    if (-not $m.travado_min) { $m.travado_min = 30 }
    $w = Linha-Opcao $p 'Arquivo de log'
    $l1 = New-Object Windows.Controls.DockPanel; $l1.Width = 410; [void]$w.Children.Add($l1)
    $bpq = Botao 'Procurar...' 'BotaoSecundario' { Escolher-Log $this.Tag[0] $this.Tag[1] $this.Tag[2] } 0xE8E5
    $bpq.Tag = @($m, $s, $srv); $bpq.Padding = '12,6'; $bpq.Margin = '8,0,0,0'; $bpq.VerticalAlignment = 'Center'; $bpq.ToolTip = 'Escolher o arquivo (no outro servidor, pelo \\endereço\C$)'
    [Windows.Controls.DockPanel]::SetDock($bpq, 'Right'); [void]$l1.Children.Add($bpq)
    $cxL = Caixa 'digite ou cole o caminho, ou clique em Procurar...' $m.log; $cxL.Tag.Tag = @($cxL.Tag.Tag, $m); $cxL.ToolTip = $m.log
    $cxL.Tag.Add_TextChanged({ $this.Tag[1].log = $this.Text.Trim().Trim('"') })
    # ao sair do campo: o arquivo do dia vira um padrão que acompanha a data (...\2026\11\11_X.log -> ...\{AAAA}\{MM}\{DD}_X.log)
    $cxL.Tag.Add_LostFocus({
        $pad = Padrao-Digitado $this.Text
        if ($pad -ne $this.Text) { $this.Text = $pad; if ($pad -match '\{(AAAA|MM|DD)\}') { Status "● Log de $($this.Tag[1].exibicao): $pad (a data do arquivo virou {AAAA}/{MM}/{DD}, para servir todo dia). Clique em Salvar." 'B.Alerta' } }
    })
    [void]$l1.Children.Add($cxL)
    # sugestões: os logs de hoje no padrão Invent (logs\AAAA\MM\dd_*) + os achados pela procura automática
    $cand = New-Object System.Collections.ArrayList
    $hoje = Get-Date
    foreach ($lg in @($s.logsHoje | Where-Object { $_ })) {
        if ($s.pastaPrograma) { [void]$cand.Add([pscustomobject]@{ caminho = "$($s.pastaPrograma)".TrimEnd('\') + ("\logs\{0:yyyy}\{0:MM}\" -f $hoje) + $lg.nome; gravadoEm = $lg.gravadoEm }) }
    }
    $ach = $script:logsAchados[("$srv|$($s.pastaPrograma)").ToLower()]
    foreach ($a in @($ach)) { if ($a -and -not ($cand | Where-Object { $_.caminho -ieq $a.caminho })) { [void]$cand.Add([pscustomobject]@{ caminho = $a.caminho; gravadoEm = $a.gravadoEm }) } }
    if ($cand.Count -or $s.pastaPrograma) {
        $w = Linha-Opcao $p 'Sugestões'
        if ($cand.Count) {
            $cb2 = New-Object Windows.Controls.ComboBox; $cb2.Style = $janela.FindResource('Lista'); $cb2.Width = 410; $cb2.Margin = '0,0,8,0'
            [void]$cb2.Items.Add("$($cand.Count) arquivo(s) gravado(s) perto do programa: escolha para usar")
            foreach ($c in ($cand | Sort-Object { $_.gravadoEm } -Descending)) {
                $idade = [int]((Get-Date) - [datetime]$c.gravadoEm).TotalMinutes
                $it = New-Object Windows.Controls.ComboBoxItem; $it.Tag = $c; $it.ToolTip = $c.caminho
                $it.Content = (Split-Path $c.caminho -Leaf) + '   ·   gravado há ' + $(if ($idade -lt 120) { "$idade min" } else { "$([int]($idade / 60)) h" }) + '   ·   ' + (Split-Path $c.caminho)
                [void]$cb2.Items.Add($it)
            }
            $cb2.SelectedIndex = 0
            $cb2.Tag = @($m, $cxL)
            $cb2.Add_SelectionChanged({
                $mm, $caixa = $this.Tag
                if ($this.SelectedIndex -le 0) { return }
                $c = $this.SelectedItem.Tag
                # o arquivo escolhido vira um padrão que acompanha a data (troca de arquivo todo dia)
                $mm.log = Padrao-Do-Arquivo $c.caminho ([datetime]$c.gravadoEm); Definir $caixa $mm.log
                Marcar-Alterado; Status "● Log de $($mm.exibicao): $($mm.log). Clique em Salvar." 'B.Alerta'
            })
            [void]$w.Children.Add($cb2)
        }
        if ($s.pastaPrograma) {
            $bp = Botao $(if ($cand.Count) { 'Procurar de novo' } else { 'Procurar logs perto do programa' }) 'BotaoLink' { Procurar-Logs $this.Tag[0] $this.Tag[1] } 0xE721
            $bp.Tag = @($s, $srv); $bp.VerticalAlignment = 'Center'; $bp.ToolTip = 'Procura os logs gravados nos últimos 3 dias na pasta do programa e em volta dela (só sugestões)'; [void]$w.Children.Add($bp)
        }
    }
    # minutos sem ciclo + texto que marca o ciclo
    $w = Linha-Opcao $p 'Sem ciclo há'
    $cxMin = Caixa '30' $m.travado_min; $cxMin.Width = 70; $cxMin.Tag.TextAlignment = 'Right'; $cxMin.Margin = '0,0,8,0'; $cxMin.Tag.Tag = @($cxMin.Tag.Tag, $m)
    $cxMin.Tag.Add_TextChanged({ $v = 0; $x = $this.Text.Trim(); $this.Tag[1].travado_min = $(if ([int]::TryParse($x, [ref]$v)) { $v } else { -1 }) })
    [void]$w.Children.Add($cxMin)
    $a2 = T 'min · ciclo = linha com' 12.5 'B.Texto'; $a2.VerticalAlignment = 'Center'; $a2.Margin = '0,0,8,0'; [void]$w.Children.Add($a2)
    $cxT = Caixa 'qualquer linha' $m.texto_ciclo; $cxT.Width = 170; $cxT.Tag.Tag = @($cxT.Tag.Tag, $m)
    $cxT.Tag.Add_TextChanged({ $this.Tag[1].texto_ciclo = $this.Text.Trim() })
    [void]$w.Children.Add($cxT)
    $w = Linha-Opcao $p ''
    [void]$w.Children.Add((Dica-Opcao '[Completed] = ciclo concluído dos serviços Invent · em branco = qualquer gravação no log conta como vivo'))
}
# caminho digitado/colado: \\servidor\C$\... vira C:\... (é como o monitoramento lê naquele servidor) e a data do arquivo vira {AAAA}{MM}{DD}
function Padrao-Digitado($v) {
    $v = "$v".Trim().Trim('"'); if (-not $v) { return '' }
    if ($v -match '^\\\\[^\\]+\\([A-Za-z])\$\\(.*)$') { $v = "$($Matches[1]):\$($Matches[2])" }
    if ($v -match '\{(AAAA|MM|DD)\}') { return $v }
    $nomeArq = Split-Path $v -Leaf; $d = $null
    if ($nomeArq -match '(20\d\d)[-.]?(\d\d)[-.]?(\d\d)') { $d = Data-Valida $Matches[1] $Matches[2] $Matches[3] }
    if (-not $d -and $nomeArq -match '(\d\d)-(\d\d)-(20\d\d)') { $d = Data-Valida $Matches[3] $Matches[2] $Matches[1] }
    if (-not $d -and $v -match '\\(20\d\d)\\(\d\d)\\(\d\d)[_\-.][^\\]*$') { $d = Data-Valida $Matches[1] $Matches[2] $Matches[3] }
    if (-not $d -and $v -match '\\(20\d\d)\\(\d\d)\\[^\\]*$') { $d = Data-Valida $Matches[1] $Matches[2] '01' }
    if (-not $d) { return $v }
    return (Padrao-Do-Arquivo $v $d)
}
function Data-Valida($a, $m, $d) { try { return (New-Object DateTime ([int]$a), ([int]$m), ([int]$d)) } catch { return $null } }
# procura automática dos logs de um serviço (servicos.ps1 -Acao procurarlog, só leitura); guarda por servidor|pasta
$script:logsAchados = @{}
# $m (opcional) = serviço que acabou de ser marcado: se ainda não tem log, já fica com o log gravado mais recente
# e o "travado" ligado (30 min sem ciclo) — a pessoa confere e troca na lista
function Procurar-Logs($s, $srv, $m = $null) {
    Trabalhando $true; Status "Procurando os logs de $($s.exibicao)..."
    try {
        $r = Rodar-Servicos "-Acao procurarlog -Servidor `"$srv`" -Nome `"$($s.pastaPrograma)`""
        $achados = @(if ($r.ok) { $r.logs | Where-Object { $_ } })   # @(...) por fora: com 1 só, o PS 5.1 desembrulha a lista
        $script:logsAchados[("$srv|$($s.pastaPrograma)").ToLower()] = $achados
        if ($m -and -not $m.log -and $achados.Count) {
            $m.log = Padrao-Do-Arquivo $achados[0].caminho ([datetime]$achados[0].gravadoEm); if (-not $m.travado_min) { $m.travado_min = 30 }
            Marcar-Alterado
            Status "● $($m.exibicao): vigia se está rodando e o log $($m.log) (travado após $($m.travado_min) min sem ciclo). Confira o arquivo e clique em Salvar." 'B.Alerta'
        } else {
            Status $(if ($r.ok) { "$($achados.Count) arquivo(s) de log achado(s) perto do programa de $($s.exibicao)." } else { "Não consegui procurar os logs: $($r.erro)" }) $(if ($r.ok) { 'B.TextoSec' } else { 'B.Alerta' })
        }
    } finally { Trabalhando $false }
    Desenhar-Servicos
}
# "Escolher arquivo de log...": abre a pasta do programa (no outro servidor, pelo \\endereço\C$) e transforma o arquivo
# escolhido num padrão que acompanha a data: ...\2026\11\11_X.log -> ...\{AAAA}\{MM}\{DD}_X.log
function Escolher-Log($m, $s, $srv) {
    $linhaSrv = $linhasSrv | Where-Object { (Nome-Servidor $_) -ieq $srv } | Select-Object -First 1
    $endereco = if ($linhaSrv -and -not $linhaSrv.Este) { (Texto-De $linhaSrv.Endereco).Trim() } else { '' }
    $pastaIni = "$($s.pastaPrograma)"; if (-not $pastaIni -and $m.log) { $pastaIni = ($m.log -replace '\\\{.*$', '') }
    if ($endereco -and $pastaIni -match '^([A-Za-z]):\\(.*)$') { $pastaIni = "\\$endereco\$($Matches[1])`$\$($Matches[2])" }
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Title = "Arquivo de log de $($m.exibicao)"; $dlg.Filter = 'Logs (*.log;*.txt)|*.log;*.txt|Todos os arquivos|*.*'
    if ($pastaIni -and (Test-Path -LiteralPath $pastaIni)) { $dlg.InitialDirectory = $pastaIni }
    if (-not $dlg.ShowDialog($janela)) { return }
    $arq = $dlg.FileName
    # escolhido pelo \\endereço\C$\...: grava como o caminho DAQUELE servidor (C:\...), que é como o monitoramento lê
    if ($endereco -and $arq -match ('^\\\\' + [regex]::Escape($endereco) + '\\([A-Za-z])\$\\(.*)$')) { $arq = "$($Matches[1]):\$($Matches[2])" }
    $m.log = Padrao-Do-Arquivo $arq (Get-Item -LiteralPath $dlg.FileName).LastWriteTime
    if (-not $m.travado_min) { $m.travado_min = 30 }
    Marcar-Alterado; Desenhar-Servicos
    Status "● Log de $($m.exibicao): $($m.log) · travado após $($m.travado_min) min sem ciclo. Clique em Salvar." 'B.Alerta'
}
# troca a data do arquivo pelos marcadores {AAAA} {MM} {DD} (pastas de ano/mês e datas no nome), para servir todo dia
function Padrao-Do-Arquivo($arq, [datetime]$data) {
    $ano = $data.ToString('yyyy'); $mes = $data.ToString('MM'); $dia = $data.ToString('dd')
    $dir = Split-Path $arq; $nomeArq = Split-Path $arq -Leaf
    $dir = $dir -replace ('\\' + $ano + '\\' + $mes + '(?=\\|$)'), '\{AAAA}\{MM}'
    $dir = $dir -replace ('\\' + $ano + '(?=\\|$)'), '\{AAAA}'
    $nomeArq = $nomeArq.Replace("$ano-$mes-$dia", '{AAAA}-{MM}-{DD}').Replace("$ano$mes$dia", '{AAAA}{MM}{DD}').Replace("$dia-$mes-$ano", '{DD}-{MM}-{AAAA}').Replace("$ano.$mes.$dia", '{AAAA}.{MM}.{DD}')
    if ($nomeArq -match ('^' + $dia + '[_\-.]')) { $nomeArq = '{DD}' + $nomeArq.Substring(2) }
    return ($dir.TrimEnd('\') + '\' + $nomeArq)   # (sem Join-Path: o disco pode ser de OUTRO servidor e não existir aqui)
}
# nome do serviço sem a versão na frente ("25.12.30.53022_TaxPlusNfeSendCancel" -> "TaxPlusNfeSendCancel")
function Base-Nome($n) { return ("$n" -replace '^\d+(\.\d+)+_', '') }
Desenhar-Seletor; Desenhar-Servicos

# ---------- Versão ----------
$arqVersao = Join-Path $pasta 'versao.txt'
$pastaAtu = Join-Path $pasta 'atualizacoes'
function Versao-Instalada { try { $v = ([IO.File]::ReadAllText($arqVersao)).Trim(); if ($v) { return $v } } catch { }; return '' }
function Achar-Node {
    $cmdNode = Get-Command node.exe -ErrorAction SilentlyContinue
    if (Test-Path -LiteralPath (Join-Path $pasta 'node\node.exe')) { return (Join-Path $pasta 'node\node.exe') }
    if ($cmdNode) { return $cmdNode.Source }
    if (Test-Path "$env:ProgramFiles\nodejs\node.exe") { return "$env:ProgramFiles\nodejs\node.exe" }
    return ''
}
# roda o Node sem travar a janela e devolve o que ele escreveu
function Rodar-Node($argumentos) {
    $node = Achar-Node
    if (-not $node) { return 'ERRO: Node.js não encontrado - rode o INSTALAR.vbs (baixa o Node) ou instale a LTS em https://nodejs.org/pt/download' }
    $psi = New-Object Diagnostics.ProcessStartInfo($node, $argumentos)
    $psi.WorkingDirectory = $pasta; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $psi.StandardOutputEncoding = [Text.Encoding]::UTF8; $psi.StandardErrorEncoding = [Text.Encoding]::UTF8
    $proc = [Diagnostics.Process]::Start($psi)
    $saida = $proc.StandardOutput.ReadToEndAsync(); $erro = $proc.StandardError.ReadToEndAsync()
    while (-not $proc.HasExited) { Bombear; Start-Sleep -Milliseconds 60 }
    $proc.WaitForExit()
    return (($saida.Result + $erro.Result).Trim())
}
$pgVersao = Nova-Pagina; $paginas['versao'] = $pgVersao
$c = Cartao $pgVersao 'Versão do monitoramento' 'publicada pela SPS Group, com o carimbo (assinatura) da SPS'
$lblVersao = T '' 14 'B.Titulo'; $lblVersao.LineHeight = 22; $lblVersao.Margin = '0,0,0,12'; [void]$c.Children.Add($lblVersao)
$w = Linha $c
$btnVerificar = Botao 'Verificar atualização' 'BotaoSecundario' { Verificar-Versao } 0xE72C; $btnVerificar.Margin = '0,0,10,10'; [void]$w.Children.Add($btnVerificar)
$btnAtualizar = Botao 'Atualizar' 'BotaoPrimario' { Atualizar-Versao } 0xE896; $btnAtualizar.Margin = '0,0,0,10'; $btnAtualizar.Visibility = 'Collapsed'; [void]$w.Children.Add($btnAtualizar)
[void]$c.Children.Add((T 'A atualização mantém as Service Layers, o e-mail, as senhas, os tempos, os logs e o histórico. O monitoramento continua rodando durante a atualização.' 12 'B.TextoSec'))
$c = Cartao $pgVersao 'Novidades e andamento' ''
$resVersao = NovaSaida $c 260
$script:fichaNova = $null; $script:versaoVerificada = $false
function Mostrar-Versao([string]$extra, $chave = 'B.Titulo') {
    $v = Versao-Instalada
    Recurso $lblVersao ([Windows.Controls.TextBlock]::ForegroundProperty) $chave
    $lblVersao.Text = 'Versão instalada: ' + $(if ($v) { $v } else { 'anterior ao atualizador (sem número)' }) + $(if ($extra) { "`n$extra" } else { '' })
}
function Verificar-Versao {
    $script:versaoVerificada = $true
    Aguarde $btnVerificar 'Verificando...'; $btnAtualizar.Visibility = 'Collapsed'
    try {
        Mostrar-Versao 'Consultando a versão publicada pela SPS...'
        $resVersao.Clear()
        $texto = Rodar-Node 'atualizacao.js verificar'
        $r = $null; try { $r = $texto | ConvertFrom-Json } catch { }
        if (-not $r -or $r.erro) { Mostrar-Versao 'Não foi possível verificar agora.' 'B.Alerta'; Saida $resVersao ('Não foi possível verificar: ' + $(if ($r -and $r.erro) { $r.erro } else { $texto })); return }
        $f = $r.disponivel
        if ($r.temNova) {
            $script:fichaNova = $f
            Mostrar-Versao ('Versão nova disponível: ' + $f.versao + ' (publicada em ' + $f.data + ')') 'B.Ok'
            Texto-Botao $btnAtualizar ('Atualizar para a versão ' + $f.versao); $btnAtualizar.Visibility = 'Visible'
            Saida $resVersao ('Novidades da versão ' + $f.versao + ':')
        } else {
            $script:fichaNova = $null
            Mostrar-Versao ('Esta é a versão mais nova publicada (' + $f.versao + ').') 'B.Ok'
            Saida $resVersao ('Versão publicada: ' + $f.versao + ' (' + $f.data + '). Novidades dela:')
        }
        foreach ($n in @($f.novidades)) { $resVersao.AppendText('   - ' + $n + "`r`n") }
    } finally { Pronto $btnVerificar; Atualizar-Menu }
}
function Atualizar-Versao {
    $f = $script:fichaNova; if (-not $f) { return }
    if ((Aviso "Atualizar o monitoramento para a versão $($f.versao)?`n`nAs Service Layers, o e-mail, as senhas, os tempos e os logs são mantidos. O instalador do Windows assume em até 1 minuto." 'Question' 'YesNo') -ne 'Yes') { return }
    $btnAtualizar.IsEnabled = $false; $btnVerificar.IsEnabled = $false
    Trabalhando $true
    Saida $resVersao ('Baixando a versão ' + $f.versao + ' e conferindo o carimbo da SPS e a impressão digital...')
    $texto = Rodar-Node 'atualizacao.js baixar'
    if ($texto -notmatch '^OK ') { Trabalhando $false; Saida $resVersao ('Atualização não iniciada: ' + ($texto -replace '^ERRO:\s*', '')); $btnAtualizar.IsEnabled = $true; $btnVerificar.IsEnabled = $true; return }
    Registrar-Alteracoes @(Mudou 'Versão (pedido de atualização)' (Versao-Instalada) $f.versao)
    Saida $resVersao 'Pacote conferido. Chamando o atualizador do Windows...'
    try { Start-ScheduledTask -TaskName $nomeAtualizador -TaskPath '\SPS Group\' -ErrorAction Stop } catch { Saida $resVersao 'O atualizador será executado no próximo minuto.' }
    $script:pedidoEm = Get-Date; $script:ultimaFase = ''
    $relogioAtu.Start()
}
# acompanha o atualizador pelo arquivo que ele escreve (atualizacoes\estado-instalador.json)
$relogioAtu = New-Object Windows.Threading.DispatcherTimer; $relogioAtu.Interval = [TimeSpan]::FromSeconds(2)
$relogioAtu.Add_Tick({
    $arqEstado = Join-Path $pastaAtu 'estado-instalador.json'
    $e = $null
    if (Test-Path -LiteralPath $arqEstado) { try { $e = [IO.File]::ReadAllText($arqEstado) | ConvertFrom-Json } catch { } }
    if ($e -and $e.fase -ne $script:ultimaFase) { $script:ultimaFase = $e.fase; Saida $resVersao $e.mensagem }
    if ($e -and $e.fase -eq 'concluido') {
        $relogioAtu.Stop(); Trabalhando $false
        Mostrar-Versao 'Atualização concluída. Feche esta tela e abra de novo pelo ícone para usar a versão nova.' 'B.Ok'
        $btnAtualizar.Visibility = 'Collapsed'; $btnVerificar.IsEnabled = $true
        Aviso "Versão $(Versao-Instalada) instalada.`n`nFeche esta tela e abra de novo pelo ícone 'Monitoramento da Service Layer' para usar a versão nova." | Out-Null
    } elseif ($e -and $e.fase -eq 'erro') {
        $relogioAtu.Stop(); Trabalhando $false; Mostrar-Versao 'A atualização não foi concluída (detalhes abaixo e em logs\atualizacao.log).' 'B.Erro'
        $btnAtualizar.IsEnabled = $true; $btnVerificar.IsEnabled = $true
    } elseif ((Test-Path -LiteralPath (Join-Path $pastaAtu 'pedido.json')) -and ((Get-Date) - $script:pedidoEm).TotalMinutes -gt 3) {
        $relogioAtu.Stop(); Trabalhando $false
        Saida $resVersao "O atualizador do Windows não pegou o pedido em 3 minutos. Confira no Agendador de Tarefas a tarefa '\SPS Group\$nomeAtualizador' (criada pelo instalador a partir desta versão) ou rode o INSTALAR.vbs desta pasta."
        $btnAtualizar.IsEnabled = $true; $btnVerificar.IsEnabled = $true
    }
})

# ---------- Painel: situação de tudo agora (só leitura: estado e histórico que o monitoramento grava) ----------
$pgPainel = Nova-Pagina; $paginas['painel'] = $pgPainel
function Data-Historico($t) {
    # o monitoramento grava "dd/mm, hh:mm:ss" (sem ano): se cair no futuro, é do ano passado
    if ("$t" -notmatch '^(\d{2})/(\d{2}),? (\d{2}):(\d{2}):(\d{2})') { return $null }
    try { $d = Get-Date -Year (Get-Date).Year -Month ([int]$Matches[2]) -Day ([int]$Matches[1]) -Hour ([int]$Matches[3]) -Minute ([int]$Matches[4]) -Second ([int]$Matches[5]); if ($d -gt (Get-Date).AddDays(1)) { $d = $d.AddYears(-1) }; return $d } catch { return $null }
}
function Situacao-SL($nome) {
    $seg = $nome -replace '[^A-Za-z0-9_-]', '_'
    $est = Ler-Json (Join-Path $pasta "dados\$seg\estado.json")
    $ultimoLog = Get-ChildItem -LiteralPath (Join-Path $pasta "logs\$seg") -Filter '????-??-??.log' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    $s = [pscustomobject]@{ nome = $nome; tipo = 'neutro'; texto = 'ainda sem verificação'; quando = $(if ($ultimoLog) { $ultimoLog.LastWriteTime } else { $null }) }
    if (-not $est) { return $s }
    $agoraMs = [DateTimeOffset]::Now.ToUnixTimeMilliseconds()
    if ($est.reiniciandoDesde -and ($agoraMs - [int64]$est.reiniciandoDesde) -lt 15 * 60000) { $s.tipo = 'alerta'; $s.texto = 'reiniciando agora' }
    elseif ([int]$est.falhas -gt 0 -and $est.primeiraFalha) { $s.tipo = 'erro'; $s.texto = 'sem resposta há ' + [int](($agoraMs - [int64]$est.primeiraFalha) / 60000) + ' min' }
    else { $s.tipo = 'ok'; $s.texto = 'respondendo' }
    return $s
}
function Montar-Painel {
    $pgPainel.Children.Clear()
    $cfgAtual = Ler-Json $arqConfig
    $sls = @((Valor $cfgAtual 'servicos' @()) | Where-Object { $_ -and $_.nome })
    $situacoes = @($sls | ForEach-Object { Situacao-SL $_.nome })
    $w = New-Object Windows.Controls.WrapPanel; [void]$pgPainel.Children.Add($w)
    function Resumo($icone, $titulo, $grande, $chave, $linhas, $botao, $destino) {
        $b = New-Object Windows.Controls.Border; $b.CornerRadius = 12; $b.BorderThickness = 1; $b.Padding = '20,16'; $b.Margin = '0,0,14,14'; $b.Width = 268
        Recurso $b ([Windows.Controls.Border]::BackgroundProperty) 'B.Cartao'; Recurso $b ([Windows.Controls.Border]::BorderBrushProperty) 'B.Borda'
        $p = New-Object Windows.Controls.StackPanel; $b.Child = $p
        $h = New-Object Windows.Controls.StackPanel; $h.Orientation = 'Horizontal'; $ic = Icone $icone 16; $ic.Margin = '0,2,10,0'; [void]$h.Children.Add($ic); [void]$h.Children.Add((T $titulo 14 'B.Titulo' 'SemiBold')); [void]$p.Children.Add($h)
        $g = T $grande 24 $chave 'SemiBold'; $g.Margin = '0,10,0,4'; [void]$p.Children.Add($g)
        foreach ($x in $linhas) { [void]$p.Children.Add((T $x 12 'B.TextoSec')) }
        if ($botao) { $bt = Botao $botao 'BotaoLink' { Ir-Para $this.Tag }; $bt.Tag = $destino; $bt.Margin = '-6,8,0,0'; $bt.HorizontalAlignment = 'Left'; [void]$p.Children.Add($bt) }
        [void]$w.Children.Add($b)
    }
    # Service Layer
    if (-not $sls.Count) { Resumo 0xE968 'Service Layer' 'Nenhuma' 'B.Alerta' @('cadastre a primeira Service Layer') 'Abrir Service Layer' 'sl' }
    else {
        $ok = @($situacoes | Where-Object { $_.tipo -eq 'ok' }).Count
        $ruins = @($situacoes | Where-Object { $_.tipo -in 'erro', 'alerta' } | ForEach-Object { "$($_.nome): $($_.texto)" })
        Resumo 0xE968 'Service Layer' "$ok de $($sls.Count) ok" $(if ($ruins.Count) { 'B.Erro' } else { 'B.Ok' }) $(if ($ruins.Count) { $ruins } else { @('todas respondendo') }) 'Abrir Service Layer' 'sl'
    }
    # Serviços do Windows (o que o monitoramento gravou em dados\servicos\<SERVIDOR>_<SERVIÇO>\estado.json)
    $mons = @((Valor (Valor $cfgAtual 'servicos_windows' $null) 'monitorados' @()) | Where-Object { $_ -and $_.nome })
    if (-not $mons.Count) { Resumo 0xE912 'Serviços do Windows' 'Nenhum' 'B.TextoSec' @('marque os que precisam ficar sempre rodando') 'Abrir serviços' 'servicos' }
    else {
        $ruinsS = @(); $okS = 0
        foreach ($m in $mons) {
            $est = Ler-Json (Join-Path $pasta ("dados\servicos\" + (("$($m.servidor)_$($m.nome)") -replace '[^A-Za-z0-9_-]', '_') + '\estado.json'))
            if ($est -and $est.problema) { $ruinsS += "$($m.exibicao) ($($m.servidor)): " + $(switch ($est.problema) { 'travado' { 'travado' } 'parado' { 'parado' } 'nao_existe' { 'não encontrado' } 'sem_acesso' { 'servidor sem acesso' } default { $est.problema } }) } else { $okS++ }
        }
        Resumo 0xE912 'Serviços do Windows' "$okS de $($mons.Count) ok" $(if ($ruinsS.Count) { 'B.Erro' } else { 'B.Ok' }) $(if ($ruinsS.Count) { @($ruinsS | Select-Object -First 3) } else { @('todos rodando') }) 'Abrir serviços' 'servicos'
    }
    # Agendador
    $t = Get-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue
    if (-not $t) { Resumo 0xE787 'Agendador' 'Sem tarefa' 'B.Erro' @('rode o INSTALAR.vbs desta pasta') 'Abrir agendador' 'tarefa' }
    else {
        $i = $t | Get-ScheduledTaskInfo
        $parada = ([string]$t.State -eq 'Disabled')
        Resumo 0xE787 'Agendador' $(if ($parada) { 'Parado' } else { 'Ativo' }) $(if ($parada) { 'B.Erro' } else { 'B.Ok' }) @($(if ($parada) { 'nada está sendo vigiado' } else { 'roda a cada 1 min · ' + $(if (Eh-System $t.Principal.UserId) { 'SYSTEM' } else { $t.Principal.UserId }) }), ('última execução ' + (DataBR $i.LastRunTime))) 'Abrir agendador' 'tarefa'
    }
    # E-mail
    $temEmail = [bool]((Valor $cfgAtual 'smtp_servidor' '') -and (Valor $cfgAtual 'email_para' ''))
    Resumo 0xE715 'E-mail e avisos' $(if ($temEmail) { 'Configurado' } else { 'Falta' }) $(if ($temEmail) { 'B.Ok' } else { 'B.Alerta' }) @($(if ($temEmail) { 'para: ' + (Valor $cfgAtual 'email_para' '') } else { 'sem SMTP ou destinatário: os avisos não saem' })) 'Abrir e-mail' 'email'
    # últimos acontecimentos (históricos de todas as Service Layers, sem as medições de rotina)
    $eventos = New-Object System.Collections.ArrayList
    foreach ($s in $sls) {
        $arq = Join-Path $pasta ("logs\" + ($s.nome -replace '[^A-Za-z0-9_-]', '_') + '\historico.log')
        if (-not (Test-Path -LiteralPath $arq)) { continue }
        foreach ($ln in @(Get-Content -LiteralPath $arq -TotalCount 60 -Encoding UTF8 -ErrorAction SilentlyContinue | Where-Object { $_ -and -not $_.StartsWith('#') })) {
            $partes = $ln -split ' \| ', 3
            if ($partes.Count -lt 2 -or $partes[1] -eq 'Medição') { continue }
            [void]$eventos.Add([pscustomobject]@{ quando = (Data-Historico $partes[0]); sl = $s.nome; evento = $partes[1]; detalhe = $(if ($partes.Count -gt 2) { $partes[2] } else { '' }) })
        }
    }
    foreach ($m in $mons) {
        $arq = Join-Path $pasta ("logs\servicos\" + (("$($m.servidor)_$($m.nome)") -replace '[^A-Za-z0-9_-]', '_') + '\historico.log')
        if (-not (Test-Path -LiteralPath $arq)) { continue }
        foreach ($ln in @(Get-Content -LiteralPath $arq -TotalCount 40 -Encoding UTF8 -ErrorAction SilentlyContinue | Where-Object { $_ -and -not $_.StartsWith('#') })) {
            $partes = $ln -split ' \| ', 3
            if ($partes.Count -lt 2) { continue }
            [void]$eventos.Add([pscustomobject]@{ quando = (Data-Historico $partes[0]); sl = "$($m.servidor) · $($m.exibicao)"; evento = $partes[1]; detalhe = $(if ($partes.Count -gt 2) { $partes[2] } else { '' }) })
        }
    }
    $c = Cartao $pgPainel 'Últimos acontecimentos' 'os mesmos que vão por e-mail · histórico completo em logs\...\historico.log'
    $lista = @($eventos | Where-Object { $_.quando } | Sort-Object quando -Descending | Select-Object -First 10)
    if (-not $lista.Count) { [void]$c.Children.Add((T 'Nenhuma ocorrência registrada ainda.' 13 'B.TextoSec')) }
    foreach ($e in $lista) {
        $d = New-Object Windows.Controls.DockPanel; $d.Margin = '0,0,0,10'
        $h = T $e.quando.ToString('dd/MM HH:mm') 12 'B.TextoSec'; $h.Width = 86; $h.TextWrapping = 'NoWrap'; [Windows.Controls.DockPanel]::SetDock($h, 'Left'); [void]$d.Children.Add($h)
        $tipo = if ($e.evento -match 'não|falha|indispon|permanece|fora há|parado|travado|sem acesso') { 'B.Erro' } elseif ($e.evento -match 'reinic|tentativa|comando') { 'B.Alerta' } else { 'B.Ok' }
        $bol = New-Object Windows.Shapes.Ellipse; $bol.Width = 9; $bol.Height = 9; $bol.Margin = '0,4,10,0'; $bol.VerticalAlignment = 'Top'; Recurso $bol ([Windows.Shapes.Shape]::FillProperty) $tipo
        [Windows.Controls.DockPanel]::SetDock($bol, 'Left'); [void]$d.Children.Add($bol)
        $sp = New-Object Windows.Controls.StackPanel; [void]$sp.Children.Add((T "$($e.sl) · $($e.evento)" 13 'B.Texto' 'SemiBold'))
        if ($e.detalhe) { $dt = T $e.detalhe 12 'B.TextoSec'; [void]$sp.Children.Add($dt) }
        [void]$d.Children.Add($sp); [void]$c.Children.Add($d)
    }
}

# =====================================================================================================
# MENU (em grupos): Painel | O QUE MONITORAR | COMO AVISAR | MOTOR
# =====================================================================================================
$itensMenu = @{}
function Item-Menu($chave, $icone, $titulo, $ativo = $true) {
    $it = New-Object Windows.Controls.ListBoxItem; $it.Tag = $chave; $it.IsEnabled = $ativo
    $g = New-Object Windows.Controls.DockPanel
    $i = Icone $icone 16 $(if ($ativo) { 'B.Link' } else { 'B.TextoSec' }); $i.Margin = '0,2,12,0'; $i.VerticalAlignment = 'Top'; [Windows.Controls.DockPanel]::SetDock($i, 'Left'); [void]$g.Children.Add($i)
    $s = New-Object Windows.Controls.StackPanel; [void]$s.Children.Add((T $titulo 13.5 $(if ($ativo) { 'B.Titulo' } else { 'B.TextoSec' }) 'SemiBold'))
    $sub = T '' 12 'B.TextoSec'; $sub.TextWrapping = 'NoWrap'; $sub.TextTrimming = 'CharacterEllipsis'; [void]$s.Children.Add($sub); [void]$g.Children.Add($s)
    $it.Content = $g; [void]$Menu.Items.Add($it); $itensMenu[$chave] = $sub
    return $it
}
function Grupo-Menu($texto) { $h = New-Object Windows.Controls.ListBoxItem; $h.IsEnabled = $false; $h.Focusable = $false; $h.Content = (T $texto 11 'B.TextoSec' 'SemiBold'); $h.Margin = '0,8,0,-4'; [void]$Menu.Items.Add($h) }
Item-Menu 'painel' 0xE80F 'Painel' | Out-Null
Grupo-Menu 'O QUE MONITORAR'
Item-Menu 'sl' 0xE968 'Service Layer' | Out-Null
Item-Menu 'servicos' 0xE912 'Serviços do Windows' | Out-Null
Grupo-Menu 'COMO AVISAR'
Item-Menu 'email' 0xE715 'E-mail e avisos' | Out-Null
Grupo-Menu 'MOTOR'
Item-Menu 'tarefa' 0xE787 'Agendador do Windows' | Out-Null
Item-Menu 'tempos' 0xE8A5 'Logs e registros' | Out-Null
Item-Menu 'versao' 0xE895 'Versão' | Out-Null
function Atualizar-Menu {
    $sls = @($linhasSL | Where-Object { (Texto-De $_.Nome).Trim() })
    $itensMenu['painel'].Text = 'situação de tudo agora'
    $itensMenu['sl'].Text = "$($sls.Count) monitorada$(if ($sls.Count -ne 1) { 's' })"
    $para = @(Destinatarios)
    $itensMenu['email'].Text = $(if ($para.Count) { "vale para tudo · $($para.Count) destinatário$(if ($para.Count -ne 1) { 's' })" } else { 'sem destinatário' })
    $t = Get-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue
    $itensMenu['tarefa'].Text = $(if (-not $t) { 'tarefa não existe' } elseif ([string]$t.State -eq 'Disabled') { 'PARADO' } else { 'ativo · a cada 1 min' })
    $qtdM = $script:marcados.Count; $qtdS = @($script:marcados.Values | ForEach-Object { $_.servidor } | Sort-Object -Unique).Count
    $itensMenu['servicos'].Text = $(if ($qtdM) { "$qtdM marcado$(if ($qtdM -ne 1) { 's' }) em $qtdS servidor$(if ($qtdS -ne 1) { 'es' })" } else { 'nenhum marcado ainda' })
    $itensMenu['tempos'].Text = 'guardados por ' + (Texto-De $caixasTempo['dias_manter_logs']) + ' dias'
    $v = Versao-Instalada; $itensMenu['versao'].Text = $(if ($v) { $v } else { 'sem número' })
    # selo do topo
    if (-not $t) { $txt = 'Tarefa não instalada'; $k = 'erro' } elseif ([string]$t.State -eq 'Disabled') { $txt = 'Monitoramento PARADO'; $k = 'erro' }
    else { $i = $t | Get-ScheduledTaskInfo; $txt = 'Monitorando · última execução ' + $(if ($i.LastRunTime -and $i.LastRunTime.Year -gt 2000) { $i.LastRunTime.ToString('HH:mm') } else { '-' }); $k = 'ok' }
    Recurso $SeloTopo ([Windows.Controls.Border]::BackgroundProperty) (@{ ok = 'B.OkFundo'; erro = 'B.ErroFundo' }[$k])
    Recurso $SeloBola ([Windows.Shapes.Shape]::FillProperty) (@{ ok = 'B.Ok'; erro = 'B.Erro' }[$k])
    Recurso $SeloTexto ([Windows.Controls.TextBlock]::ForegroundProperty) (@{ ok = 'B.Ok'; erro = 'B.Erro' }[$k]); $SeloTexto.Text = $txt
    $TxtVersao.Text = $(if ($v) { "versão $v" } else { '' })
}
function Ir-Para($chave) { foreach ($it in $Menu.Items) { if ($it.Tag -eq $chave) { $Menu.SelectedItem = $it } } }
$Menu.Add_SelectionChanged({
    $it = $Menu.SelectedItem; if (-not $it -or -not $it.Tag) { return }
    if ($it.Tag -eq 'painel') { Montar-Painel }
    if ($it.Tag -eq 'tarefa') { Mostrar-Tarefa }
    $Area.Content = $paginas[$it.Tag]; $Area.ScrollToTop()
    if ($it.Tag -eq 'versao' -and -not $script:versaoVerificada) { $janela.Dispatcher.BeginInvoke([Windows.Threading.DispatcherPriority]::Background, [Action] { Verificar-Versao }) | Out-Null }
})

# =====================================================================================================
# AÇÕES (as mesmas da tela anterior)
# =====================================================================================================
function Confirmar-Pendente {
    if (-not $script:alterado) { return $true }
    $r = Aviso "Há alterações não salvas.`n`nSim = salvar e continuar`nNão = continuar com o que já está salvo`nCancelar = voltar" 'Question' 'YesNoCancel'
    if ($r -eq 'Yes') { return (Salvar) }
    return ($r -eq 'No')
}

function Salvar {
    $erros = @()
    $tempos = [ordered]@{ '_explicacao' = 'Tempos e limites do monitoramento. Editar pelo configurar_monitoramento.ps1.' }
    foreach ($c in $camposTempo) {
        $v = (Texto-De $caixasTempo[$c[0]]).Trim()
        if ($c[0] -eq 'janela_reinicio_memoria') {
            if ($v -notmatch '^\d{1,2}:\d{2}-\d{1,2}:\d{2}$') { $erros += $c[2] } else { $tempos[$c[0]] = $v }
        } else {
            $n = 0.0
            if (-not [double]::TryParse($v.Replace(',', '.'), [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$n) -or $n -lt 0) { $erros += $c[2] }
            elseif ($n -eq [math]::Floor($n)) { $tempos[$c[0]] = [int]$n } else { $tempos[$c[0]] = $n }
        }
    }
    $porta = 0
    if (-not [int]::TryParse((Texto-De $txtPorta).Trim(), [ref]$porta)) { $erros += 'Porta do e-mail' }
    $repetir = 0; $alertaMem = 0
    if (-not [int]::TryParse((Texto-De $txtRepetir).Trim(), [ref]$repetir) -or $repetir -lt 1) { $erros += 'Repetir avisos a cada (minutos)' }
    if (-not [int]::TryParse((Texto-De $txtAlertaMem).Trim(), [ref]$alertaMem) -or $alertaMem -lt 1) { $erros += 'Alerta de memória a cada (minutos)' }
    foreach ($e in @(Destinatarios)) { if ($e -notmatch '^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+$') { $erros += "Destinatário '$e' (um e-mail por linha, ex.: nome@empresa.com.br)" } }
    $avisos = [ordered]@{}
    foreach ($ta in $tiposAviso) { $avisos[$ta[0]] = [bool]$chkAvisos[$ta[0]].IsChecked }
    $avisos['repetir_min'] = $repetir
    $avisos['memoria_min'] = $alertaMem
    # Service Layers: nome único (vira nome de arquivo) e caminhos completos
    $servicos = New-Object System.Collections.ArrayList
    $nomesVistos = @{}
    foreach ($l in $linhasSL) {
        $n = (Texto-De $l.Nome).Trim(); $s = (Texto-De $l.SL).Trim(); $k = (Texto-De $l.Ctl).Trim()
        if (-not $n -and -not $s -and -not $k) { continue }
        if ($n -notmatch '^[A-Za-z0-9_-]+$') { $erros += "Service Layer: nome '$n' (use letras, números, - ou _)" }
        elseif ($nomesVistos.ContainsKey($n.ToUpper())) { $erros += "Service Layer: nome repetido '$n'" }
        $nomesVistos[$n.ToUpper()] = 1
        if ($s -notmatch '^https?://\S+') { $erros += "Caminho da Service Layer de '$n'" }
        if ($k -notmatch '^https?://\S+') { $erros += "Caminho do Controller de '$n'" }
        [void]$servicos.Add([ordered]@{ nome = $n; service_layer = $s; controller = $k; reiniciar = [bool]$l.Reinicia.IsChecked })
    }
    if ($erros.Count) { Aviso ("Valores inválidos:`n- " + ($erros -join "`n- ")) 'Warning' | Out-Null; return $false }
    # nome de servidor digitado errado vira alarme falso: confere na rede antes de gravar
    $janela.Cursor = [Windows.Input.Cursors]::Wait; Trabalhando $true; Status 'Conferindo os servidores na rede...'
    $faltam = @(Servidores-NaoEncontrados @($servicos | ForEach-Object { $_.service_layer; $_.controller }))
    $janela.Cursor = $null; Trabalhando $false
    if ($faltam.Count) {
        $r = Aviso ("Servidor não encontrado na rede:`n- " + ($faltam -join "`n- ") + "`n`nConfira o nome digitado: com o nome errado, o monitoramento trata a Service Layer como fora do ar e envia avisos.`nSe esta tela estiver aberta fora da rede do cliente, pode salvar assim mesmo.`n`nSalvar mesmo assim?") 'Warning' 'YesNo'
        if ($r -ne 'Yes') { Status '● Alterações não salvas - confira o nome do servidor.' 'B.Alerta'; return $false }
    }
    # senha em branco = mantém a salva; senha antiga em texto vira criptografada
    $digCtl = Senha-Digitada $senhaCtl; $digSmtp = Senha-Digitada $senhaSmtp
    $novaCtl = if ($digCtl) { Cripto $digCtl } elseif (Valor $cfg 'controller_senha_cripto' '') { $cfg.controller_senha_cripto } elseif (Valor $cfg 'controller_senha' '') { Cripto $cfg.controller_senha } else { '' }
    $novaSmtp = if ($digSmtp) { Cripto $digSmtp } elseif (Valor $cfg 'smtp_senha_cripto' '') { $cfg.smtp_senha_cripto } elseif (Valor $cfg 'smtp_senha' '') { Cripto $cfg.smtp_senha } else { '' }
    $novo = [ordered]@{
        controller_usuario      = (Texto-De $txtCtlUsuario).Trim()
        controller_senha_cripto = $novaCtl
        smtp_servidor           = (Texto-De $txtSmtp).Trim()
        smtp_porta              = $porta
        smtp_ssl                = [bool]$chkSsl.IsChecked
        smtp_usuario            = (Texto-De $txtSmtpUsuario).Trim()
        smtp_senha_cripto       = $novaSmtp
        email_remetente         = (Texto-De $txtRemetente).Trim()
        email_para              = (@(Destinatarios) -join ', ')
        avisos                  = $avisos
        servicos                = $servicos
    }
    # serviços do Windows: servidores e serviços marcados (só grava a seção se houver algo ou se ela já existia)
    $swAnt = Valor $cfg 'servicos_windows' $null
    $srvsNovos = New-Object System.Collections.ArrayList
    foreach ($l in $linhasSrv | Where-Object { -not $_.Este }) {
        $n = (Texto-De $l.Nome).Trim(); $e = (Texto-De $l.Endereco).Trim(); $u = (Texto-De $l.Usuario).Trim()
        if (-not $n -and -not $e) { continue }
        if ($n -notmatch '^[A-Za-z0-9_.-]+$') { $erros += "Servidor: nome '$n' (use letras, números, ponto, - ou _)" }
        if (-not $e) { $erros += "Servidor '$n': falta o endereço (IP ou nome)" }
        $dig = Senha-Digitada $l.Senha
        $ant = @(Valor $swAnt 'servidores' @()) | Where-Object { $_ -and "$($_.nome)" -ieq $n } | Select-Object -First 1
        $sc = if ($dig) { Cripto $dig } elseif ($ant -and $l.Senha.salva.Visibility -eq 'Visible') { "$($ant.senha_cripto)" } else { '' }
        if ($u -and -not $sc) { $erros += "Servidor '$n': digite a senha do usuário $u" }
        [void]$srvsNovos.Add([ordered]@{ nome = $n; endereco = $e; usuario = $u; senha_cripto = $sc })
    }
    $nomesSrv = @($ESTE) + @($srvsNovos | ForEach-Object { $_.nome })
    # cada serviço grava só os campos da regra escolhida (porta/endereço/log de outra regra não são testados à toa)
    $monsNovos = @()
    foreach ($mk in @($script:marcados.Values | Where-Object { $nomesSrv -contains $_.servidor })) {
        $vf = "$($mk.verificacao)"; if ($vf -notin 'estado', 'log', 'porta', 'url') { $vf = 'estado' }
        $quem = "$($mk.exibicao) ($($mk.servidor))"
        $lg = ''; $mn = 0; $pt = 0; $ur = ''
        if ($vf -eq 'log') {
            $lg = Padrao-Digitado $mk.log; $mn = [int]$mk.travado_min; $mk.log = $lg
            if (-not $lg) { $erros += "$quem`: indique o arquivo de log (ou escolha 'só se parar')" }
            elseif ($lg -notmatch '^([A-Za-z]:\\|\\\\)') { $erros += "$quem`: o arquivo de log precisa do caminho completo (ex.: C:\...\servico.log)" }
            if ($mn -lt 1) { $erros += "$quem`: minutos sem ciclo no log (número inteiro, 1 ou mais)" }
        }
        if ($vf -eq 'porta') { $pt = [int]$mk.porta; if ($pt -lt 1 -or $pt -gt 65535) { $erros += "$quem`: porta (número de 1 a 65535)" } }
        if ($vf -eq 'url') { $ur = "$($mk.url)".Trim(); if ($ur -notmatch '^https?://\S+$') { $erros += "$quem`: endereço (ex.: http://servidor:8080/status)" } }
        if ([int]$mk.memoria_mb -lt 0) { $erros += "$quem`: memória em MB (número inteiro; em branco = não olha)" }
        $monsNovos += [ordered]@{ servidor = $mk.servidor; nome = $mk.nome; exibicao = $mk.exibicao; reiniciar = [bool]$mk.reiniciar; verificacao = $vf
            travado_min = $mn; log = $lg; texto_ciclo = $(if ($vf -eq 'log') { "$($mk.texto_ciclo)".Trim() } else { '' }); porta = $pt; url = $ur
            memoria_mb = [math]::Max(0, [int]$mk.memoria_mb); forcar = [bool]$mk.forcar }
    }
    if ($erros.Count) { Aviso ("Valores inválidos:`n- " + ($erros -join "`n- ")) 'Warning' | Out-Null; return $false }
    if ($srvsNovos.Count -or $monsNovos.Count -or $swAnt) {
        $novo['servicos_windows'] = [ordered]@{ servidores = @($srvsNovos); monitorados = @($monsNovos)
            tentativas = (Valor $swAnt 'tentativas' 3); minutos_entre_reinicios = (Valor $swAnt 'minutos_entre_reinicios' 10) }
    }
    # campos que outras versões possam ter acrescentado ao config.json: são mantidos como estão
    if ($cfg) { foreach ($p in $cfg.PSObject.Properties) { if (-not $novo.Contains($p.Name) -and $p.Name -notin 'controller_senha', 'smtp_senha') { $novo[$p.Name] = $p.Value } } }

    # log de alterações: compara o que está gravado com o que vai gravar (senha: só "alterada", nunca o valor)
    $ant = Ler-Json $arqConfig; $antT = Ler-Json $arqTempos
    $mud = @()
    $mud += Mudou 'Service Layers > Usuário do Controller' (Valor $ant 'controller_usuario' '') $novo.controller_usuario
    if ($digCtl) { $mud += 'Service Layers > Senha do Controller | senha alterada (o valor não é registrado)' }
    $antSL = @{}
    foreach ($s in @(Valor $ant 'servicos' @())) { if ($s -and $s.nome) { $antSL["$($s.nome)".ToUpper()] = $s } }
    $novSL = @{}
    foreach ($s in $servicos) {
        $novSL[$s.nome.ToUpper()] = 1
        $o = $antSL[$s.nome.ToUpper()]
        if (-not $o) { $mud += "Service Layers > $($s.nome) | incluída | Service Layer: $($s.service_layer) · Controller: $($s.controller) · Reiniciar: $(Texto-Log $s.reiniciar)"; continue }
        $mud += Mudou "Service Layers > $($s.nome) > Nome" $o.nome $s.nome
        $mud += Mudou "Service Layers > $($s.nome) > Caminho da Service Layer" $o.service_layer $s.service_layer
        $mud += Mudou "Service Layers > $($s.nome) > Caminho do Controller" $o.controller $s.controller
        $mud += Mudou "Service Layers > $($s.nome) > Reiniciar" ($o.reiniciar -ne $false) $s.reiniciar
    }
    foreach ($k in $antSL.Keys) { if (-not $novSL.ContainsKey($k)) { $o = $antSL[$k]; $mud += "Service Layers > $($o.nome) | removida | era Service Layer: $($o.service_layer) · Controller: $($o.controller)" } }
    foreach ($par in @(@('smtp_servidor', 'Servidor SMTP', ''), @('smtp_porta', 'Porta', 587), @('smtp_ssl', 'Usar SSL/TLS', $true), @('smtp_usuario', 'Usuário do e-mail', ''),
            @('email_remetente', 'Remetente', ''), @('email_para', 'Destinatários', ''))) { $mud += Mudou "E-mail > $($par[1])" (Valor $ant $par[0] $par[2]) $novo[$par[0]] }
    if ($digSmtp) { $mud += 'E-mail > Senha do e-mail | senha alterada (o valor não é registrado)' }
    $antAv = Valor $ant 'avisos' $null
    foreach ($ta in $tiposAviso) {
        $antes = -not ($antAv -and ($antAv.PSObject.Properties.Name -contains $ta[0]) -and $antAv.($ta[0]) -eq $false)
        $mud += Mudou "E-mail > Avisos enviados > $($ta[1])" $antes $avisos[$ta[0]]
    }
    $mud += Mudou 'E-mail > Repetir "continua fora" / "acionar o NOC" a cada (minutos)' (Valor $antAv 'repetir_min' 30) $repetir
    $mud += Mudou 'E-mail > Alerta de memória elevada a cada (minutos)' (Valor $antAv 'memoria_min' 60) $alertaMem
    foreach ($c in $camposTempo) { $mud += Mudou "Tempos e limites > $($c[4]) > $($c[2])" (Valor $antT $c[0] $c[1]) $tempos[$c[0]] }
    # serviços do Windows: servidores e serviços incluídos/retirados/alterados
    $swA = Valor $ant 'servicos_windows' $null
    $aS = @{}; foreach ($s in @(Valor $swA 'servidores' @())) { if ($s -and $s.nome) { $aS["$($s.nome)".ToUpper()] = $s } }
    foreach ($s in $srvsNovos) {
        $o = $aS[$s.nome.ToUpper()]; if (-not $o) { $mud += "Serviços do Windows > Servidor $($s.nome) | incluído | endereço $($s.endereco)$(if ($s.usuario) { ' · usuário ' + $s.usuario })"; continue }
        $mud += Mudou "Serviços do Windows > Servidor $($s.nome) > Endereço" $o.endereco $s.endereco
        $mud += Mudou "Serviços do Windows > Servidor $($s.nome) > Usuário" $o.usuario $s.usuario
        if ($s.senha_cripto -ne "$($o.senha_cripto)") { $mud += "Serviços do Windows > Servidor $($s.nome) > Senha | senha alterada (o valor não é registrado)" }
    }
    foreach ($k in $aS.Keys) { if (-not ($srvsNovos | Where-Object { $_.nome.ToUpper() -eq $k })) { $mud += "Serviços do Windows > Servidor $($aS[$k].nome) | retirado" } }
    $aM = @{}; foreach ($m in @(Valor $swA 'monitorados' @())) { if ($m -and $m.nome) { $aM[("$($m.servidor)|$($m.nome)").ToLower()] = $m } }
    foreach ($m in $monsNovos) {
        $k = ("$($m.servidor)|$($m.nome)").ToLower(); $o = $aM[$k]; $quem = "Serviços do Windows > $($m.servidor) > $($m.exibicao)"
        if (-not $o) { $mud += "$quem | marcado para ficar sempre rodando · reiniciar: $(Texto-Log $m.reiniciar) · $(Texto-Regra $m)$(if ($m.memoria_mb) { ' · memória acima de ' + $m.memoria_mb + ' MB' })"; continue }
        $on = Novo-Marcado $o.servidor $o.nome $o.exibicao $o   # cadastro antigo com os mesmos padrões da tela
        $mud += Mudou "$quem > Reiniciar sozinho" $on.reiniciar $m.reiniciar
        $mud += Mudou "$quem > Considerar travado quando" (Texto-Regra $on) (Texto-Regra $m)
        $mud += Mudou "$quem > Memória acima de (MB)" $on.memoria_mb $m.memoria_mb
    }
    foreach ($k in $aM.Keys) { if (-not ($monsNovos | Where-Object { ("$($_.servidor)|$($_.nome)").ToLower() -eq $k })) { $mud += "Serviços do Windows > $($aM[$k].servidor) > $($aM[$k].exibicao) | desmarcado (não é mais vigiado)" } }

    Gravar-Json $arqConfig ([pscustomobject]$novo)
    Gravar-Json $arqTempos ([pscustomobject]$tempos)
    Registrar-Alteracoes $mud
    $script:cfg = Ler-Json $arqConfig
    $script:carregando = $true
    Definir-Senha $senhaCtl ([bool]$novaCtl); Definir-Senha $senhaSmtp ([bool]$novaSmtp)
    foreach ($l in $linhasSrv | Where-Object { -not $_.Este }) { $sv = $srvsNovos | Where-Object { $_.nome -ieq (Texto-De $l.Nome).Trim() } | Select-Object -First 1; Definir-Senha $l.Senha ([bool]($sv -and $sv.senha_cripto)) }
    $script:carregando = $false
    $script:alterado = $false; $BtnSalvar.IsEnabled = $false
    Status ('✓ Salvo às ' + (Get-Date).ToString('HH:mm:ss') + ' (senhas criptografadas). Vale a partir da próxima execução.') 'B.Ok'
    # servidores salvos ficam compactos (só a linha); Editar abre de novo
    Atualizar-Linhas-SL; foreach ($l in $linhasSL | Where-Object { (Texto-De $_.Nome).Trim() }) { $l.Campos.Visibility = 'Collapsed' }
    Atualizar-Linhas-Servidor; foreach ($l in $linhasSrv | Where-Object { -not $_.Este -and (Texto-De $_.Nome).Trim() -and (Texto-De $_.Endereco).Trim() }) { $l.Campos.Visibility = 'Collapsed' }
    Atualizar-Menu; Desenhar-Seletor; Desenhar-Servicos
    return $true
}

function Rodar-Monitoramento($modo, $botao) {
    if (-not (Confirmar-Pendente)) { return }
    $caixa = if ($modo -eq 'status') { $resAcesso } else { $resEmail }
    Aguarde $botao
    try {
        $caixa.Clear()
        if (-not (Achar-Node)) { Saida $caixa 'Node.js não encontrado: rode o INSTALAR.vbs (baixa o Node) ou instale a LTS em https://nodejs.org/pt/download'; return }
        Saida $caixa $(if ($modo -eq 'status') { 'Testando a conexão com o Controller...' } else { 'Enviando o e-mail de teste...' })
        $texto = Rodar-Node "monitoramento_sl.js $modo"
        # mostra só o essencial (sem o detalhe em JSON do Controller); as linhas já vêm com o horário
        $linhas = @($texto -split "`r?`n" | Where-Object { $_ -and $_ -notmatch 'Controller \(detalhe\)' })
        $caixa.AppendText(($linhas -join "`r`n") + "`r`n"); $caixa.ScrollToEnd()
        $tudo = $linhas -join ' '
        if ($modo -eq 'status') {
            $nomesSL = @($linhasSL | ForEach-Object { (Texto-De $_.Nome).Trim() })
            if ($nomesSL.Count -le 1) { Saida $caixa $(if ($tudo -match 'status: Running') { '>>> RESULTADO: conexão OK.' } else { '>>> RESULTADO: falhou - veja as linhas acima.' }) }
            else { foreach ($n in $nomesSL) { $ok = $linhas | Where-Object { $_ -match ('\[' + [regex]::Escape($n) + '\] Controller: status: Running') }; Saida $caixa $(if ($ok) { ">>> $n : conexão OK." } else { ">>> $n : falhou - veja as linhas acima." }) } }
        } else { Saida $caixa $(if ($tudo -match 'E-mail: enviado') { '>>> RESULTADO: e-mail enviado.' } else { '>>> RESULTADO: e-mail NÃO enviado - veja as linhas acima.' }) }
    } finally { Pronto $botao }
}

# data sempre no formato brasileiro (o Windows do servidor pode estar em inglês)
function DataBR($d) { if ($d -and ([datetime]$d).Year -gt 2000) { ([datetime]$d).ToString('dd/MM/yyyy HH:mm:ss') } else { '-' } }
function Eh-System($id) { return ("$id" -eq '' -or "$id" -eq 'S-1-5-18' -or "$id" -match '^(NT AUTHORITY\\)?(SYSTEM|SISTEMA)$') }

function Mostrar-Tarefa {
    $t = Get-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue
    if (-not $t) {
        Recurso $lblTarefa ([Windows.Controls.TextBlock]::ForegroundProperty) 'B.Alerta'
        $lblTarefa.Text = "Situação: a tarefa NÃO existe - o monitoramento não está rodando.`nDê dois cliques no INSTALAR.vbs desta pasta para criar."
        $btnLigar.IsEnabled = $false; Atualizar-Menu; return
    }
    $parada = ([string]$t.State -eq 'Disabled')
    $btnLigar.IsEnabled = $true
    Texto-Botao $btnLigar $(if ($parada) { 'Iniciar monitoramento' } else { 'Parar monitoramento' })
    $btnLigar.Style = $janela.FindResource($(if ($parada) { 'BotaoPrimario' } else { 'BotaoPerigo' }))
    $i = $t | Get-ScheduledTaskInfo
    $estado = switch ([string]$t.State) { 'Ready' { 'ATIVA, aguardando o próximo minuto' } 'Running' { 'ATIVA, executando agora' } 'Disabled' { 'PARADA - clique em Iniciar monitoramento' } default { [string]$t.State } }
    $resultado = if ($i.LastTaskResult -eq 0) { 'ok' } elseif ($i.LastTaskResult -eq 267009) { 'em execução' } elseif ($i.LastTaskResult -eq 267011) { 'ainda não executou' } else { 'código ' + $i.LastTaskResult }
    Recurso $lblTarefa ([Windows.Controls.TextBlock]::ForegroundProperty) $(if ($parada) { 'B.Erro' } else { 'B.Ok' })
    $lblTarefa.Text = "Situação: $estado`nUsuário: " + $t.Principal.UserId + "`nÚltima execução: " + (DataBR $i.LastRunTime) + " ($resultado)`nPróxima execução: " + (DataBR $i.NextRunTime)
    Atualizar-Menu
}

function Ligar-Desligar($botao) {
    $t = Get-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue
    if (-not $t) { Mostrar-Tarefa; return }
    $resTarefa.Clear()
    if ([string]$t.State -eq 'Disabled') {
        if (-not (Confirmar-Pendente)) { return }
        # só liga com o mínimo configurado: uma Service Layer e a senha do Controller
        $c = Ler-Json $arqConfig
        $falta = @()
        if (-not @((Valor $c 'servicos' @()) | Where-Object { $_ -and $_.nome }).Count) { $falta += 'cadastrar uma Service Layer (página Service Layer)' }
        if (-not "$(Valor $c 'controller_usuario' '')".Trim()) { $falta += 'informar o usuário do Controller (página Service Layer)' }
        if (-not (TemSenha (Valor $c 'controller_senha_cripto' '') (Valor $c 'controller_senha' ''))) { $falta += 'salvar a senha do Controller (página Service Layer)' }
        if ($falta.Count) { Aviso ("Antes de iniciar, falta:`n- " + ($falta -join "`n- ")) 'Warning' | Out-Null; return }
        $janela.Cursor = [Windows.Input.Cursors]::Wait
        $faltam = @(Servidores-NaoEncontrados @((Valor $c 'servicos' @()) | ForEach-Object { $_.service_layer; $_.controller }))
        $janela.Cursor = $null
        if ($faltam.Count) {
            $r = Aviso ("Servidor não encontrado na rede:`n- " + ($faltam -join "`n- ") + "`n`nO monitoramento vai tratar essa Service Layer como fora do ar e enviar avisos. Confira o nome na página Service Layer.`n`nIniciar mesmo assim?") 'Warning' 'YesNo'
            if ($r -ne 'Yes') { return }
        }
        $botao.IsEnabled = $false
        try {
            Enable-ScheduledTask -TaskName $nomeTarefa -ErrorAction Stop | Out-Null
            Start-ScheduledTask -TaskName $nomeTarefa -ErrorAction Stop
            Registrar-Alteracoes 'Tarefa agendada > Monitoramento | antes: PARADO | depois: INICIADO'
            Saida $resTarefa '>>> Monitoramento INICIADO: a tarefa roda agora e a cada 1 minuto.'
        } catch { Saida $resTarefa ('>>> Não foi possível iniciar: ' + $_.Exception.Message) }
    } else {
        $r = Aviso "Parar o monitoramento?`n`nAs Service Layers ficam sem vigilância (sem reinício e sem e-mail) até clicar em Iniciar de novo." 'Warning' 'YesNo'
        if ($r -ne 'Yes') { return }
        $botao.IsEnabled = $false
        try {
            Stop-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue
            Disable-ScheduledTask -TaskName $nomeTarefa -ErrorAction Stop | Out-Null
            Registrar-Alteracoes 'Tarefa agendada > Monitoramento | antes: INICIADO | depois: PARADO'
            Saida $resTarefa '>>> Monitoramento PARADO: a tarefa não roda até clicar em Iniciar monitoramento.'
        } catch { Saida $resTarefa ('>>> Não foi possível parar: ' + $_.Exception.Message) }
    }
    Start-Sleep -Milliseconds 500
    Mostrar-Tarefa
}

function Ler-Conta {
    $t = Get-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue
    if ($t -and -not (Eh-System $t.Principal.UserId)) { $rdUsuario.IsChecked = $true; Definir $txtContaUsuario $t.Principal.UserId } else { $rdSystem.IsChecked = $true }
    Ajustar-Conta
}
function Explicar-Codigo($cod) {
    $hex = '0x{0:X8}' -f ([int64]$cod -band 0xFFFFFFFF)
    switch ($hex) {
        '0x8007052E' { return "$hex - usuário ou senha incorretos" }
        '0x80070569' { return "$hex - o usuário não tem a permissão 'Fazer logon como trabalho em lote' neste servidor (pedir ao TI do cliente)" }
        '0x80070532' { return "$hex - a senha deste usuário expirou" }
        '0x80070533' { return "$hex - o usuário está desativado" }
        '0x80070005' { return "$hex - acesso negado (permissão na pasta ou no Node)" }
        default { return $hex }
    }
}
function Aplicar-Conta($botao) {
    $resTarefa.Clear()
    $t = Get-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue
    if (-not $t) { Saida $resTarefa 'A tarefa não existe: dê dois cliques no INSTALAR.vbs desta pasta.'; return }
    $usuario = (Texto-De $txtContaUsuario).Trim()
    if ($rdUsuario.IsChecked) {
        if (-not $usuario) { Saida $resTarefa 'Digite o usuário (ex.: DOMINIO\usuario).'; [void]$txtContaUsuario.Tag.Focus(); return }
        if (-not $txtContaSenha.Password) { Saida $resTarefa 'Digite a senha deste usuário.'; [void]$txtContaSenha.Focus(); return }
    }
    $conta = if ($rdUsuario.IsChecked) { $usuario } else { 'SYSTEM' }
    $contaAntes = if (Eh-System $t.Principal.UserId) { 'SYSTEM' } else { $t.Principal.UserId }
    Aguarde $botao
    try {
        if ($rdUsuario.IsChecked) {
            Saida $resTarefa "Liberando a pasta para $usuario (gravar logs e estado)..."
            $retorno = & icacls.exe $pasta /grant "${usuario}:(OI)(CI)M" /C
            if ($LASTEXITCODE -ne 0) { Saida $resTarefa "Aviso: não consegui liberar a pasta para '$usuario' (confira o formato DOMINIO\usuario; em pasta compartilhada, o TI pode precisar liberar). Seguindo...`n$($retorno -join ' ')" }
            Saida $resTarefa 'Trocando a conta da tarefa (o Windows confere a senha)...'
            Set-ScheduledTask -TaskName $nomeTarefa -User $usuario -Password $txtContaSenha.Password -ErrorAction Stop | Out-Null
            $txtContaSenha.Password = ''
        } else {
            Saida $resTarefa 'Trocando a conta da tarefa para SYSTEM...'
            Set-ScheduledTask -TaskName $nomeTarefa -Principal (New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest) -ErrorAction Stop | Out-Null
        }
        $alt = Mudou 'Tarefa agendada > Executar a tarefa como' $contaAntes $conta
        if (-not $alt -and $rdUsuario.IsChecked) { $alt = "Tarefa agendada > Executar a tarefa como | senha de $usuario atualizada (o valor não é registrado)" }
        Registrar-Alteracoes $alt
        Saida $resTarefa "Conta trocada para $conta. Rodando a tarefa uma vez para testar..."
        $inicio = Get-Date
        $estavaParada = ([string](Get-ScheduledTask -TaskName $nomeTarefa).State -eq 'Disabled')
        if ($estavaParada) { Enable-ScheduledTask -TaskName $nomeTarefa -ErrorAction Stop | Out-Null }
        Stop-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue
        Start-ScheduledTask -TaskName $nomeTarefa -ErrorAction Stop
        if ($estavaParada) { Start-Sleep -Seconds 1; Disable-ScheduledTask -TaskName $nomeTarefa -ErrorAction SilentlyContinue | Out-Null }
        $log = $null; $erro = $null
        for ($k = 0; $k -lt 20 -and -not $log -and -not $erro; $k++) {
            for ($q = 0; $q -lt 10; $q++) { Start-Sleep -Milliseconds 100; Bombear }
            $log = Get-ChildItem -LiteralPath (Join-Path $pasta 'logs') -Recurse -Filter '*.log' -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -ge $inicio -and $_.FullName -notmatch '\\alteracoes\\' } | Select-Object -First 1
            $i = Get-ScheduledTaskInfo -TaskName $nomeTarefa
            if (-not $log -and $i.LastRunTime -ge $inicio.AddSeconds(-2) -and @(0, 267009, 267011) -notcontains [int64]$i.LastTaskResult) { $erro = $i.LastTaskResult }
        }
        if ($log) { Saida $resTarefa (">>> RESULTADO: a tarefa rodou com $conta e gravou o log (logs\$($log.Directory.Name)\$($log.Name)). Tudo certo." + $(if ($estavaParada) { ' Ela continua PARADA: clique em Iniciar monitoramento quando quiser.' } else { '' })) }
        elseif ($erro) { Saida $resTarefa (">>> RESULTADO: a tarefa NÃO rodou com $conta. Código " + (Explicar-Codigo $erro)) }
        else { Saida $resTarefa '>>> RESULTADO: a tarefa iniciou, mas ainda não gravou log. Clique em Atualizar informações daqui a 1 minuto e veja a última execução.' }
    } catch { Saida $resTarefa (">>> RESULTADO: não foi possível trocar a conta: " + $_.Exception.Message) }
    finally { Pronto $botao; Mostrar-Tarefa }
}

# =====================================================================================================
# TOPO: manual e modo dia / noite (a escolha fica no registro do usuário: HKCU\Software\SPS Group\Monitoramento)
# =====================================================================================================
$arqManual = Join-Path $pasta 'Manual_Monitoramento_Service_Layer.pdf'
$sp = New-Object Windows.Controls.StackPanel; $sp.Orientation = 'Horizontal'; $ic = Icone 0xE736 13 'B.Titulo'; $ic.Margin = '0,2,8,0'; [void]$sp.Children.Add($ic); [void]$sp.Children.Add((T 'Manual' 13 'B.Titulo')); $BtnManual.Content = $sp
$BtnManual.Add_Click({ if (Test-Path -LiteralPath $arqManual) { [void][Diagnostics.Process]::Start($arqManual) } else { Aviso "Manual não encontrado nesta pasta:`n$arqManual" | Out-Null } })
$chaveReg = 'HKCU:\Software\SPS Group\Monitoramento'
function Tema-Inicial {
    try { $t = (Get-ItemProperty -LiteralPath $chaveReg -ErrorAction Stop).tema; if ($t -in @('claro', 'escuro')) { return $t } } catch { }
    try { if ((Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -ErrorAction Stop).AppsUseLightTheme -eq 0) { return 'escuro' } } catch { }
    return 'claro'
}
function Aplicar-Tema($nome) {
    $script:tema = $nome
    foreach ($k in $TEMAS[$nome].Keys) {
        $p = [Windows.Media.SolidColorBrush]::new([Windows.Media.ColorConverter]::ConvertFromString($TEMAS[$nome][$k])); $p.Freeze(); $janela.Resources["B.$k"] = $p
    }
    $sp = New-Object Windows.Controls.StackPanel; $sp.Orientation = 'Horizontal'
    $ic = Icone $(if ($nome -eq 'escuro') { 0xE706 } else { 0xE708 }) 13 'B.Titulo'; $ic.Margin = '0,2,8,0'; [void]$sp.Children.Add($ic)
    [void]$sp.Children.Add((T $(if ($nome -eq 'escuro') { 'Modo dia' } else { 'Modo noite' }) 13 'B.Titulo')); $BtnTema.Content = $sp
    Barra-Titulo
}
# barra de título do Windows na mesma cor (Windows 11; em versões antigas é ignorado)
function Barra-Titulo { try { $h = (New-Object Windows.Interop.WindowInteropHelper($janela)).Handle; if ($h -ne [IntPtr]::Zero) { $v = [int]($script:tema -eq 'escuro'); [void][Monit.Dwm]::DwmSetWindowAttribute($h, 20, [ref]$v, 4) } } catch { } }
$BtnTema.Add_Click({
    $novo = $(if ($script:tema -eq 'escuro') { 'claro' } else { 'escuro' }); Aplicar-Tema $novo
    try { if (-not (Test-Path -LiteralPath $chaveReg)) { New-Item -Path $chaveReg -Force | Out-Null }; Set-ItemProperty -LiteralPath $chaveReg -Name tema -Value $novo } catch { }
})
$janela.Add_SourceInitialized({ Barra-Titulo })

$BtnSalvar.Add_Click({ Salvar | Out-Null })
# fechar com alteração pendente: pergunta
$janela.Add_Closing({
    param($s, $e)
    if (-not $script:alterado) { return }
    $r = Aviso 'Salvar as alterações antes de fechar?' 'Question' 'YesNoCancel'
    if ($r -eq 'Cancel') { $e.Cancel = $true } elseif ($r -eq 'Yes' -and -not (Salvar)) { $e.Cancel = $true }
})
# tamanho inicial proporcional à tela (servidor por acesso remoto costuma ter resolução baixa): até 85% da área útil,
# no máximo 1120 x 800 e no mínimo o que cabe; pode ser redimensionada à vontade
$util = [Windows.SystemParameters]::WorkArea
$janela.Width = [Math]::Max([Math]::Min(1120, [Math]::Floor($util.Width * 0.85)), [Math]::Min($janela.MinWidth, $util.Width))
$janela.Height = [Math]::Max([Math]::Min(800, [Math]::Floor($util.Height * 0.85)), [Math]::Min($janela.MinHeight, $util.Height))

Aplicar-Tema (Tema-Inicial)
Ler-Conta
Atualizar-Menu
Mostrar-Versao ''
$script:carregando = $false
Ir-Para 'painel'
if ($env:SPS_TELA_TESTE) { return }   # teste automatizado: só monta a janela
[void]$janela.ShowDialog()
